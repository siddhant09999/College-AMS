package com.college.campustrack;

import com.college.campustrack.service.AuthService;

public class CreateTestUser {

    public static void main(String[] args) {

        try {
            AuthService authService = new AuthService();

            int userId = authService.createUser(
                    "student1",
                    "student123",
                    "STUDENT",
                    1,
                    null
            );

            System.out.println("Student login created! User ID: " + userId);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}