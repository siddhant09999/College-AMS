package com.college.campustrack.util;

public final class ValidationUtil {
    private ValidationUtil() {}
    public static void required(String value, String field) { if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " is required"); }
    public static void positive(int value, String field) { if (value <= 0) throw new IllegalArgumentException(field + " must be positive"); }
    public static void range(double value, double min, double max, String field) { if (value < min || value > max) throw new IllegalArgumentException(field + " must be between " + min + " and " + max); }
}