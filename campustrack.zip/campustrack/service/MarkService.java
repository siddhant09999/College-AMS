package com.college.campustrack.service;



import com.college.campustrack.dao.MarkDAO;import com.college.campustrack.model.Mark;import com.college.campustrack.util.ValidationUtil;
public class MarkService{private final MarkDAO dao=new MarkDAO();public void save(Mark m)throws Exception{ValidationUtil.range(m.marks(),0,100,"Marks");dao.save(m);}public static String grade(double x){if(x>=90)return "A+";if(x>=80)return "A";if(x>=70)return "B+";if(x>=60)return "B";if(x>=50)return "C";if(x>=40)return "D";return "F";}}

