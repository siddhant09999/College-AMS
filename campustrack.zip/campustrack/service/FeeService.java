package com.college.campustrack.service;

import com.college.campustrack.dao.FeeDAO;import java.math.BigDecimal;import java.sql.Date;
public class FeeService{private final FeeDAO dao=new FeeDAO();public void create(int studentId,String type,BigDecimal amount,BigDecimal paid,Date due)throws Exception{dao.create(studentId,type,amount,paid,due);}public void pay(int feeId,BigDecimal amount)throws Exception{if(amount.signum()<=0)throw new IllegalArgumentException("Payment must be positive");dao.pay(feeId,amount);}}

