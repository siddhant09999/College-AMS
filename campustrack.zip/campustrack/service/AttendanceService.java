package com.college.campustrack.service;

import com.college.campustrack.dao.AttendanceDAO;import com.college.campustrack.model.Attendance;
public class AttendanceService{private final AttendanceDAO dao=new AttendanceDAO();public void mark(Attendance a)throws Exception{dao.save(a);}public double percentage(int studentId,int subjectId)throws Exception{return dao.percentage(studentId,subjectId);}}
