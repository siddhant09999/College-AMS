package com.college.campustrack.service;

import com.college.campustrack.dao.UserDAO;
import com.college.campustrack.model.User;
import com.college.campustrack.util.PasswordUtil;
import com.college.campustrack.util.ValidationUtil;

public class AuthService {
    private final UserDAO dao = new UserDAO();

    public User login(String username, String password) throws Exception {
        ValidationUtil.required(username, "Username");
        ValidationUtil.required(password, "Password");
        User user = dao.findByUsername(username);
        if (user == null || !PasswordUtil.matches(password, user.passwordHash())) {
            throw new SecurityException("Invalid username or password");
        }
        if ("STUDENT".equals(user.role())) {
            if (user.studentId() == null || !dao.isStudentActive(user.studentId())) {
                throw new SecurityException("Student account is deactivated. Contact the administrator.");
            }
        }
        return user;
    }

    public int createUser(String username, String password, String role,
                          Integer studentId, Integer facultyId) throws Exception {
        return dao.create(username, PasswordUtil.hash(password), role, studentId, facultyId);
    }
}
