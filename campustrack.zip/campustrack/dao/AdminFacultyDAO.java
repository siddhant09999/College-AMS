
package com.college.campustrack.dao;

import com.college.campustrack.model.Faculty;
import com.college.campustrack.util.DatabaseConnection;
import com.college.campustrack.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminFacultyDAO {

    public List<String[]> getDepartments() throws SQLException {

        List<String[]> result = new ArrayList<>();

        String sql = "SELECT id, name FROM departments ORDER BY name";

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("name")
                });
            }
        }

        return result;
    }

    public int createFacultyWithAccount(
            Faculty faculty,
            String username,
            String password
    ) throws Exception {

        validateFaculty(faculty);

        if (username == null || username.isBlank()
                || password == null || password.length() < 8) {

            throw new IllegalArgumentException(
                    "Username and password of at least " +
                            "8 characters are required."
            );
        }

        String passwordHash = PasswordUtil.hash(password);

        String facultySql = """
                INSERT INTO faculty
                (employee_no, name, email, phone, department_id)
                SELECT ?, ?, ?, ?, d.id
                FROM departments d
                WHERE d.id = ?
                """;

        String userSql = """
                INSERT INTO users
                (username, password_hash, role, student_id, faculty_id)
                VALUES (?, ?, 'FACULTY', NULL, ?)
                """;

        try (Connection c = DatabaseConnection.getConnection()) {

            c.setAutoCommit(false);

            try {
                int facultyId;

                try (PreparedStatement p = c.prepareStatement(
                        facultySql,
                        Statement.RETURN_GENERATED_KEYS
                )) {

                    p.setString(1, faculty.employeeNo().trim());
                    p.setString(2, faculty.name().trim());
                    p.setString(3, faculty.email().trim());
                    p.setString(4, faculty.phone());
                    p.setInt(5, faculty.departmentId());

                    if (p.executeUpdate() != 1) {
                        throw new SQLException(
                                "Selected branch does not exist."
                        );
                    }

                    try (ResultSet keys = p.getGeneratedKeys()) {

                        if (!keys.next()) {
                            throw new SQLException(
                                    "Faculty ID was not generated."
                            );
                        }

                        facultyId = keys.getInt(1);
                    }
                }

                try (PreparedStatement p = c.prepareStatement(userSql)) {

                    p.setString(1, username.trim());
                    p.setString(2, passwordHash);
                    p.setInt(3, facultyId);

                    if (p.executeUpdate() != 1) {
                        throw new SQLException(
                                "Faculty login was not created."
                        );
                    }
                }

                c.commit();
                return facultyId;

            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        }
    }

    public void updateFaculty(Faculty faculty) throws SQLException {

        validateFaculty(faculty);

        if (faculty.id() <= 0) {
            throw new IllegalArgumentException(
                    "Select a faculty member before editing."
            );
        }

        String sql = """
                UPDATE faculty f
                JOIN departments d ON d.id = ?
                SET f.employee_no = ?,
                    f.name = ?,
                    f.email = ?,
                    f.phone = ?,
                    f.department_id = d.id
                WHERE f.id = ?
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, faculty.departmentId());
            p.setString(2, faculty.employeeNo().trim());
            p.setString(3, faculty.name().trim());
            p.setString(4, faculty.email().trim());
            p.setString(5, faculty.phone());
            p.setInt(6, faculty.id());

            p.executeUpdate();
        }
    }

    public void deleteFaculty(int facultyId) throws SQLException {

        if (facultyId <= 0) {
            throw new IllegalArgumentException(
                    "Select a faculty member to delete."
            );
        }

        try (Connection c = DatabaseConnection.getConnection()) {

            c.setAutoCommit(false);

            try {
                // Lock faculty record before checking assignments.
                try (PreparedStatement p = c.prepareStatement(
                        "SELECT id FROM faculty WHERE id = ? FOR UPDATE")) {

                    p.setInt(1, facultyId);

                    try (ResultSet r = p.executeQuery()) {

                        if (!r.next()) {
                            throw new SQLException(
                                    "Faculty member not found."
                            );
                        }
                    }
                }

                // Prevent deleting teachers assigned to classes.
                String checkSql = """
                        SELECT COUNT(*)
                        FROM timetable
                        WHERE faculty_id = ?
                        """;

                try (PreparedStatement p = c.prepareStatement(checkSql)) {

                    p.setInt(1, facultyId);

                    try (ResultSet r = p.executeQuery()) {

                        if (r.next() && r.getInt(1) > 0) {
                            throw new SQLException(
                                    "This faculty member has timetable " +
                                            "assignments. Remove or reassign " +
                                            "those classes before deletion."
                            );
                        }
                    }
                }

                // Remove faculty login account.
                try (PreparedStatement p = c.prepareStatement(
                        "DELETE FROM users WHERE faculty_id = ?")) {

                    p.setInt(1, facultyId);
                    p.executeUpdate();
                }

                // Remove faculty record.
                try (PreparedStatement p = c.prepareStatement(
                        "DELETE FROM faculty WHERE id = ?")) {

                    p.setInt(1, facultyId);

                    if (p.executeUpdate() != 1) {
                        throw new SQLException(
                                "Faculty deletion failed."
                        );
                    }
                }

                c.commit();

            } catch (Exception e) {

                c.rollback();

                if (e instanceof SQLException sqlException) {
                    throw sqlException;
                }

                throw new SQLException(
                        "Unable to delete faculty.", e
                );
            }
        }
    }

    private void validateFaculty(Faculty faculty) {

        if (faculty == null
                || faculty.employeeNo() == null
                || faculty.employeeNo().isBlank()
                || faculty.name() == null
                || faculty.name().isBlank()
                || faculty.email() == null
                || faculty.email().isBlank()
                || faculty.departmentId() <= 0) {

            throw new IllegalArgumentException(
                    "Enter valid faculty details."
            );
        }
    }
}
