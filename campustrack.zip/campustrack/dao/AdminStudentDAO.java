
package com.college.campustrack.dao;

import com.college.campustrack.model.Student;
import com.college.campustrack.util.DatabaseConnection;
import com.college.campustrack.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminStudentDAO {

    public List<String[]> getDepartments() throws SQLException {
        List<String[]> result = new ArrayList<>();

        String sql = "SELECT id, name FROM departments ORDER BY name";

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("name")
                });
            }
        }

        return result;
    }

    public List<String[]> getCourses(int departmentId)
            throws SQLException {

        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT id, name
                FROM courses
                WHERE department_id = ?
                ORDER BY name
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, departmentId);

            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    result.add(new String[]{
                            String.valueOf(r.getInt("id")),
                            r.getString("name")
                    });
                }
            }
        }

        return result;
    }

    public int createStudentWithAccount(
            Student student,
            String username,
            String password
    ) throws Exception {

        validateStudent(student);

        if (username == null || username.isBlank()
                || password == null || password.length() < 8) {
            throw new IllegalArgumentException(
                    "Username and password (minimum 8 characters) are required."
            );
        }

        String hash = PasswordUtil.hash(password);

        String studentSql = """
                INSERT INTO students
                (roll_no, name, email, phone,
                 department_id, course_id, semester,
                 division, admission_year)
                SELECT ?, ?, ?, ?, d.id, c.id, ?, ?, ?
                FROM departments d
                JOIN courses c ON c.department_id = d.id
                WHERE d.id = ? AND c.id = ?
                """;

        String userSql = """
                INSERT INTO users
                (username, password_hash, role, student_id, faculty_id)
                VALUES (?, ?, 'STUDENT', ?, NULL)
                """;

        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);

            try {
                int studentId;

                try (PreparedStatement p = c.prepareStatement(
                        studentSql, Statement.RETURN_GENERATED_KEYS)) {

                    p.setString(1, student.rollNo().trim());
                    p.setString(2, student.name().trim());
                    p.setString(3, student.email().trim());
                    p.setString(4, student.phone());
                    p.setInt(5, student.semester());
                    p.setString(6, student.division());
                    p.setInt(7, student.admissionYear());
                    p.setInt(8, student.departmentId());
                    p.setInt(9, student.courseId());

                    if (p.executeUpdate() != 1) {
                        throw new SQLException(
                                "Selected branch and course do not match."
                        );
                    }

                    try (ResultSet keys = p.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException(
                                    "Student ID was not generated."
                            );
                        }
                        studentId = keys.getInt(1);
                    }
                }

                try (PreparedStatement p = c.prepareStatement(userSql)) {
                    p.setString(1, username.trim());
                    p.setString(2, hash);
                    p.setInt(3, studentId);
                    p.executeUpdate();
                }

                c.commit();
                return studentId;

            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        }
    }

    public void updateStudent(Student student) throws SQLException {
        validateStudent(student);

        if (student.id() <= 0) {
            throw new IllegalArgumentException(
                    "Select a student before saving changes."
            );
        }

        String sql = """
                UPDATE students s
                JOIN courses c ON c.id = ?
                SET s.roll_no = ?,
                    s.name = ?,
                    s.email = ?,
                    s.phone = ?,
                    s.department_id = ?,
                    s.course_id = ?,
                    s.semester = ?,
                    s.division = ?,
                    s.admission_year = ?
                WHERE s.id = ?
                  AND c.department_id = ?
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, student.courseId());
            p.setString(2, student.rollNo().trim());
            p.setString(3, student.name().trim());
            p.setString(4, student.email().trim());
            p.setString(5, student.phone());
            p.setInt(6, student.departmentId());
            p.setInt(7, student.courseId());
            p.setInt(8, student.semester());
            p.setString(9, student.division());
            p.setInt(10, student.admissionYear());
            p.setInt(11, student.id());
            p.setInt(12, student.departmentId());

            p.executeUpdate();
        }
    }

    private void requireAdmin() {
        com.college.campustrack.model.User user =
                com.college.campustrack.UserSession.getCurrentUser();
        if (user == null || !"ADMIN".equals(user.role())) {
            throw new SecurityException("Administrator access required.");
        }
    }

    public boolean isStudentActive(int studentId) throws SQLException {
        requireAdmin();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(
                     "SELECT is_active FROM students WHERE id = ?")) {
            p.setInt(1, studentId);
            try (ResultSet r = p.executeQuery()) {
                if (!r.next()) throw new SQLException("Student not found.");
                return r.getBoolean(1);
            }
        }
    }

    public void setStudentActive(int studentId, boolean active) throws SQLException {
        requireAdmin();
        if (studentId <= 0) {
            throw new IllegalArgumentException("Select a student first.");
        }
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(
                     "UPDATE students SET is_active = ? WHERE id = ?")) {
            p.setBoolean(1, active);
            p.setInt(2, studentId);
            if (p.executeUpdate() != 1) {
                throw new SQLException("Student not found or status could not be updated.");
            }
        }
    }

    // Kept for compatibility: never permanently erase student history.
    public void deleteStudent(int studentId) throws SQLException {
        setStudentActive(studentId, false);
    }

    private void validateStudent(Student student) {
        if (student == null
                || student.rollNo() == null
                || student.rollNo().isBlank()
                || student.name() == null
                || student.name().isBlank()
                || student.email() == null
                || student.email().isBlank()
                || student.departmentId() <= 0
                || student.courseId() <= 0
                || student.semester() < 1
                || student.semester() > 8
                || student.admissionYear() < 1900
                || student.admissionYear() > 2100) {

            throw new IllegalArgumentException(
                    "Enter valid student details."
            );
        }
    }
}

