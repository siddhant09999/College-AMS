
package com.college.campustrack.dao;

import com.college.campustrack.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TimetableDAO {

    public List<String[]> getTimetableForStudent(int studentId)
            throws SQLException {

        List<String[]> results = new ArrayList<>();

        String sql = """
            SELECT
                t.day_of_week,
                s.name AS subject_name,
                t.start_time,
                t.end_time,
                t.classroom
            FROM timetable t
            JOIN subjects s ON t.subject_id = s.id
            JOIN students st ON t.course_id = st.course_id
            WHERE st.id = ?
              AND s.semester = st.semester
            ORDER BY
                FIELD(t.day_of_week,
                    'Monday', 'Tuesday', 'Wednesday',
                    'Thursday', 'Friday', 'Saturday', 'Sunday'),
                t.start_time
            """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {

                    String day = rs.getString("day_of_week");
                    String subject = rs.getString("subject_name");

                    String start = rs.getTime("start_time")
                            .toLocalTime().toString();

                    String end = rs.getTime("end_time")
                            .toLocalTime().toString();

                    String room = rs.getString("classroom");

                    results.add(new String[]{
                            day,
                            subject,
                            start + " - " + end,
                            room == null ? "Not assigned" : room
                    });
                }
            }
        }

        return results;
    }
}

