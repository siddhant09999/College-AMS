package com.college.campustrack.dao;

import com.college.campustrack.model.Faculty;import com.college.campustrack.util.DatabaseConnection;import java.sql.*;import java.util.*;
public class FacultyDAO{
    private Faculty map(ResultSet r)throws SQLException{return new Faculty(r.getInt("id"),r.getString("employee_no"),r.getString("name"),r.getString("email"),r.getString("phone"),r.getInt("department_id"));}
    public int create(Faculty f)throws SQLException{String q="INSERT INTO faculty(employee_no,name,email,phone,department_id) VALUES(?,?,?,?,?)";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q,Statement.RETURN_GENERATED_KEYS)){set(p,f);p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){r.next();return r.getInt(1);}}}
    private void set(PreparedStatement p,Faculty f)throws SQLException{p.setString(1,f.employeeNo());p.setString(2,f.name());p.setString(3,f.email());p.setString(4,f.phone());p.setInt(5,f.departmentId());}
    public void update(Faculty f)throws SQLException{String q="UPDATE faculty SET employee_no=?,name=?,email=?,phone=?,department_id=? WHERE id=?";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){set(p,f);p.setInt(6,f.id());p.executeUpdate();}}
    public void delete(int id)throws SQLException{try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM faculty WHERE id=?")){p.setInt(1,id);p.executeUpdate();}}
    public List<Faculty> search(String x)throws SQLException{List<Faculty> a=new ArrayList<>();String q="SELECT * FROM faculty WHERE employee_no LIKE ? OR name LIKE ? OR email LIKE ? ORDER BY name";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){String s="%"+x+"%";p.setString(1,s);p.setString(2,s);p.setString(3,s);try(ResultSet r=p.executeQuery()){while(r.next())a.add(map(r));}}return a;}
}
