package com.college.campustrack.dao;

import com.college.campustrack.model.Attendance;
import com.college.campustrack.util.DatabaseConnection;
import java.sql.*;
import java.time.LocalDate;
public class AttendanceDAO{
    public void save(Attendance a)throws SQLException{String q="INSERT INTO attendance(student_id,subject_id,date,present) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE present=VALUES(present)";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,a.studentId());p.setInt(2,a.subjectId());p.setDate(3,Date.valueOf(a.date()));p.setBoolean(4,a.present());p.executeUpdate();}}
    public double percentage(int studentId,int subjectId)throws SQLException{String q="SELECT COALESCE(100.0*SUM(present)/NULLIF(COUNT(*),0),0) FROM attendance WHERE student_id=? AND subject_id=?";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,studentId);p.setInt(2,subjectId);try(ResultSet r=p.executeQuery()){r.next();return r.getDouble(1);}}}


    public java.util.List<String[]> getAttendanceSummary(int studentId)
            throws SQLException {

        java.util.List<String[]> summaries = new java.util.ArrayList<>();

        String sql = """
        SELECT
            s.name AS subject_name,
            COUNT(a.id) AS total_classes,
            COALESCE(SUM(CASE WHEN a.present = TRUE THEN 1 ELSE 0 END), 0)
                AS attended_classes
        FROM students st
        JOIN subjects s
            ON s.course_id = st.course_id
            AND s.semester = st.semester
        LEFT JOIN attendance a
            ON a.subject_id = s.id
            AND a.student_id = st.id
        WHERE st.id = ?
        GROUP BY s.id, s.name
        ORDER BY s.name
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String subject = rs.getString("subject_name");
                    int attended = rs.getInt("attended_classes");
                    int total = rs.getInt("total_classes");

                    String percentage = total == 0
                            ? "N/A"
                            : String.format("%.1f%%", attended * 100.0 / total);

                    summaries.add(new String[]{
                            subject,
                            String.valueOf(attended),
                            String.valueOf(total),
                            percentage
                    });
                }
            }
        }

        return summaries;
    }


    public java.util.List<String[]> getFacultySubjects(int facultyId)
            throws SQLException {

        java.util.List<String[]> results = new java.util.ArrayList<>();

        String sql = """
        SELECT DISTINCT s.id, s.name
        FROM timetable t
        JOIN subjects s ON s.id = t.subject_id
        WHERE t.faculty_id = ?
        ORDER BY s.name
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, facultyId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.add(new String[]{
                            String.valueOf(rs.getInt("id")),
                            rs.getString("name")
                    });
                }
            }
        }

        return results;
    }

    public java.util.List<String[]> getStudentsForFacultySubject(
            int facultyId, int subjectId) throws SQLException {

        java.util.List<String[]> results = new java.util.ArrayList<>();

        String sql = """
        SELECT DISTINCT st.id, st.roll_no, st.name
        FROM students st
        JOIN subjects s
            ON s.course_id = st.course_id
            AND s.semester = st.semester
        JOIN timetable t
            ON t.subject_id = s.id
            AND t.course_id = st.course_id
        WHERE t.faculty_id = ?
          AND s.id = ?
        ORDER BY st.roll_no
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, facultyId);
            stmt.setInt(2, subjectId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.add(new String[]{
                            String.valueOf(rs.getInt("id")),
                            rs.getString("roll_no"),
                            rs.getString("name")
                    });
                }
            }
        }

        return results;
    }


    public void saveForFaculty(int facultyId, Attendance a)
            throws SQLException {

        String sql = """
        INSERT INTO attendance
            (student_id, subject_id, date, present)
        SELECT st.id, s.id, ?, ?
        FROM students st
        JOIN subjects s
            ON s.course_id = st.course_id
            AND s.semester = st.semester
        JOIN timetable t
            ON t.subject_id = s.id
            AND t.course_id = st.course_id
        WHERE st.id = ?
          AND s.id = ?
          AND t.faculty_id = ?
        LIMIT 1
        ON DUPLICATE KEY UPDATE present = VALUES(present)
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, Date.valueOf(a.date()));
            stmt.setBoolean(2, a.present());
            stmt.setInt(3, a.studentId());
            stmt.setInt(4, a.subjectId());
            stmt.setInt(5, facultyId);

            if (stmt.executeUpdate() == 0) {
                throw new SQLException(
                        "Student or subject is not assigned to this faculty member."
                );
            }
        }
    }

}
