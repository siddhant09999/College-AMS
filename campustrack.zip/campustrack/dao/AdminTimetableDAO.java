
package com.college.campustrack.dao;

import com.college.campustrack.UserSession;
import com.college.campustrack.model.User;
import com.college.campustrack.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class AdminTimetableDAO {

    private void requireAdmin() {
        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            throw new SecurityException(
                    "Only administrators can modify the timetable."
            );
        }
    }

    public List<String[]> getCourses() throws SQLException {
        List<String[]> result = new ArrayList<>();

        String sql = "SELECT id, name FROM courses ORDER BY name";

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("name")
                });
            }
        }

        return result;
    }

    public List<String[]> getSubjects(int courseId)
            throws SQLException {

        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT id, name, semester
                FROM subjects
                WHERE course_id = ?
                ORDER BY semester, name
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, courseId);

            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    result.add(new String[]{
                            String.valueOf(r.getInt("id")),
                            r.getString("name"),
                            String.valueOf(r.getInt("semester"))
                    });
                }
            }
        }

        return result;
    }

    public List<String[]> getFaculty() throws SQLException {
        List<String[]> result = new ArrayList<>();

        String sql = "SELECT id, name FROM faculty ORDER BY name";

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("name")
                });
            }
        }

        return result;
    }

    public List<String[]> getTimetable() throws SQLException {
        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT t.id,
                       c.name AS course_name,
                       s.name AS subject_name,
                       s.semester,
                       f.name AS faculty_name,
                       t.day_of_week,
                       t.start_time,
                       t.end_time,
                       t.classroom,
                       t.course_id,
                       t.subject_id,
                       t.faculty_id
                FROM timetable t
                JOIN courses c ON c.id = t.course_id
                JOIN subjects s ON s.id = t.subject_id
                JOIN faculty f ON f.id = t.faculty_id
                ORDER BY c.name,
                         s.semester,
                         FIELD(t.day_of_week,
                               'Monday', 'Tuesday', 'Wednesday',
                               'Thursday', 'Friday', 'Saturday',
                               'Sunday'),
                         t.start_time
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("course_name"),
                        r.getString("subject_name"),
                        String.valueOf(r.getInt("semester")),
                        r.getString("faculty_name"),
                        r.getString("day_of_week"),
                        r.getTime("start_time").toLocalTime().toString(),
                        r.getTime("end_time").toLocalTime().toString(),
                        r.getString("classroom"),
                        String.valueOf(r.getInt("course_id")),
                        String.valueOf(r.getInt("subject_id")),
                        String.valueOf(r.getInt("faculty_id"))
                });
            }
        }

        return result;
    }

    public void addClass(
            int courseId,
            int subjectId,
            int facultyId,
            String day,
            LocalTime start,
            LocalTime end,
            String classroom
    ) throws SQLException {

        requireAdmin();

        saveClass(
                0, courseId, subjectId, facultyId,
                day, start, end, classroom, false
        );
    }

    public void updateClass(
            int timetableId,
            int courseId,
            int subjectId,
            int facultyId,
            String day,
            LocalTime start,
            LocalTime end,
            String classroom
    ) throws SQLException {

        requireAdmin();

        if (timetableId <= 0) {
            throw new IllegalArgumentException(
                    "Select a timetable entry to edit."
            );
        }

        saveClass(
                timetableId, courseId, subjectId, facultyId,
                day, start, end, classroom, true
        );
    }

    private void saveClass(
            int timetableId,
            int courseId,
            int subjectId,
            int facultyId,
            String day,
            LocalTime start,
            LocalTime end,
            String classroom,
            boolean editing
    ) throws SQLException {

        if (courseId <= 0 || subjectId <= 0 || facultyId <= 0) {
            throw new IllegalArgumentException(
                    "Course, subject and faculty are required."
            );
        }

        if (day == null || !List.of(
                "Monday", "Tuesday", "Wednesday",
                "Thursday", "Friday", "Saturday"
        ).contains(day)) {
            throw new IllegalArgumentException(
                    "Select a valid day."
            );
        }

        if (start == null || end == null || !start.isBefore(end)) {
            throw new IllegalArgumentException(
                    "Start time must be before end time."
            );
        }

        if (classroom == null || classroom.isBlank()) {
            throw new IllegalArgumentException(
                    "Classroom is required."
            );
        }

        String room = classroom.trim();

        String subjectCheck = """
                SELECT id
                FROM subjects
                WHERE id = ? AND course_id = ?
                """;

        String conflictCheck = """
                SELECT COUNT(*)
                FROM timetable t
                JOIN subjects existing_subject
                  ON existing_subject.id = t.subject_id
                WHERE t.id <> ?
                  AND t.day_of_week = ?
                  AND t.start_time < ?
                  AND t.end_time > ?
                  AND (
                      t.faculty_id = ?
                      OR (
                          t.course_id = ?
                          AND existing_subject.semester = (
                              SELECT semester
                              FROM subjects
                              WHERE id = ?
                          )
                      )
                      OR LOWER(TRIM(t.classroom)) = LOWER(?)
                  )
                """;

        String insertSql = """
                INSERT INTO timetable
                (course_id, subject_id, faculty_id,
                 day_of_week, start_time, end_time, classroom)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        String updateSql = """
                UPDATE timetable
                SET course_id = ?,
                    subject_id = ?,
                    faculty_id = ?,
                    day_of_week = ?,
                    start_time = ?,
                    end_time = ?,
                    classroom = ?
                WHERE id = ?
                """;

        try (Connection c = DatabaseConnection.getConnection()) {

            c.setAutoCommit(false);

            try {
                // Lock the timetable row when editing.
                if (editing) {
                    try (PreparedStatement p = c.prepareStatement(
                            "SELECT id FROM timetable " +
                                    "WHERE id = ? FOR UPDATE")) {

                        p.setInt(1, timetableId);

                        try (ResultSet r = p.executeQuery()) {
                            if (!r.next()) {
                                throw new SQLException(
                                        "Timetable entry not found."
                                );
                            }
                        }
                    }
                }

                try (PreparedStatement p =
                             c.prepareStatement(subjectCheck)) {

                    p.setInt(1, subjectId);
                    p.setInt(2, courseId);

                    try (ResultSet r = p.executeQuery()) {
                        if (!r.next()) {
                            throw new SQLException(
                                    "Subject does not belong to " +
                                            "the selected course."
                            );
                        }
                    }
                }

                try (PreparedStatement p =
                             c.prepareStatement(conflictCheck)) {

                    p.setInt(1, editing ? timetableId : 0);
                    p.setString(2, day);
                    p.setTime(3, Time.valueOf(end));
                    p.setTime(4, Time.valueOf(start));
                    p.setInt(5, facultyId);
                    p.setInt(6, courseId);
                    p.setInt(7, subjectId);
                    p.setString(8, room);

                    try (ResultSet r = p.executeQuery()) {
                        if (r.next() && r.getInt(1) > 0) {
                            throw new SQLException(
                                    "Schedule conflict: faculty, " +
                                            "course/semester, or classroom " +
                                            "is already occupied."
                            );
                        }
                    }
                }

                try (PreparedStatement p = c.prepareStatement(
                        editing ? updateSql : insertSql)) {

                    p.setInt(1, courseId);
                    p.setInt(2, subjectId);
                    p.setInt(3, facultyId);
                    p.setString(4, day);
                    p.setTime(5, Time.valueOf(start));
                    p.setTime(6, Time.valueOf(end));
                    p.setString(7, room);

                    if (editing) {
                        p.setInt(8, timetableId);
                    }

                    int rows = p.executeUpdate();

                    if (rows != 1) {
                        throw new SQLException(
                                "Unable to save timetable entry."
                        );
                    }
                }

                c.commit();

            } catch (Exception e) {
                c.rollback();

                if (e instanceof SQLException sqlException) {
                    throw sqlException;
                }

                if (e instanceof RuntimeException runtimeException) {
                    throw runtimeException;
                }

                throw new SQLException(
                        "Unable to save timetable entry.", e
                );
            }
        }
    }

    public void deleteClass(int timetableId) throws SQLException {

        requireAdmin();

        if (timetableId <= 0) {
            throw new IllegalArgumentException(
                    "Select a timetable entry to delete."
            );
        }

        String sql = "DELETE FROM timetable WHERE id = ?";

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, timetableId);

            if (p.executeUpdate() != 1) {
                throw new SQLException(
                        "Timetable entry not found."
                );
            }
        }
    }
}
