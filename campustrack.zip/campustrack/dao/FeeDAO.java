package com.college.campustrack.dao;

import com.college.campustrack.util.DatabaseConnection;import java.math.BigDecimal;import java.sql.*;
public class FeeDAO{public void create(int studentId,String type,BigDecimal amount,BigDecimal paid,Date due)throws SQLException{String q="INSERT INTO fees(student_id,fee_type,amount,paid_amount,due_date,status) VALUES(?,?,?,?,?,?)";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,studentId);p.setString(2,type);p.setBigDecimal(3,amount);p.setBigDecimal(4,paid);p.setDate(5,due);p.setString(6,status(amount,paid));p.executeUpdate();}}public void pay(int id,BigDecimal amount)throws SQLException{String q="UPDATE fees SET paid_amount=paid_amount+?,status=CASE WHEN paid_amount+? >= amount THEN 'PAID' ELSE 'PARTIAL' END WHERE id=?";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){p.setBigDecimal(1,amount);p.setBigDecimal(2,amount);p.setInt(3,id);p.executeUpdate();}}private String status(BigDecimal a,BigDecimal p){int x=p.compareTo(a);return x>=0?"PAID":p.signum()>0?"PARTIAL":"PENDING";}


    public java.util.List<String[]> getFeesForStudent(int studentId)
            throws SQLException {

        java.util.List<String[]> results = new java.util.ArrayList<>();

        String sql = """
        SELECT fee_type, amount, paid_amount, status
        FROM fees
        WHERE student_id = ?
        ORDER BY id
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {

                    String feeType = rs.getString("fee_type");
                    BigDecimal amount = rs.getBigDecimal("amount");
                    BigDecimal paid = rs.getBigDecimal("paid_amount");
                    String status = rs.getString("status");

                    results.add(new String[]{
                            feeType,
                            amount.toPlainString(),
                            paid.toPlainString(),
                            status
                    });
                }
            }
        }

        return results;
    }

}

