package com.college.campustrack.dao;

import com.college.campustrack.model.Student;
import com.college.campustrack.util.DatabaseConnection;
import java.sql.*;
import java.util.*;

public class StudentDAO {
    private Student map(ResultSet r)throws SQLException{return new Student(r.getInt("id"),r.getString("roll_no"),r.getString("name"),r.getString("email"),r.getString("phone"),r.getInt("department_id"),r.getInt("course_id"),r.getInt("semester"),r.getString("division"),r.getInt("admission_year"));}
    public int create(Student s)throws SQLException{String q="INSERT INTO students(roll_no,name,email,phone,department_id,course_id,semester,division,admission_year) VALUES(?,?,?,?,?,?,?,?,?)";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q,Statement.RETURN_GENERATED_KEYS)){set(p,s);p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){r.next();return r.getInt(1);}}}
    private void set(PreparedStatement p,Student s)throws SQLException{p.setString(1,s.rollNo());p.setString(2,s.name());p.setString(3,s.email());p.setString(4,s.phone());p.setInt(5,s.departmentId());p.setInt(6,s.courseId());p.setInt(7,s.semester());p.setString(8,s.division());p.setInt(9,s.admissionYear());}
    public void update(Student s)throws SQLException{String q="UPDATE students SET roll_no=?,name=?,email=?,phone=?,department_id=?,course_id=?,semester=?,division=?,admission_year=? WHERE id=?";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){set(p,s);p.setInt(10,s.id());p.executeUpdate();}}
    public void delete(int id)throws SQLException{try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM students WHERE id=?")){p.setInt(1,id);p.executeUpdate();}}
    public Student findById(int id)throws SQLException{try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM students WHERE id=?")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}}}
    public List<Student> search(String text)throws SQLException{List<Student> out=new ArrayList<>();String q="SELECT * FROM students WHERE roll_no LIKE ? OR name LIKE ? OR email LIKE ? ORDER BY name";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){String x="%"+text+"%";p.setString(1,x);p.setString(2,x);p.setString(3,x);try(ResultSet r=p.executeQuery()){while(r.next())out.add(map(r));}}return out;}


    public String[] getDepartmentAndCourseNames(int studentId)
            throws SQLException {

        String sql = """
        SELECT d.name AS department_name,
               c.name AS course_name
        FROM students s
        JOIN departments d ON s.department_id = d.id
        JOIN courses c ON s.course_id = c.id
        WHERE s.id = ?
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new String[] {
                            rs.getString("department_name"),
                            rs.getString("course_name")
                    };
                }
            }
        }

        return null;
    }

}
