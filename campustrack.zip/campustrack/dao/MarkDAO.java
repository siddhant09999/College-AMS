package com.college.campustrack.dao;

import com.college.campustrack.model.Mark;import com.college.campustrack.util.DatabaseConnection;import java.sql.*;
public class MarkDAO{public void save(Mark m)throws SQLException{String q="INSERT INTO marks(student_id,subject_id,exam_id,marks) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE marks=VALUES(marks)";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,m.studentId());p.setInt(2,m.subjectId());p.setInt(3,m.examId());p.setDouble(4,m.marks());p.executeUpdate();}}


    public java.util.List<String[]> getMarksForStudent(int studentId)
            throws SQLException {

        java.util.List<String[]> results = new java.util.ArrayList<>();

        String sql = """
        SELECT
            s.name AS subject_name,
            e.name AS exam_name,
            m.marks AS obtained_marks,
            e.max_marks AS maximum_marks
        FROM marks m
        JOIN subjects s ON m.subject_id = s.id
        JOIN exams e ON m.exam_id = e.id
        WHERE m.student_id = ?
        ORDER BY e.exam_date DESC, s.name
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {

                    String subject = rs.getString("subject_name");
                    String exam = rs.getString("exam_name");

                    double obtained = rs.getDouble("obtained_marks");
                    int maximum = rs.getInt("maximum_marks");

                    double percentage = maximum > 0
                            ? obtained * 100.0 / maximum
                            : 0;

                    String grade = maximum > 0
                            ? com.college.campustrack.service.MarkService
                            .grade(percentage)
                            : "N/A";

                    results.add(new String[]{
                            subject,
                            exam,
                            String.format("%.1f / %d", obtained, maximum),
                            grade
                    });
                }
            }
        }

        return results;
    }


    public java.util.List<String[]> getExamsForSubject(int subjectId)
            throws SQLException {

        java.util.List<String[]> results = new java.util.ArrayList<>();

        String sql = """
        SELECT e.id, e.name, e.max_marks
        FROM exams e
        JOIN subjects s ON s.semester = e.semester
        WHERE s.id = ?
        ORDER BY e.exam_date DESC
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, subjectId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.add(new String[]{
                            String.valueOf(rs.getInt("id")),
                            rs.getString("name"),
                            String.valueOf(rs.getInt("max_marks"))
                    });
                }
            }
        }

        return results;
    }

    public java.util.Map<Integer, Double> getExistingMarks(
            int subjectId, int examId) throws SQLException {

        java.util.Map<Integer, Double> results =
                new java.util.HashMap<>();

        String sql = """
        SELECT student_id, marks
        FROM marks
        WHERE subject_id = ? AND exam_id = ?
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, subjectId);
            stmt.setInt(2, examId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.put(
                            rs.getInt("student_id"),
                            rs.getDouble("marks")
                    );
                }
            }
        }

        return results;
    }

    public void saveForFaculty(int facultyId, Mark mark)
            throws SQLException {

        String sql = """
        INSERT INTO marks
            (student_id, subject_id, exam_id, marks)
        SELECT st.id, s.id, e.id, ?
        FROM students st
        JOIN subjects s
            ON s.course_id = st.course_id
            AND s.semester = st.semester
        JOIN timetable t
            ON t.subject_id = s.id
            AND t.course_id = st.course_id
        JOIN exams e
            ON e.semester = s.semester
        WHERE st.id = ?
          AND s.id = ?
          AND e.id = ?
          AND t.faculty_id = ?
          AND ? >= 0
          AND ? <= e.max_marks
        LIMIT 1
        ON DUPLICATE KEY UPDATE marks = VALUES(marks)
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, mark.marks());
            stmt.setInt(2, mark.studentId());
            stmt.setInt(3, mark.subjectId());
            stmt.setInt(4, mark.examId());
            stmt.setInt(5, facultyId);
            stmt.setDouble(6, mark.marks());
            stmt.setDouble(7, mark.marks());

            if (stmt.executeUpdate() == 0) {
                throw new SQLException(
                        "Marks unchanged, invalid, or faculty not authorized."
                );
            }
        }
    }

}

