
package com.college.campustrack.dao;

import com.college.campustrack.UserSession;
import com.college.campustrack.model.User;
import com.college.campustrack.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminAcademicDAO {

    private void requireAdmin() {
        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            throw new SecurityException(
                    "Only administrators can modify academic records."
            );
        }
    }

    public List<String[]> getDepartments() throws SQLException {
        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT id, name, code
                FROM departments
                ORDER BY name
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("name"),
                        r.getString("code")
                });
            }
        }

        return result;
    }

    public List<String[]> getCourses() throws SQLException {
        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT c.id, c.name, c.code,
                       d.name AS department,
                       c.department_id,
                       c.duration_years
                FROM courses c
                JOIN departments d ON d.id = c.department_id
                ORDER BY d.name, c.name
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("name"),
                        r.getString("code"),
                        r.getString("department"),
                        String.valueOf(r.getInt("department_id")),
                        String.valueOf(r.getInt("duration_years"))
                });
            }
        }

        return result;
    }

    public List<String[]> getSubjects() throws SQLException {
        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT s.id, s.name, s.code,
                       c.name AS course,
                       s.semester, s.credits,
                       s.course_id
                FROM subjects s
                JOIN courses c ON c.id = s.course_id
                ORDER BY c.name, s.semester, s.name
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                result.add(new String[]{
                        String.valueOf(r.getInt("id")),
                        r.getString("name"),
                        r.getString("code"),
                        r.getString("course"),
                        String.valueOf(r.getInt("semester")),
                        String.valueOf(r.getInt("credits")),
                        String.valueOf(r.getInt("course_id"))
                });
            }
        }

        return result;
    }

    public void addDepartment(String name, String code)
            throws SQLException {

        requireAdmin();
        validateText(name, code);

        String sql = """
                INSERT INTO departments(name, code)
                VALUES(?, ?)
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, name.trim());
            p.setString(2, normalizeCode(code));
            p.executeUpdate();
        }
    }

    public void updateDepartment(int id, String name, String code)
            throws SQLException {

        requireAdmin();
        validateId(id);
        validateText(name, code);

        String sql = """
                UPDATE departments
                SET name = ?, code = ?
                WHERE id = ?
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, name.trim());
            p.setString(2, normalizeCode(code));
            p.setInt(3, id);

            ensureUpdated(p.executeUpdate(), "Branch");
        }
    }

    public void deleteDepartment(int id) throws SQLException {
        requireAdmin();
        validateId(id);

        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);

            try {
                lockRecord(c, "departments", id, "Branch");

                ensureNoReferences(c, "courses", "department_id", id,
                        "courses");
                ensureNoReferences(c, "students", "department_id", id,
                        "students");
                ensureNoReferences(c, "faculty", "department_id", id,
                        "faculty");

                deleteRecord(c, "departments", id, "Branch");
                c.commit();

            } catch (Exception e) {
                c.rollback();
                throwAsSqlException(e);
            }
        }
    }

    public void addCourse(
            String name,
            String code,
            int departmentId,
            int durationYears
    ) throws SQLException {

        requireAdmin();
        validateText(name, code);
        validateId(departmentId);
        validateDuration(durationYears);

        String sql = """
                INSERT INTO courses
                (name, code, department_id, duration_years)
                VALUES(?, ?, ?, ?)
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, name.trim());
            p.setString(2, normalizeCode(code));
            p.setInt(3, departmentId);
            p.setInt(4, durationYears);
            p.executeUpdate();
        }
    }

    public void updateCourse(
            int id,
            String name,
            String code,
            int departmentId,
            int durationYears
    ) throws SQLException {

        requireAdmin();
        validateId(id);
        validateText(name, code);
        validateId(departmentId);
        validateDuration(durationYears);

        String sql = """
                UPDATE courses
                SET name = ?, code = ?,
                    department_id = ?, duration_years = ?
                WHERE id = ?
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, name.trim());
            p.setString(2, normalizeCode(code));
            p.setInt(3, departmentId);
            p.setInt(4, durationYears);
            p.setInt(5, id);

            ensureUpdated(p.executeUpdate(), "Course");
        }
    }

    public void deleteCourse(int id) throws SQLException {
        requireAdmin();
        validateId(id);

        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);

            try {
                lockRecord(c, "courses", id, "Course");

                ensureNoReferences(c, "students", "course_id", id,
                        "students");
                ensureNoReferences(c, "subjects", "course_id", id,
                        "subjects");
                ensureNoReferences(c, "timetable", "course_id", id,
                        "timetable classes");

                deleteRecord(c, "courses", id, "Course");
                c.commit();

            } catch (Exception e) {
                c.rollback();
                throwAsSqlException(e);
            }
        }
    }

    public void addSubject(
            String name,
            String code,
            int courseId,
            int semester,
            int credits
    ) throws SQLException {

        requireAdmin();
        validateText(name, code);
        validateId(courseId);
        validateSubjectValues(semester, credits);

        String sql = """
                INSERT INTO subjects
                (name, code, course_id, semester, credits)
                VALUES(?, ?, ?, ?, ?)
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, name.trim());
            p.setString(2, normalizeCode(code));
            p.setInt(3, courseId);
            p.setInt(4, semester);
            p.setInt(5, credits);
            p.executeUpdate();
        }
    }

    public void updateSubject(
            int id,
            String name,
            String code,
            int courseId,
            int semester,
            int credits
    ) throws SQLException {

        requireAdmin();
        validateId(id);
        validateText(name, code);
        validateId(courseId);
        validateSubjectValues(semester, credits);

        String sql = """
                UPDATE subjects
                SET name = ?, code = ?, course_id = ?,
                    semester = ?, credits = ?
                WHERE id = ?
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, name.trim());
            p.setString(2, normalizeCode(code));
            p.setInt(3, courseId);
            p.setInt(4, semester);
            p.setInt(5, credits);
            p.setInt(6, id);

            ensureUpdated(p.executeUpdate(), "Subject");
        }
    }

    public void deleteSubject(int id) throws SQLException {
        requireAdmin();
        validateId(id);

        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);

            try {
                lockRecord(c, "subjects", id, "Subject");

                ensureNoReferences(c, "attendance", "subject_id", id,
                        "attendance records");
                ensureNoReferences(c, "marks", "subject_id", id,
                        "marks records");
                ensureNoReferences(c, "timetable", "subject_id", id,
                        "timetable classes");

                deleteRecord(c, "subjects", id, "Subject");
                c.commit();

            } catch (Exception e) {
                c.rollback();
                throwAsSqlException(e);
            }
        }
    }

    private void lockRecord(
            Connection c,
            String table,
            int id,
            String label
    ) throws SQLException {

        String sql = "SELECT id FROM " + table +
                " WHERE id = ? FOR UPDATE";

        try (PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id);

            try (ResultSet r = p.executeQuery()) {
                if (!r.next()) {
                    throw new SQLException(label + " not found.");
                }
            }
        }
    }

    private void ensureNoReferences(
            Connection c,
            String table,
            String column,
            int id,
            String description
    ) throws SQLException {

        String sql = "SELECT 1 FROM " + table +
                " WHERE " + column + " = ? LIMIT 1";

        try (PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id);

            try (ResultSet r = p.executeQuery()) {
                if (r.next()) {
                    throw new SQLException(
                            "Cannot delete: linked " + description +
                                    " exist."
                    );
                }
            }
        }
    }

    private void deleteRecord(
            Connection c,
            String table,
            int id,
            String label
    ) throws SQLException {

        String sql = "DELETE FROM " + table + " WHERE id = ?";

        try (PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id);
            ensureUpdated(p.executeUpdate(), label);
        }
    }

    private void ensureUpdated(int rows, String label)
            throws SQLException {

        if (rows == 0) {
            throw new SQLException(
                    label + " not found or no changes were saved."
            );
        }
    }

    private void validateId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException(
                    "Please select a valid record."
            );
        }
    }

    private void validateText(String name, String code) {
        if (name == null || name.isBlank()
                || code == null || code.isBlank()) {
            throw new IllegalArgumentException(
                    "Name and code are required."
            );
        }
    }

    private void validateDuration(int years) {
        if (years < 1 || years > 10) {
            throw new IllegalArgumentException(
                    "Duration must be between 1 and 10 years."
            );
        }
    }

    private void validateSubjectValues(int semester, int credits) {
        if (semester < 1 || semester > 8) {
            throw new IllegalArgumentException(
                    "Semester must be between 1 and 8."
            );
        }

        if (credits < 1 || credits > 10) {
            throw new IllegalArgumentException(
                    "Credits must be between 1 and 10."
            );
        }
    }

    private String normalizeCode(String code) {
        return code.trim().toUpperCase(Locale.ROOT);
    }

    private void throwAsSqlException(Exception e)
            throws SQLException {

        if (e instanceof SQLException sqlException) {
            throw sqlException;
        }

        if (e instanceof RuntimeException runtimeException) {
            throw runtimeException;
        }

        throw new SQLException("Academic operation failed.", e);
    }
}
