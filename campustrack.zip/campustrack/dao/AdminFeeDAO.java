
package com.college.campustrack.dao;

import com.college.campustrack.UserSession;
import com.college.campustrack.model.User;
import com.college.campustrack.util.DatabaseConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AdminFeeDAO {

    private void requireAdmin() {
        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            throw new SecurityException(
                    "Only administrators can manage fees."
            );
        }
    }

    public List<String[]> searchStudents(String search)
            throws SQLException {

        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT id, roll_no, name
                FROM students
                WHERE roll_no LIKE ? OR name LIKE ?
                ORDER BY name
                LIMIT 100
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            String pattern = "%" +
                    (search == null ? "" : search.trim()) + "%";

            p.setString(1, pattern);
            p.setString(2, pattern);

            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    result.add(new String[]{
                            String.valueOf(r.getInt("id")),
                            r.getString("roll_no"),
                            r.getString("name")
                    });
                }
            }
        }

        return result;
    }

    public List<String[]> getFees(int studentId)
            throws SQLException {

        List<String[]> result = new ArrayList<>();

        String sql = """
                SELECT id, fee_type, amount, paid_amount,
                       due_date, status
                FROM fees
                WHERE student_id = ?
                ORDER BY id DESC
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, studentId);

            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    result.add(new String[]{
                            String.valueOf(r.getInt("id")),
                            r.getString("fee_type"),
                            r.getBigDecimal("amount").toPlainString(),
                            r.getBigDecimal("paid_amount").toPlainString(),
                            r.getDate("due_date").toString(),
                            r.getString("status")
                    });
                }
            }
        }

        return result;
    }

    public void assignFee(
            int studentId,
            String feeType,
            BigDecimal amount,
            LocalDate dueDate
    ) throws SQLException {

        requireAdmin();
        validateFee(feeType, amount, dueDate);

        if (studentId <= 0) {
            throw new IllegalArgumentException(
                    "Please select a student."
            );
        }

        String sql = """
                INSERT INTO fees
                (student_id, fee_type, amount,
                 paid_amount, due_date, status)
                VALUES (?, ?, ?, 0.00, ?, 'PENDING')
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, studentId);
            p.setString(2, feeType.trim());
            p.setBigDecimal(3, amount);
            p.setDate(4, Date.valueOf(dueDate));

            p.executeUpdate();
        }
    }

    public void updateFee(
            int feeId,
            int studentId,
            String feeType,
            BigDecimal amount,
            LocalDate dueDate
    ) throws SQLException {

        requireAdmin();
        validateFee(feeType, amount, dueDate);

        if (feeId <= 0 || studentId <= 0) {
            throw new IllegalArgumentException(
                    "Select a valid fee record."
            );
        }

        try (Connection c = DatabaseConnection.getConnection()) {

            c.setAutoCommit(false);

            try {
                BigDecimal paid;

                String checkSql = """
                        SELECT paid_amount
                        FROM fees
                        WHERE id = ? AND student_id = ?
                        FOR UPDATE
                        """;

                try (PreparedStatement p = c.prepareStatement(checkSql)) {
                    p.setInt(1, feeId);
                    p.setInt(2, studentId);

                    try (ResultSet r = p.executeQuery()) {
                        if (!r.next()) {
                            throw new SQLException(
                                    "Fee record not found for this student."
                            );
                        }

                        paid = r.getBigDecimal("paid_amount");
                    }
                }

                if (amount.compareTo(paid) < 0) {
                    throw new SQLException(
                            "Fee amount cannot be less than the " +
                                    "amount already paid (" +
                                    paid.toPlainString() + ")."
                    );
                }

                String status;

                if (paid.signum() == 0) {
                    status = "PENDING";
                } else if (paid.compareTo(amount) == 0) {
                    status = "PAID";
                } else {
                    status = "PARTIAL";
                }

                String updateSql = """
                        UPDATE fees
                        SET fee_type = ?,
                            amount = ?,
                            due_date = ?,
                            status = ?
                        WHERE id = ? AND student_id = ?
                        """;

                try (PreparedStatement p = c.prepareStatement(updateSql)) {
                    p.setString(1, feeType.trim());
                    p.setBigDecimal(2, amount);
                    p.setDate(3, Date.valueOf(dueDate));
                    p.setString(4, status);
                    p.setInt(5, feeId);
                    p.setInt(6, studentId);

                    p.executeUpdate();
                }

                c.commit();

            } catch (Exception e) {
                c.rollback();

                if (e instanceof SQLException sqlException) {
                    throw sqlException;
                }

                if (e instanceof RuntimeException runtimeException) {
                    throw runtimeException;
                }

                throw new SQLException(
                        "Unable to update fee.", e
                );
            }
        }
    }

    public void deleteUnpaidFee(
            int feeId,
            int studentId
    ) throws SQLException {

        requireAdmin();

        if (feeId <= 0 || studentId <= 0) {
            throw new IllegalArgumentException(
                    "Select a valid fee record."
            );
        }

        String sql = """
                DELETE FROM fees
                WHERE id = ?
                  AND student_id = ?
                  AND paid_amount = 0
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, feeId);
            p.setInt(2, studentId);

            if (p.executeUpdate() != 1) {
                throw new SQLException(
                        "Deletion blocked. Only unpaid fee records " +
                                "can be deleted."
                );
            }
        }
    }

    public void recordPayment(
            int feeId,
            BigDecimal payment
    ) throws SQLException {

        requireAdmin();
        validateMoney(payment, "Payment");

        if (feeId <= 0) {
            throw new IllegalArgumentException(
                    "Please select a fee."
            );
        }

        String sql = """
                UPDATE fees
                SET paid_amount = paid_amount + ?,
                    status = CASE
                        WHEN paid_amount + ? = amount
                            THEN 'PAID'
                        ELSE 'PARTIAL'
                    END
                WHERE id = ?
                  AND paid_amount + ? <= amount
                """;

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setBigDecimal(1, payment);
            p.setBigDecimal(2, payment);
            p.setInt(3, feeId);
            p.setBigDecimal(4, payment);

            if (p.executeUpdate() != 1) {
                throw new SQLException(
                        "Payment rejected. The fee may not exist, " +
                                "or the payment exceeds the remaining balance."
                );
            }
        }
    }

    private void validateFee(
            String feeType,
            BigDecimal amount,
            LocalDate dueDate
    ) {
        if (feeType == null || feeType.isBlank()) {
            throw new IllegalArgumentException(
                    "Fee type is required."
            );
        }

        if (feeType.trim().length() > 100) {
            throw new IllegalArgumentException(
                    "Fee type must be at most 100 characters."
            );
        }

        validateMoney(amount, "Fee amount");

        if (dueDate == null) {
            throw new IllegalArgumentException(
                    "Due date is required."
            );
        }
    }

    private void validateMoney(BigDecimal value, String label) {
        if (value == null
                || value.signum() <= 0
                || value.scale() > 2
                || value.precision() - value.scale() > 10) {

            throw new IllegalArgumentException(
                    label + " must be positive, with at most " +
                            "two decimal places."
            );
        }
    }
}
