package com.college.campustrack.dao;

import com.college.campustrack.model.User;
import com.college.campustrack.util.DatabaseConnection;
import java.sql.*;

public class UserDAO {
    public User findByUsername(String username) throws SQLException {
        String sql = "SELECT id, username, password_hash, role, student_id, faculty_id " +
                "FROM users WHERE username = ?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, username);
            try (ResultSet r = p.executeQuery()) {
                if (r.next()) {
                    return new User(r.getInt("id"), r.getString("username"),
                            r.getString("password_hash"), r.getString("role"),
                            (Integer) r.getObject("student_id"),
                            (Integer) r.getObject("faculty_id"));
                }
            }
        }
        return null;
    }

    public boolean isStudentActive(int studentId) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(
                     "SELECT is_active FROM students WHERE id = ?")) {
            p.setInt(1, studentId);
            try (ResultSet r = p.executeQuery()) {
                return r.next() && r.getBoolean("is_active");
            }
        }
    }

    public int create(String username, String passwordHash, String role,
                      Integer studentId, Integer facultyId) throws SQLException {
        String sql = "INSERT INTO users(username,password_hash,role,student_id,faculty_id) " +
                "VALUES(?,?,?,?,?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            p.setString(1, username);
            p.setString(2, passwordHash);
            p.setString(3, role);
            if (studentId == null) p.setNull(4, Types.INTEGER);
            else p.setInt(4, studentId);
            if (facultyId == null) p.setNull(5, Types.INTEGER);
            else p.setInt(5, facultyId);
            p.executeUpdate();
            try (ResultSet r = p.getGeneratedKeys()) {
                if (r.next()) return r.getInt(1);
            }
        }
        throw new SQLException("User creation failed");
    }
}
