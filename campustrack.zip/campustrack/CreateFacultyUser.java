
package com.college.campustrack;

import com.college.campustrack.service.AuthService;

public class CreateFacultyUser {

    public static void main(String[] args) {
        try {
            AuthService authService = new AuthService();

            int userId = authService.createUser(
                    "faculty1",
                    "faculty123",
                    "FACULTY",
                    null,
                    1
            );

            System.out.println(
                    "Faculty account created! User ID: " + userId
            );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
