
package com.college.campustrack;

import javafx.scene.Scene;

import java.net.URL;

public class StyleManager {

    public static void applyStyles(Scene scene) {

        URL css = StyleManager.class.getResource("/style.css");

        if (css == null) {
            System.err.println(
                    "CampusTrack warning: /style.css not found."
            );
            return;
        }

        String stylesheet = css.toExternalForm();

        // Avoid adding the same stylesheet more than once.
        if (!scene.getStylesheets().contains(stylesheet)) {
            scene.getStylesheets().add(stylesheet);
        }
    }
}
