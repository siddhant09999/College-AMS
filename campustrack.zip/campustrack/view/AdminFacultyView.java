
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AdminFacultyDAO;
import com.college.campustrack.dao.FacultyDAO;
import com.college.campustrack.model.Faculty;
import com.college.campustrack.model.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class AdminFacultyView {

    private final AdminFacultyDAO adminDAO =
            new AdminFacultyDAO();

    private final FacultyDAO facultyDAO =
            new FacultyDAO();

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            showAlert(
                    Alert.AlertType.ERROR,
                    "Please log in as an administrator."
            );
            return;
        }

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("ADMIN PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: #2563eb;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label title = new Label("Faculty Management");
        title.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Create, search, update, and manage faculty records."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox titleBox = new VBox(
                5, eyebrow, title, subtitle
        );

        Button back = new Button("← Back to Dashboard");

        back.setStyle(
                "-fx-background-color: white;" +
                        "-fx-text-fill: #14233e;" +
                        "-fx-font-weight: bold;" +
                        "-fx-border-color: #e2e8f0;" +
                        "-fx-border-radius: 9;" +
                        "-fx-background-radius: 9;" +
                        "-fx-padding: 11 16;"
        );

        back.setOnAction(e ->
                new AdminDashboardView().show(stage)
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                titleBox,
                headerSpacer,
                back
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= BANNER =================

        Label bannerTag = new Label(
                "ADMINISTRATION • FACULTY"
        );
        bannerTag.setStyle(
                "-fx-text-fill: #bfdbfe;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label bannerTitle = new Label(
                "Manage your teaching team."
        );
        bannerTitle.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Maintain faculty profiles, department assignments, " +
                        "and login accounts in one place."
        );
        bannerDescription.setStyle(
                "-fx-text-fill: #dbeafe;" +
                        "-fx-font-size: 13px;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);

        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, #14233e, #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= FORM CONTROLS =================

        TextField employeeNo = new TextField();
        TextField name = new TextField();
        TextField email = new TextField();
        TextField phone = new TextField();
        TextField username = new TextField();
        PasswordField password = new PasswordField();

        employeeNo.setPromptText("Enter employee number");
        name.setPromptText("Enter full name");
        email.setPromptText("Enter email address");
        phone.setPromptText("Enter phone number");
        username.setPromptText("Create login username");
        password.setPromptText("Create login password");

        ComboBox<String> department = new ComboBox<>();
        department.setPromptText("Select branch");

        // ================= LOAD BRANCHES =================

        try {

            for (String[] d : adminDAO.getDepartments()) {
                department.getItems().add(
                        d[0] + " - " + d[1]
                );
            }

        } catch (Exception e) {

            showAlert(
                    Alert.AlertType.ERROR,
                    "Unable to load branches: "
                            + e.getMessage()
            );
        }

        // ================= FORM MODE =================

        Label mode = new Label("CREATE NEW FACULTY");

        mode.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 9 14;" +
                        "-fx-background-radius: 16;"
        );

        Label formTitle = new Label("Faculty Details");
        formTitle.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label formDescription = new Label(
                "Enter personal, department, and account information."
        );
        formDescription.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        // ================= PERSONAL INFORMATION =================

        GridPane personalGrid = new GridPane();
        personalGrid.setHgap(18);
        personalGrid.setVgap(16);

        addField(
                personalGrid, 0, 0,
                "EMPLOYEE NUMBER", employeeNo
        );

        addField(
                personalGrid, 1, 0,
                "FULL NAME", name
        );

        addField(
                personalGrid, 0, 1,
                "EMAIL", email
        );

        addField(
                personalGrid, 1, 1,
                "PHONE", phone
        );

        // ================= DEPARTMENT INFORMATION =================

        GridPane departmentGrid = new GridPane();
        departmentGrid.setHgap(18);
        departmentGrid.setVgap(16);

        addField(
                departmentGrid, 0, 0,
                "BRANCH / DEPARTMENT", department
        );

        // ================= LOGIN INFORMATION =================

        GridPane accountGrid = new GridPane();
        accountGrid.setHgap(18);
        accountGrid.setVgap(16);

        addField(
                accountGrid, 0, 0,
                "LOGIN USERNAME", username
        );

        addField(
                accountGrid, 1, 0,
                "LOGIN PASSWORD", password
        );

        Label accountHint = new Label(
                "Login credentials are created with new faculty. " +
                        "They are not changed when editing faculty details."
        );
        accountHint.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 11px;"
        );
        accountHint.setWrapText(true);

        // ================= ACTION BUTTONS =================

        Button create = new Button(
                "Create Faculty & Login"
        );

        Button update = new Button("Save Changes");
        Button delete = new Button("Delete Faculty");
        Button clear = new Button("Clear / New Faculty");

        create.setStyle(primaryButtonStyle());
        update.setStyle(primaryButtonStyle());

        delete.setStyle(
                "-fx-background-color: #fee2e2;" +
                        "-fx-text-fill: #b91c1c;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;"
        );

        clear.setStyle(
                "-fx-background-color: #f1f5f9;" +
                        "-fx-text-fill: #334155;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;"
        );

        update.setDisable(true);
        delete.setDisable(true);

        HBox actions = new HBox(
                12,
                create,
                update,
                delete,
                clear
        );
        actions.setAlignment(Pos.CENTER_LEFT);
        actions.setPadding(new Insets(10, 0, 0, 0));

        VBox formCard = new VBox(
                22,
                mode,
                formTitle,
                formDescription,
                sectionLabel("Personal Information"),
                personalGrid,
                sectionLabel("Department Assignment"),
                departmentGrid,
                sectionLabel("Login Account"),
                accountHint,
                accountGrid,
                actions
        );

        formCard.getStyleClass().add("content-card");
        formCard.setMaxWidth(Double.MAX_VALUE);

        // ================= FACULTY RECORDS =================

        TextField search = new TextField();
        search.setPromptText(
                "Search by name, employee number or email"
        );
        search.setMaxWidth(Double.MAX_VALUE);

        TableView<Faculty> table = new TableView<>();

        TableColumn<Faculty, String> employeeColumn =
                new TableColumn<>("Employee No.");

        employeeColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().employeeNo()
                )
        );

        TableColumn<Faculty, String> nameColumn =
                new TableColumn<>("Name");

        nameColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().name()
                )
        );

        TableColumn<Faculty, String> emailColumn =
                new TableColumn<>("Email");

        emailColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().email()
                )
        );

        table.getColumns().addAll(
                employeeColumn,
                nameColumn,
                emailColumn
        );

        table.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        table.setPrefHeight(330);
        table.setMinHeight(260);

        table.setPlaceholder(
                new Label("No matching faculty found.")
        );

        Label recordsTitle = new Label(
                "Existing Faculty"
        );
        recordsTitle.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label recordsDescription = new Label(
                "Search faculty and select a row to edit or delete."
        );
        recordsDescription.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        VBox recordsCard = new VBox(
                18,
                recordsTitle,
                recordsDescription,
                search,
                table
        );

        recordsCard.getStyleClass().add("content-card");
        recordsCard.setMaxWidth(Double.MAX_VALUE);

        // ================= CREATE / EDIT STATE =================

        final Faculty[] selectedFaculty = {null};

        Runnable clearForm = () -> {

            selectedFaculty[0] = null;

            table.getSelectionModel().clearSelection();

            employeeNo.clear();
            name.clear();
            email.clear();
            phone.clear();

            department.setValue(null);

            username.clear();
            password.clear();

            username.setDisable(false);
            password.setDisable(false);

            create.setDisable(false);
            update.setDisable(true);
            delete.setDisable(true);

            mode.setText("CREATE NEW FACULTY");
        };

        // ================= SELECT FACULTY =================

        table.getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldValue, faculty) -> {

                    if (faculty == null) {
                        return;
                    }

                    selectedFaculty[0] = faculty;

                    employeeNo.setText(faculty.employeeNo());
                    name.setText(faculty.name());
                    email.setText(faculty.email());

                    phone.setText(
                            faculty.phone() == null
                                    ? ""
                                    : faculty.phone()
                    );

                    selectById(
                            department,
                            faculty.departmentId()
                    );

                    username.clear();
                    password.clear();

                    username.setDisable(true);
                    password.setDisable(true);

                    create.setDisable(true);
                    update.setDisable(false);
                    delete.setDisable(false);

                    mode.setText(
                            "EDITING: " + faculty.name()
                                    + " (ID " + faculty.id() + ")"
                    );
                });

        // ================= CREATE FACULTY =================

        create.setOnAction(event -> {

            try {

                Faculty faculty = buildFaculty(
                        0,
                        employeeNo,
                        name,
                        email,
                        phone,
                        department
                );

                int id = adminDAO.createFacultyWithAccount(
                        faculty,
                        username.getText(),
                        password.getText()
                );

                showAlert(
                        Alert.AlertType.INFORMATION,
                        "Faculty and login created! ID: " + id
                );

                clearForm.run();

                refreshFaculty(
                        search.getText(),
                        table
                );

            } catch (Exception e) {

                showAlert(
                        Alert.AlertType.ERROR,
                        "Creation failed: " + e.getMessage()
                );
            }
        });

        // ================= UPDATE FACULTY =================

        update.setOnAction(event -> {

            try {

                if (selectedFaculty[0] == null) {
                    return;
                }

                Faculty updated = buildFaculty(
                        selectedFaculty[0].id(),
                        employeeNo,
                        name,
                        email,
                        phone,
                        department
                );

                adminDAO.updateFaculty(updated);

                showAlert(
                        Alert.AlertType.INFORMATION,
                        "Faculty updated successfully!"
                );

                clearForm.run();

                refreshFaculty(
                        search.getText(),
                        table
                );

            } catch (Exception e) {

                showAlert(
                        Alert.AlertType.ERROR,
                        "Update failed: " + e.getMessage()
                );
            }
        });

        // ================= DELETE FACULTY =================

        delete.setOnAction(event -> {

            if (selectedFaculty[0] == null) {
                return;
            }

            Alert confirm = new Alert(
                    Alert.AlertType.CONFIRMATION,
                    "Delete " + selectedFaculty[0].name()
                            + " and their login account?\n\n"
                            + "Deletion is blocked if they have "
                            + "timetable assignments.",
                    ButtonType.YES,
                    ButtonType.NO
            );

            confirm.setTitle(
                    "Confirm Faculty Deletion"
            );

            if (confirm.showAndWait()
                    .orElse(ButtonType.NO)
                    != ButtonType.YES) {

                return;
            }

            try {

                adminDAO.deleteFaculty(
                        selectedFaculty[0].id()
                );

                showAlert(
                        Alert.AlertType.INFORMATION,
                        "Faculty deleted successfully."
                );

                clearForm.run();

                refreshFaculty(
                        search.getText(),
                        table
                );

            } catch (Exception e) {

                showAlert(
                        Alert.AlertType.ERROR,
                        "Deletion blocked: " + e.getMessage()
                );
            }
        });

        clear.setOnAction(event -> clearForm.run());

        // ================= LIVE SEARCH =================

        search.textProperty().addListener(
                (observable, oldValue, newValue) ->
                        refreshFaculty(
                                newValue,
                                table
                        )
        );

        refreshFaculty("", table);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Admin Faculty Management"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                formCard,
                recordsCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );

        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scroll = new ScrollPane(mainContent);
        scroll.setFitToWidth(true);

        scroll.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );

        Scene scene = new Scene(
                scroll,
                1120,
                750
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Faculty Management"
        );

        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= BUILD FACULTY =================

    private Faculty buildFaculty(
            int id,
            TextField employeeNo,
            TextField name,
            TextField email,
            TextField phone,
            ComboBox<String> department
    ) {

        if (department.getValue() == null) {

            throw new IllegalArgumentException(
                    "Please select a branch."
            );
        }

        return new Faculty(
                id,
                employeeNo.getText().trim(),
                name.getText().trim(),
                email.getText().trim(),
                phone.getText().trim(),
                getId(department.getValue())
        );
    }

    // ================= FORM FIELD =================

    private void addField(
            GridPane grid,
            int column,
            int row,
            String labelText,
            Control control
    ) {

        Label label = new Label(labelText);

        label.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        control.setMaxWidth(Double.MAX_VALUE);

        VBox field = new VBox(
                7,
                label,
                control
        );

        grid.add(field, column, row);

        if (grid.getColumnConstraints().isEmpty()) {

            ColumnConstraints left =
                    new ColumnConstraints();

            ColumnConstraints right =
                    new ColumnConstraints();

            left.setPercentWidth(50);
            right.setPercentWidth(50);

            grid.getColumnConstraints().addAll(
                    left,
                    right
            );
        }
    }

    // ================= SECTION LABEL =================

    private Label sectionLabel(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        return label;
    }

    // ================= PRIMARY BUTTON STYLE =================

    private String primaryButtonStyle() {

        return "-fx-background-color: #2563eb;" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 11 17;" +
                "-fx-background-radius: 9;";
    }

    // ================= SELECT BY ID =================

    private void selectById(
            ComboBox<String> box,
            int id
    ) {

        for (String item : box.getItems()) {

            if (getId(item) == id) {
                box.setValue(item);
                return;
            }
        }
    }

    // ================= PARSE ID =================

    private int getId(String value) {

        return Integer.parseInt(
                value.split(" - ", 2)[0]
        );
    }

    // ================= REFRESH FACULTY =================

    private void refreshFaculty(
            String query,
            TableView<Faculty> table
    ) {

        try {

            table.setItems(
                    FXCollections.observableArrayList(
                            facultyDAO.search(query)
                    )
            );

        } catch (Exception e) {

            showAlert(
                    Alert.AlertType.ERROR,
                    "Unable to load faculty: "
                            + e.getMessage()
            );
        }
    }

    // ================= ALERT =================

    private void showAlert(
            Alert.AlertType type,
            String message
    ) {

        Alert alert = new Alert(
                type,
                message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.showAndWait();
    }
}
