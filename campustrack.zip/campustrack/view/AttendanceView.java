
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AttendanceDAO;
import com.college.campustrack.model.User;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AttendanceView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"STUDENT".equals(user.role())
                || user.studentId() == null) {

            showError("Please log in as a student.");
            return;
        }

        // ================= LOAD ATTENDANCE =================

        List<String[]> summaries;

        try {
            summaries = new AttendanceDAO()
                    .getAttendanceSummary(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load attendance.");
            return;
        }

        // ================= CALCULATE SUMMARY =================

        int totalAttended = 0;
        int totalClasses = 0;

        List<SubjectAttendance> subjects = new ArrayList<>();

        try {
            for (String[] summary : summaries) {

                String subjectName = summary[0];
                int attended = Integer.parseInt(summary[1]);
                int total = Integer.parseInt(summary[2]);

                double percentage = total == 0
                        ? 0
                        : attended * 100.0 / total;

                subjects.add(
                        new SubjectAttendance(
                                subjectName,
                                attended,
                                total,
                                percentage
                        )
                );

                totalAttended += attended;
                totalClasses += total;
            }

        } catch (RuntimeException e) {
            e.printStackTrace();
            showError("Unable to read attendance information.");
            return;
        }

        double overallPercentage = totalClasses == 0
                ? 0
                : totalAttended * 100.0 / totalClasses;

        String overallText = totalClasses == 0
                ? "N/A"
                : formatPercentage(overallPercentage);

        // ================= SHARED SIDEBAR =================

        VBox sidebar = Sidebar.create(stage);
        sidebar.setPrefWidth(260);
        sidebar.setMinWidth(230);

        // ================= HEADER =================

        Label eyebrow = new Label("STUDENT PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("My Attendance");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Track your attendance across all subjects."
        );
        subtitle.getStyleClass().add("page-subtitle");

        VBox headerText = new VBox(
                5,
                eyebrow,
                heading,
                subtitle
        );

        Label badge = new Label("●  ATTENDANCE");
        badge.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10 14;" +
                        "-fx-background-radius: 20;"
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                headerText,
                headerSpacer,
                badge
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= SUMMARY BANNER =================

        Label bannerTag = new Label(
                "YOUR ACADEMIC ATTENDANCE"
        );
        bannerTag.setStyle(
                "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #bfdbfe;"
        );

        Label bannerValue = new Label(overallText);
        bannerValue.setStyle(
                "-fx-font-size: 38px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );

        Label bannerDescription = new Label(
                totalClasses == 0
                        ? "No attendance records are available yet."
                        : "Your overall attendance across recorded classes."
        );
        bannerDescription.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #dbeafe;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                8,
                bannerTag,
                bannerValue,
                bannerDescription
        );

        banner.setPadding(new Insets(26, 30, 26, 30));
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= STATISTICS CARDS =================

        VBox attendedCard = createStatCard(
                "AT",
                "Classes Attended",
                String.valueOf(totalAttended),
                "#dbeafe",
                "#1d4ed8"
        );

        VBox totalCard = createStatCard(
                "CL",
                "Total Classes",
                String.valueOf(totalClasses),
                "#dcfce7",
                "#15803d"
        );

        VBox subjectCard = createStatCard(
                "SB",
                "Subjects",
                String.valueOf(subjects.size()),
                "#f3e8ff",
                "#7e22ce"
        );

        HBox stats = new HBox(
                18,
                attendedCard,
                totalCard,
                subjectCard
        );

        for (VBox card : new VBox[]{
                attendedCard,
                totalCard,
                subjectCard
        }) {
            HBox.setHgrow(card, Priority.ALWAYS);
            card.setMaxWidth(Double.MAX_VALUE);

            card.prefWidthProperty().bind(
                    stats.widthProperty()
                            .subtract(36)
                            .divide(3)
            );
        }

        // ================= SUBJECT ATTENDANCE =================

        Label sectionTitle = new Label(
                "Subject-wise Attendance"
        );
        sectionTitle.getStyleClass().add("section-title");

        Label sectionSubtitle = new Label(
                "Attendance records for each subject."
        );
        sectionSubtitle.getStyleClass().add("page-subtitle");

        VBox sectionHeading = new VBox(
                4,
                sectionTitle,
                sectionSubtitle
        );

        VBox subjectList = new VBox(14);

        if (subjects.isEmpty()) {

            Label emptyTitle = new Label(
                    "No attendance information available"
            );
            emptyTitle.setStyle(
                    "-fx-font-size: 16px;" +
                            "-fx-font-weight: bold;" +
                            "-fx-text-fill: #14233e;"
            );

            Label emptyDescription = new Label(
                    "No subjects found for your course and semester."
            );
            emptyDescription.setStyle(
                    "-fx-font-size: 13px;" +
                            "-fx-text-fill: " + MUTED + ";"
            );
            emptyDescription.setWrapText(true);

            VBox emptyCard = new VBox(
                    10,
                    emptyTitle,
                    emptyDescription
            );
            emptyCard.getStyleClass().add("content-card");

            subjectList.getChildren().add(emptyCard);

        } else {

            for (SubjectAttendance subject : subjects) {

                subjectList.getChildren().add(
                        createSubjectCard(subject)
                );
            }
        }

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Student Attendance"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-padding: 10 0 0 0;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                stats,
                sectionHeading,
                subjectList,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );
        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT LAYOUT =================

        BorderPane root = new BorderPane();
        root.setLeft(sidebar);
        root.setCenter(scrollPane);

        Scene scene = new Scene(root, 1120, 720);
        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - My Attendance"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= STAT CARD =================

    private VBox createStatCard(
            String initials,
            String title,
            String value,
            String iconBackground,
            String iconColor
    ) {

        Label icon = new Label(initials);
        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(42, 42);
        icon.setPrefSize(42, 42);
        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 11;"
        );

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;" +
                        "-fx-font-weight: bold;"
        );

        Label valueLabel = new Label(value);
        valueLabel.setStyle(
                "-fx-font-size: 27px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        VBox card = new VBox(
                14,
                icon,
                titleLabel,
                valueLabel
        );

        card.getStyleClass().add("dashboard-card");
        card.setPadding(new Insets(22));
        card.setMinHeight(155);
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= SUBJECT CARD =================

    private VBox createSubjectCard(
            SubjectAttendance subject
    ) {

        Label nameLabel = new Label(subject.name());
        nameLabel.setStyle(
                "-fx-font-size: 15px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );
        nameLabel.setWrapText(true);

        String percentageText = subject.total() == 0
                ? "N/A"
                : formatPercentage(subject.percentage());

        Label percentageLabel = new Label(
                percentageText
        );
        percentageLabel.setStyle(
                "-fx-font-size: 15px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: " + BLUE + ";"
        );

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox subjectHeader = new HBox(
                12,
                nameLabel,
                spacer,
                percentageLabel
        );
        subjectHeader.setAlignment(Pos.CENTER_LEFT);

        Label countLabel = new Label(
                subject.attended()
                        + " of "
                        + subject.total()
                        + " classes attended"
        );
        countLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );

        ProgressBar progressBar = new ProgressBar(
                subject.total() == 0
                        ? 0
                        : Math.max(
                        0,
                        Math.min(
                                1,
                                subject.percentage() / 100.0
                        )
                )
        );

        progressBar.setMaxWidth(Double.MAX_VALUE);
        progressBar.setPrefHeight(10);
        progressBar.setStyle(
                "-fx-accent: " + BLUE + ";"
        );

        VBox card = new VBox(
                13,
                subjectHeader,
                countLabel,
                progressBar
        );

        card.getStyleClass().add("content-card");
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= FORMATTING =================

    private String formatPercentage(double percentage) {

        return String.format(
                Locale.ENGLISH,
                "%.1f%%",
                percentage
        );
    }

    // ================= DATA HOLDER =================

    private record SubjectAttendance(
            String name,
            int attended,
            int total,
            double percentage
    ) {
    }

    // ================= ERROR HANDLING =================

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText("Attendance Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
