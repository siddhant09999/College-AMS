
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AttendanceDAO;
import com.college.campustrack.model.Attendance;
import com.college.campustrack.model.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;

public class FacultyAttendanceView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"FACULTY".equals(user.role())
                || user.facultyId() == null) {

            showAlert(
                    Alert.AlertType.ERROR,
                    "Please log in as faculty."
            );
            return;
        }

        int facultyId = user.facultyId();
        AttendanceDAO dao = new AttendanceDAO();

        // ================= LOAD ASSIGNED SUBJECTS =================

        List<String[]> subjects;

        try {
            subjects = dao.getFacultySubjects(facultyId);

        } catch (Exception e) {
            e.printStackTrace();

            showAlert(
                    Alert.AlertType.ERROR,
                    "Unable to load faculty subjects."
            );
            return;
        }

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("FACULTY PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("Attendance Management");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Record student attendance for your assigned subjects."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox headingBox = new VBox(
                5,
                eyebrow,
                heading,
                subtitle
        );

        Button backButton = new Button(
                "← Back to Dashboard"
        );

        backButton.setStyle(
                "-fx-background-color: white;" +
                        "-fx-text-fill: #14233e;" +
                        "-fx-font-weight: bold;" +
                        "-fx-border-color: #e2e8f0;" +
                        "-fx-border-radius: 9;" +
                        "-fx-background-radius: 9;" +
                        "-fx-padding: 11 16;"
        );

        backButton.setOnAction(e ->
                new FacultyDashboardView().show(stage)
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                headingBox,
                headerSpacer,
                backButton
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= BANNER =================

        Label bannerTag = new Label(
                "FACULTY • ATTENDANCE"
        );
        bannerTag.setStyle(
                "-fx-text-fill: #bfdbfe;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label bannerTitle = new Label(
                "Manage classroom attendance."
        );
        bannerTitle.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Select a subject and date, mark students " +
                        "Present or Absent, and save their records."
        );
        bannerDescription.setStyle(
                "-fx-text-fill: #dbeafe;" +
                        "-fx-font-size: 13px;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);

        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= SUBJECT & DATE CONTROLS =================

        Label controlsTitle = new Label(
                "Class Selection"
        );
        controlsTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label controlsDescription = new Label(
                "Choose the subject and attendance date."
        );
        controlsDescription.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );

        ComboBox<String> subjectBox = new ComboBox<>();
        subjectBox.setPromptText("Select Subject");
        subjectBox.setMaxWidth(Double.MAX_VALUE);

        for (String[] subject : subjects) {
            subjectBox.getItems().add(
                    subject[0] + " - " + subject[1]
            );
        }

        DatePicker datePicker = new DatePicker(
                LocalDate.now()
        );
        datePicker.setMaxWidth(Double.MAX_VALUE);

        Label subjectLabel = new Label("SUBJECT");
        subjectLabel.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #64748b;"
        );

        Label dateLabel = new Label("ATTENDANCE DATE");
        dateLabel.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #64748b;"
        );

        VBox subjectField = new VBox(
                8,
                subjectLabel,
                subjectBox
        );

        VBox dateField = new VBox(
                8,
                dateLabel,
                datePicker
        );

        HBox.setHgrow(
                subjectField,
                Priority.ALWAYS
        );
        HBox.setHgrow(
                dateField,
                Priority.ALWAYS
        );

        subjectField.setMaxWidth(Double.MAX_VALUE);
        dateField.setMaxWidth(Double.MAX_VALUE);

        HBox selectionRow = new HBox(
                18,
                subjectField,
                dateField
        );

        VBox controlsCard = new VBox(
                18,
                controlsTitle,
                controlsDescription,
                selectionRow
        );

        controlsCard.getStyleClass().add("content-card");
        controlsCard.setMaxWidth(Double.MAX_VALUE);

        // ================= STUDENT TABLE =================

        TableView<String[]> table = new TableView<>();

        TableColumn<String[], String> rollCol =
                new TableColumn<>("Roll No.");

        rollCol.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 1)
                )
        );

        TableColumn<String[], String> nameCol =
                new TableColumn<>("Student Name");

        nameCol.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 2)
                )
        );

        TableColumn<String[], String> statusCol =
                new TableColumn<>("Attendance");

        statusCol.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 3)
                )
        );
        Label totalValue = new Label("0");
        Label presentValue = new Label("0");
        Label absentValue = new Label("0");
        // Each row keeps its Present/Absent selection.
        statusCol.setCellFactory(col -> new TableCell<>() {

            private final ComboBox<String> choice =
                    new ComboBox<>();

            {
                choice.getItems().addAll(
                        "Present",
                        "Absent"
                );

                choice.setMaxWidth(Double.MAX_VALUE);

                choice.setOnAction(e -> {

                    String[] row = getTableRow().getItem();

                    if (row != null
                            && choice.getValue() != null) {

                        row[3] = choice.getValue();

                        // Refresh the table and counters.
                        table.refresh();
                        updateCounters(
                                table,
                                totalValue,
                                presentValue,
                                absentValue
                        );
                    }
                });
            }

            @Override
            protected void updateItem(
                    String item,
                    boolean empty
            ) {

                super.updateItem(item, empty);

                if (empty
                        || getTableRow().getItem() == null) {

                    setGraphic(null);
                    return;
                }

                choice.setValue(item);
                setGraphic(choice);
            }
        });

        table.getColumns().addAll(
                rollCol,
                nameCol,
                statusCol
        );

        table.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        table.setPlaceholder(
                new Label(
                        "Select a subject to load students."
                )
        );

        table.setPrefHeight(370);
        table.setMinHeight(280);
        table.setMaxWidth(Double.MAX_VALUE);

        // ================= LIVE SUMMARY CARDS =================



        VBox totalCard = createStatCard(
                "ST",
                "Total Students",
                totalValue,
                "#dbeafe",
                "#1d4ed8"
        );

        VBox presentCard = createStatCard(
                "PR",
                "Present",
                presentValue,
                "#dcfce7",
                "#15803d"
        );

        VBox absentCard = createStatCard(
                "AB",
                "Absent",
                absentValue,
                "#fee2e2",
                "#b91c1c"
        );

        HBox stats = new HBox(
                18,
                totalCard,
                presentCard,
                absentCard
        );

        for (VBox card : new VBox[]{
                totalCard,
                presentCard,
                absentCard
        }) {

            HBox.setHgrow(card, Priority.ALWAYS);
            card.setMaxWidth(Double.MAX_VALUE);

            card.prefWidthProperty().bind(
                    stats.widthProperty()
                            .subtract(36)
                            .divide(3)
            );
        }

        // ================= SAVE BUTTON =================

        Button saveButton = new Button(
                "Save Attendance"
        );

        saveButton.setDisable(true);

        saveButton.setStyle(
                "-fx-background-color: #2563eb;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 12 22;" +
                        "-fx-background-radius: 10;" +
                        "-fx-cursor: hand;"
        );

        // ================= LOAD STUDENTS =================

        subjectBox.setOnAction(e -> {

            table.getItems().clear();
            saveButton.setDisable(true);

            updateCounters(
                    table,
                    totalValue,
                    presentValue,
                    absentValue
            );

            int index = subjectBox
                    .getSelectionModel()
                    .getSelectedIndex();

            if (index < 0) {
                return;
            }

            int subjectId = Integer.parseInt(
                    subjects.get(index)[0]
            );

            try {

                List<String[]> students =
                        dao.getStudentsForFacultySubject(
                                facultyId,
                                subjectId
                        );

                for (String[] student : students) {

                    table.getItems().add(
                            new String[]{
                                    student[0],
                                    student[1],
                                    student[2],
                                    "Present"
                            }
                    );
                }

                saveButton.setDisable(
                        students.isEmpty()
                );

                updateCounters(
                        table,
                        totalValue,
                        presentValue,
                        absentValue
                );

            } catch (Exception ex) {

                ex.printStackTrace();

                showAlert(
                        Alert.AlertType.ERROR,
                        "Unable to load students."
                );
            }
        });

        // ================= SAVE ATTENDANCE =================

        saveButton.setOnAction(e -> {

            int index = subjectBox
                    .getSelectionModel()
                    .getSelectedIndex();

            LocalDate date = datePicker.getValue();

            if (index < 0 || date == null) {

                showAlert(
                        Alert.AlertType.WARNING,
                        "Select a subject and date."
                );
                return;
            }

            if (table.getItems().isEmpty()) {

                showAlert(
                        Alert.AlertType.WARNING,
                        "No students available to mark."
                );
                return;
            }

            int subjectId = Integer.parseInt(
                    subjects.get(index)[0]
            );

            try {

                for (String[] student : table.getItems()) {

                    Attendance attendance = new Attendance(
                            0,
                            Integer.parseInt(student[0]),
                            subjectId,
                            date,
                            "Present".equals(student[3])
                    );

                    dao.saveForFaculty(
                            facultyId,
                            attendance
                    );
                }

                showAlert(
                        Alert.AlertType.INFORMATION,
                        "Attendance saved successfully!"
                );

            } catch (Exception ex) {

                ex.printStackTrace();

                showAlert(
                        Alert.AlertType.ERROR,
                        "Unable to save attendance: "
                                + ex.getMessage()
                );
            }
        });

        // ================= TABLE SECTION =================

        Label tableTitle = new Label(
                "Student Attendance Register"
        );
        tableTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label tableDescription = new Label(
                "Select Present or Absent for each student."
        );
        tableDescription.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;"
        );

        VBox tableHeading = new VBox(
                5,
                tableTitle,
                tableDescription
        );

        Region tableSpacer = new Region();
        HBox.setHgrow(
                tableSpacer,
                Priority.ALWAYS
        );

        HBox tableHeader = new HBox(
                16,
                tableHeading,
                tableSpacer,
                saveButton
        );
        tableHeader.setAlignment(Pos.CENTER_LEFT);

        VBox tableCard = new VBox(
                18,
                tableHeader,
                table
        );

        tableCard.getStyleClass().add("content-card");
        tableCard.setMaxWidth(Double.MAX_VALUE);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Faculty Attendance"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                controlsCard,
                stats,
                tableCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );
        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );

        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT LAYOUT =================

        BorderPane root = new BorderPane();
        root.setCenter(scrollPane);

        Scene scene = new Scene(
                root,
                1120,
                720
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Faculty Attendance"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= COUNTER HELPER =================

    private void updateCounters(
            TableView<String[]> table,
            Label totalValue,
            Label presentValue,
            Label absentValue
    ) {

        int total = table.getItems().size();
        int present = 0;
        int absent = 0;

        for (String[] student : table.getItems()) {

            if ("Present".equals(student[3])) {
                present++;

            } else if ("Absent".equals(student[3])) {
                absent++;
            }
        }

        totalValue.setText(
                String.valueOf(total)
        );

        presentValue.setText(
                String.valueOf(present)
        );

        absentValue.setText(
                String.valueOf(absent)
        );
    }

    // ================= STAT CARD HELPER =================

    private VBox createStatCard(
            String initials,
            String title,
            Label valueLabel,
            String iconBackground,
            String iconColor
    ) {

        Label icon = new Label(initials);
        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(42, 42);
        icon.setPrefSize(42, 42);
        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 11;"
        );

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;" +
                        "-fx-font-weight: bold;"
        );

        valueLabel.setStyle(
                "-fx-font-size: 27px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        VBox card = new VBox(
                12,
                icon,
                titleLabel,
                valueLabel
        );

        card.getStyleClass().add("dashboard-card");
        card.setPadding(new Insets(22));
        card.setMinHeight(155);
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= SAFE TABLE VALUE =================

    private String getValue(
            String[] row,
            int index
    ) {

        if (row == null
                || index >= row.length
                || row[index] == null) {

            return "N/A";
        }

        return row[index];
    }

    // ================= ALERT HELPER =================

    private void showAlert(
            Alert.AlertType type,
            String message
    ) {

        Alert alert = new Alert(type);
        alert.setTitle("CampusTrack");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
