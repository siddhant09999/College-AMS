
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.FeeDAO;
import com.college.campustrack.model.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class FeesView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"STUDENT".equals(user.role())
                || user.studentId() == null) {

            showError("Please log in as a student.");
            return;
        }

        // ================= LOAD REAL FEE DATA =================

        List<String[]> studentFees;

        try {
            studentFees = new FeeDAO()
                    .getFeesForStudent(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load student fees.");
            return;
        }

        // ================= FINANCIAL SUMMARY =================

        BigDecimal totalFees = BigDecimal.ZERO;
        BigDecimal totalPaid = BigDecimal.ZERO;

        try {
            for (String[] fee : studentFees) {

                BigDecimal amount = parseAmount(
                        getValue(fee, 1)
                );

                BigDecimal paid = parseAmount(
                        getValue(fee, 2)
                );

                totalFees = totalFees.add(amount);
                totalPaid = totalPaid.add(paid);
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
            showError(
                    "Unable to calculate fee totals. " +
                            "One or more fee amounts are invalid."
            );
            return;
        }

        BigDecimal outstanding = totalFees.subtract(totalPaid);

        // ================= SHARED SIDEBAR =================

        VBox sidebar = Sidebar.create(stage);
        sidebar.setPrefWidth(260);
        sidebar.setMinWidth(230);

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("STUDENT PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("My Fees");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "View your fee details and payment status."
        );
        subtitle.getStyleClass().add("page-subtitle");

        VBox headerText = new VBox(
                5,
                eyebrow,
                heading,
                subtitle
        );

        Label badge = new Label("●  FEE OVERVIEW");
        badge.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10 14;" +
                        "-fx-background-radius: 20;"
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                headerText,
                headerSpacer,
                badge
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= SUMMARY BANNER =================

        Label bannerTag = new Label(
                "YOUR FINANCIAL OVERVIEW"
        );
        bannerTag.setStyle(
                "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #bfdbfe;"
        );

        Label bannerTitle = new Label(
                "Stay informed about your fees."
        );
        bannerTitle.setStyle(
                "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Track assigned fees, recorded payments, " +
                        "and outstanding balances in one place."
        );
        bannerDescription.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #dbeafe;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(new Insets(26, 30, 26, 30));
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= SUMMARY CARDS =================

        VBox totalCard = createStatCard(
                "TF",
                "Total Fees",
                formatCurrency(totalFees),
                "Assigned fee amount",
                "#dbeafe",
                "#1d4ed8"
        );

        VBox paidCard = createStatCard(
                "PD",
                "Total Paid",
                formatCurrency(totalPaid),
                "Recorded payments",
                "#dcfce7",
                "#15803d"
        );

        VBox dueCard = createStatCard(
                "DU",
                "Outstanding",
                formatCurrency(outstanding),
                "Remaining fee balance",
                "#fef3c7",
                "#b45309"
        );

        HBox stats = new HBox(
                18,
                totalCard,
                paidCard,
                dueCard
        );

        for (VBox card : new VBox[]{
                totalCard,
                paidCard,
                dueCard
        }) {

            HBox.setHgrow(card, Priority.ALWAYS);
            card.setMaxWidth(Double.MAX_VALUE);

            card.prefWidthProperty().bind(
                    stats.widthProperty()
                            .subtract(36)
                            .divide(3)
            );
        }

        // ================= RECORDS SECTION =================

        Label sectionTitle = new Label(
                "Fee Records"
        );
        sectionTitle.getStyleClass().add("section-title");

        Label sectionSubtitle = new Label(
                "A detailed view of your assigned fees."
        );
        sectionSubtitle.getStyleClass().add("page-subtitle");

        VBox sectionHeading = new VBox(
                4,
                sectionTitle,
                sectionSubtitle
        );

        // ================= FEE TABLE =================

        TableView<String[]> feesTable = new TableView<>();

        TableColumn<String[], String> typeColumn =
                new TableColumn<>("Fee Type");

        typeColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 0)
                )
        );

        TableColumn<String[], String> amountColumn =
                new TableColumn<>("Amount");

        amountColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 1)
                )
        );

        TableColumn<String[], String> paidColumn =
                new TableColumn<>("Paid Amount");

        paidColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 2)
                )
        );

        TableColumn<String[], String> statusColumn =
                new TableColumn<>("Status");

        statusColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 3)
                )
        );

        // Style the status values using their real DB status.
        statusColumn.setCellFactory(column ->
                new TableCell<>() {

                    @Override
                    protected void updateItem(
                            String status,
                            boolean empty
                    ) {

                        super.updateItem(status, empty);

                        if (empty || status == null) {
                            setText(null);
                            setGraphic(null);
                            return;
                        }

                        Label statusBadge = new Label(status);

                        String background;
                        String foreground;

                        switch (status.toUpperCase(Locale.ENGLISH)) {

                            case "PAID":
                                background = "#dcfce7";
                                foreground = "#15803d";
                                break;

                            case "PARTIAL":
                                background = "#fef3c7";
                                foreground = "#b45309";
                                break;

                            default:
                                background = "#fee2e2";
                                foreground = "#b91c1c";
                                break;
                        }

                        statusBadge.setStyle(
                                "-fx-background-color: " +
                                        background + ";" +
                                        "-fx-text-fill: " +
                                        foreground + ";" +
                                        "-fx-font-size: 11px;" +
                                        "-fx-font-weight: bold;" +
                                        "-fx-padding: 6 11;" +
                                        "-fx-background-radius: 14;"
                        );

                        setText(null);
                        setGraphic(statusBadge);
                        setAlignment(Pos.CENTER_LEFT);
                    }
                }
        );

        feesTable.getColumns().addAll(
                typeColumn,
                amountColumn,
                paidColumn,
                statusColumn
        );

        feesTable.getItems().addAll(studentFees);

        feesTable.setPlaceholder(
                new Label("No fee records available yet.")
        );

        feesTable.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        feesTable.setPrefHeight(
                Math.max(
                        280,
                        Math.min(
                                520,
                                55 + studentFees.size() * 42
                        )
                )
        );

        feesTable.setMinHeight(280);
        feesTable.setMaxWidth(Double.MAX_VALUE);

        // ================= TABLE CARD =================

        Label tableTitle = new Label(
                "Payment & Fee Details"
        );
        tableTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label tableDescription = new Label(
                studentFees.size() == 1
                        ? "1 fee record"
                        : studentFees.size() + " fee records"
        );
        tableDescription.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );

        VBox tableHeader = new VBox(
                5,
                tableTitle,
                tableDescription
        );

        VBox tableCard = new VBox(
                18,
                tableHeader,
                feesTable
        );

        tableCard.getStyleClass().add("content-card");
        tableCard.setMaxWidth(Double.MAX_VALUE);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Student Fees"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-padding: 10 0 0 0;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                stats,
                sectionHeading,
                tableCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );
        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );

        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT LAYOUT =================

        BorderPane root = new BorderPane();

        root.setLeft(sidebar);
        root.setCenter(scrollPane);

        Scene scene = new Scene(
                root,
                1120,
                720
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - My Fees"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= STAT CARD HELPER =================

    private VBox createStatCard(
            String initials,
            String title,
            String value,
            String description,
            String iconBackground,
            String iconColor
    ) {

        Label icon = new Label(initials);
        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(42, 42);
        icon.setPrefSize(42, 42);
        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 11;"
        );

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;" +
                        "-fx-font-weight: bold;"
        );

        Label valueLabel = new Label(value);
        valueLabel.setStyle(
                "-fx-font-size: 22px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );
        valueLabel.setWrapText(true);

        Label descriptionLabel = new Label(description);
        descriptionLabel.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-text-fill: #94a3b8;"
        );
        descriptionLabel.setWrapText(true);

        VBox card = new VBox(
                12,
                icon,
                titleLabel,
                valueLabel,
                descriptionLabel
        );

        card.getStyleClass().add("dashboard-card");
        card.setPadding(new Insets(22));
        card.setMinHeight(180);
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= SAFE TABLE VALUES =================

    private String getValue(String[] row, int index) {

        if (row == null
                || index >= row.length
                || row[index] == null) {

            return "N/A";
        }

        return row[index];
    }

    // ================= AMOUNT HELPERS =================

    private BigDecimal parseAmount(String value) {

        if (value == null
                || value.isBlank()
                || "N/A".equals(value)) {

            return BigDecimal.ZERO;
        }

        // DAO amounts are expected to be numeric strings.
        return new BigDecimal(
                value.trim().replace(",", "")
        );
    }

    private String formatCurrency(BigDecimal amount) {

        NumberFormat currency = NumberFormat.getCurrencyInstance(
                new Locale("en", "IN")
        );

        currency.setMinimumFractionDigits(2);
        currency.setMaximumFractionDigits(2);

        return currency.format(amount);
    }

    // ================= ERROR HANDLING =================

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText("Fees Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
