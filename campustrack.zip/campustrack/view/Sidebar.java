package com.college.campustrack.view;

import com.college.campustrack.Main;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.college.campustrack.UserSession;


public class Sidebar {

    public static VBox create(Stage stage) {

        Label logo = new Label("CampusTrack");
        logo.getStyleClass().add("sidebar-logo");


        Button dashboardButton = new Button("Dashboard");
        Button attendanceButton = new Button("Attendance");
        Button marksButton = new Button("Marks");
        Button timetableButton = new Button("Timetable");
        Button feesButton = new Button("Fees");
        Button profileButton = new Button("Profile");
        Button logoutButton = new Button("Logout");

        dashboardButton.getStyleClass().add("sidebar-button");
        attendanceButton.getStyleClass().add("sidebar-button");
        marksButton.getStyleClass().add("sidebar-button");
        timetableButton.getStyleClass().add("sidebar-button");
        feesButton.getStyleClass().add("sidebar-button");
        profileButton.getStyleClass().add("sidebar-button");

        logoutButton.getStyleClass().add("logout-button");

        // ----- NAVIGATION -----

        dashboardButton.setOnAction(event -> {
            new DashboardView().show(stage);
        });

        attendanceButton.setOnAction(event -> {
            new AttendanceView().show(stage);
        });

        marksButton.setOnAction(event -> {
            new MarksView().show(stage);
        });

        timetableButton.setOnAction(event -> {
            new TimetableView().show(stage);
        });

        feesButton.setOnAction(event -> {
            new FeesView().show(stage);
        });

        profileButton.setOnAction(event -> {
            new ProfileView().show(stage);
        });


        logoutButton.setOnAction(e -> {
            UserSession.logout();
            new Main().showLogin(stage);
        });



        // ----- SIDEBAR LAYOUT -----

        VBox sidebar = new VBox(
                15,
                logo,
                dashboardButton,
                attendanceButton,
                marksButton,
                timetableButton,
                feesButton,
                profileButton,
                logoutButton
        );

        sidebar.setPadding(new Insets(25));
        sidebar.setPrefWidth(180);
        sidebar.getStyleClass().add("sidebar");

        return sidebar;
    }
}