
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AttendanceDAO;
import com.college.campustrack.dao.MarkDAO;
import com.college.campustrack.model.Mark;
import com.college.campustrack.model.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FacultyMarksView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"FACULTY".equals(user.role())
                || user.facultyId() == null) {

            showAlert(
                    Alert.AlertType.ERROR,
                    "Please log in as faculty."
            );
            return;
        }

        int facultyId = user.facultyId();

        AttendanceDAO attendanceDAO = new AttendanceDAO();
        MarkDAO markDAO = new MarkDAO();

        // ================= LOAD FACULTY SUBJECTS =================

        List<String[]> subjects;

        try {
            subjects = attendanceDAO.getFacultySubjects(facultyId);

        } catch (Exception e) {
            e.printStackTrace();

            showAlert(
                    Alert.AlertType.ERROR,
                    "Unable to load subjects."
            );
            return;
        }

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("FACULTY PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("Marks Management");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Record, review, and update student examination marks."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox headingBox = new VBox(
                5,
                eyebrow,
                heading,
                subtitle
        );

        Button backButton = new Button(
                "← Back to Dashboard"
        );

        backButton.setStyle(
                "-fx-background-color: white;" +
                        "-fx-text-fill: #14233e;" +
                        "-fx-font-weight: bold;" +
                        "-fx-border-color: #e2e8f0;" +
                        "-fx-border-radius: 9;" +
                        "-fx-background-radius: 9;" +
                        "-fx-padding: 11 16;"
        );

        backButton.setOnAction(e ->
                new FacultyDashboardView().show(stage)
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                headingBox,
                headerSpacer,
                backButton
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= BANNER =================

        Label bannerTag = new Label(
                "FACULTY • EXAMINATION RESULTS"
        );
        bannerTag.setStyle(
                "-fx-text-fill: #bfdbfe;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label bannerTitle = new Label(
                "Manage student performance."
        );
        bannerTitle.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Select a subject and exam, enter student marks, " +
                        "and save the results securely."
        );
        bannerDescription.setStyle(
                "-fx-text-fill: #dbeafe;" +
                        "-fx-font-size: 13px;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);

        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= SELECTION CONTROLS =================

        Label selectionTitle = new Label(
                "Examination Selection"
        );
        selectionTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label selectionDescription = new Label(
                "Choose your assigned subject and an examination."
        );
        selectionDescription.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;"
        );

        ComboBox<String> subjectBox = new ComboBox<>();
        subjectBox.setPromptText("Select Subject");
        subjectBox.setMaxWidth(Double.MAX_VALUE);

        for (String[] subject : subjects) {
            subjectBox.getItems().add(
                    subject[0] + " - " + subject[1]
            );
        }

        ComboBox<String> examBox = new ComboBox<>();
        examBox.setPromptText("Select Exam");
        examBox.setMaxWidth(Double.MAX_VALUE);
        examBox.setDisable(true);

        Label subjectLabel = fieldLabel("SUBJECT");
        Label examLabel = fieldLabel("EXAMINATION");

        VBox subjectField = new VBox(
                8,
                subjectLabel,
                subjectBox
        );

        VBox examField = new VBox(
                8,
                examLabel,
                examBox
        );

        HBox.setHgrow(subjectField, Priority.ALWAYS);
        HBox.setHgrow(examField, Priority.ALWAYS);

        subjectField.setMaxWidth(Double.MAX_VALUE);
        examField.setMaxWidth(Double.MAX_VALUE);

        HBox selectionRow = new HBox(
                18,
                subjectField,
                examField
        );

        Label maxMarksLabel = new Label(
                "Select an exam to view its maximum marks."
        );
        maxMarksLabel.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        VBox selectionCard = new VBox(
                18,
                selectionTitle,
                selectionDescription,
                selectionRow,
                maxMarksLabel
        );

        selectionCard.getStyleClass().add("content-card");
        selectionCard.setMaxWidth(Double.MAX_VALUE);

        // ================= LIVE SUMMARY LABELS =================

        Label totalValue = new Label("0");
        Label enteredValue = new Label("0");
        Label pendingValue = new Label("0");

        VBox totalCard = createStatCard(
                "ST",
                "Total Students",
                totalValue,
                "#dbeafe",
                "#1d4ed8"
        );

        VBox enteredCard = createStatCard(
                "EN",
                "Marks Entered",
                enteredValue,
                "#dcfce7",
                "#15803d"
        );

        VBox pendingCard = createStatCard(
                "PN",
                "Marks Pending",
                pendingValue,
                "#fef3c7",
                "#b45309"
        );

        HBox stats = new HBox(
                18,
                totalCard,
                enteredCard,
                pendingCard
        );

        for (VBox card : new VBox[]{
                totalCard,
                enteredCard,
                pendingCard
        }) {

            HBox.setHgrow(card, Priority.ALWAYS);
            card.setMaxWidth(Double.MAX_VALUE);

            card.prefWidthProperty().bind(
                    stats.widthProperty()
                            .subtract(36)
                            .divide(3)
            );
        }

        // ================= EDITABLE MARKS TABLE =================

        TableView<String[]> table = new TableView<>();
        table.setEditable(true);

        TableColumn<String[], String> rollCol =
                new TableColumn<>("Roll No.");

        rollCol.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 1)
                )
        );

        TableColumn<String[], String> nameCol =
                new TableColumn<>("Student Name");

        nameCol.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 2)
                )
        );

        TableColumn<String[], String> marksCol =
                new TableColumn<>("Marks");

        marksCol.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 3)
                )
        );

        marksCol.setCellFactory(
                TextFieldTableCell.forTableColumn()
        );

        marksCol.setEditable(true);

        marksCol.setOnEditCommit(event -> {

            String[] row = event.getRowValue();

            if (row != null) {

                String newValue = event.getNewValue();

                row[3] = newValue == null
                        ? ""
                        : newValue.trim();

                table.refresh();

                updateCounters(
                        table,
                        totalValue,
                        enteredValue,
                        pendingValue
                );
            }
        });

        table.getColumns().addAll(
                rollCol,
                nameCol,
                marksCol
        );

        table.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        table.setPlaceholder(
                new Label(
                        "Select a subject and exam to load students."
                )
        );

        table.setPrefHeight(380);
        table.setMinHeight(280);
        table.setMaxWidth(Double.MAX_VALUE);

        // ================= SAVE BUTTON =================

        Button saveButton = new Button("Save Marks");
        saveButton.setDisable(true);

        saveButton.setStyle(
                "-fx-background-color: #2563eb;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 12 22;" +
                        "-fx-background-radius: 10;" +
                        "-fx-cursor: hand;"
        );

        // ================= EXAMS HOLDER =================

        final List<String[]>[] examsHolder =
                new List[]{List.of()};

        // ================= SUBJECT SELECTION =================

        subjectBox.setOnAction(e -> {

            examBox.getItems().clear();
            examBox.setValue(null);
            examBox.setDisable(true);

            examsHolder[0] = List.of();

            table.getItems().clear();
            saveButton.setDisable(true);

            maxMarksLabel.setText(
                    "Select an exam to view its maximum marks."
            );

            updateCounters(
                    table,
                    totalValue,
                    enteredValue,
                    pendingValue
            );

            int index = subjectBox
                    .getSelectionModel()
                    .getSelectedIndex();

            if (index < 0) {
                return;
            }

            int subjectId = Integer.parseInt(
                    subjects.get(index)[0]
            );

            try {

                List<String[]> exams =
                        markDAO.getExamsForSubject(subjectId);

                examsHolder[0] = exams;

                for (String[] exam : exams) {

                    examBox.getItems().add(
                            exam[1]
                                    + " (Max: "
                                    + exam[2]
                                    + ")"
                    );
                }

                examBox.setDisable(exams.isEmpty());

                if (exams.isEmpty()) {

                    maxMarksLabel.setText(
                            "No examinations are available " +
                                    "for this subject."
                    );
                }

            } catch (Exception ex) {

                ex.printStackTrace();

                showAlert(
                        Alert.AlertType.ERROR,
                        "Unable to load exams."
                );
            }
        });

        // ================= EXAM SELECTION =================

        examBox.setOnAction(e -> {

            table.getItems().clear();
            saveButton.setDisable(true);

            updateCounters(
                    table,
                    totalValue,
                    enteredValue,
                    pendingValue
            );

            int subjectIndex = subjectBox
                    .getSelectionModel()
                    .getSelectedIndex();

            int examIndex = examBox
                    .getSelectionModel()
                    .getSelectedIndex();

            if (subjectIndex < 0
                    || examIndex < 0
                    || examIndex >= examsHolder[0].size()) {

                return;
            }

            int subjectId = Integer.parseInt(
                    subjects.get(subjectIndex)[0]
            );

            String[] selectedExam =
                    examsHolder[0].get(examIndex);

            int examId = Integer.parseInt(
                    selectedExam[0]
            );

            maxMarksLabel.setText(
                    "Maximum marks for this exam: "
                            + selectedExam[2]
            );

            try {

                List<String[]> students =
                        attendanceDAO.getStudentsForFacultySubject(
                                facultyId,
                                subjectId
                        );

                Map<Integer, Double> existing =
                        markDAO.getExistingMarks(
                                subjectId,
                                examId
                        );

                for (String[] student : students) {

                    int studentId = Integer.parseInt(
                            student[0]
                    );

                    Double previous =
                            existing.get(studentId);

                    table.getItems().add(
                            new String[]{
                                    student[0],
                                    student[1],
                                    student[2],
                                    previous == null
                                            ? ""
                                            : String.valueOf(previous)
                            }
                    );
                }

                saveButton.setDisable(
                        students.isEmpty()
                );

                updateCounters(
                        table,
                        totalValue,
                        enteredValue,
                        pendingValue
                );

            } catch (Exception ex) {

                ex.printStackTrace();

                showAlert(
                        Alert.AlertType.ERROR,
                        "Unable to load student marks."
                );
            }
        });

        // ================= SAVE MARKS =================

        saveButton.setOnAction(e -> {

            int subjectIndex = subjectBox
                    .getSelectionModel()
                    .getSelectedIndex();

            int examIndex = examBox
                    .getSelectionModel()
                    .getSelectedIndex();

            if (subjectIndex < 0
                    || examIndex < 0
                    || examIndex >= examsHolder[0].size()) {

                showAlert(
                        Alert.AlertType.WARNING,
                        "Select a subject and exam."
                );
                return;
            }

            int subjectId = Integer.parseInt(
                    subjects.get(subjectIndex)[0]
            );

            String[] selectedExam =
                    examsHolder[0].get(examIndex);

            int examId = Integer.parseInt(
                    selectedExam[0]
            );

            double maximum;

            try {
                maximum = Double.parseDouble(
                        selectedExam[2]
                );

            } catch (NumberFormatException ex) {

                showAlert(
                        Alert.AlertType.ERROR,
                        "Invalid maximum marks for this exam."
                );
                return;
            }

            try {

                List<Mark> marksToSave =
                        new ArrayList<>();

                // Validate every entry before saving.
                for (String[] student : table.getItems()) {

                    String entered =
                            student[3] == null
                                    ? ""
                                    : student[3].trim();

                    if (entered.isEmpty()) {
                        continue;
                    }

                    double value =
                            Double.parseDouble(entered);

                    if (!Double.isFinite(value)
                            || value < 0
                            || value > maximum) {

                        throw new IllegalArgumentException(
                                "Marks must be between 0 and "
                                        + maximum
                        );
                    }

                    marksToSave.add(
                            new Mark(
                                    0,
                                    Integer.parseInt(student[0]),
                                    subjectId,
                                    examId,
                                    value
                            )
                    );
                }

                if (marksToSave.isEmpty()) {

                    showAlert(
                            Alert.AlertType.WARNING,
                            "Enter at least one student's marks."
                    );
                    return;
                }

                // Preserve existing DAO save behavior.
                for (Mark mark : marksToSave) {

                    markDAO.saveForFaculty(
                            facultyId,
                            mark
                    );
                }

                showAlert(
                        Alert.AlertType.INFORMATION,
                        "Marks saved successfully!"
                );

            } catch (NumberFormatException ex) {

                showAlert(
                        Alert.AlertType.ERROR,
                        "Please enter valid numeric marks."
                );

            } catch (IllegalArgumentException ex) {

                showAlert(
                        Alert.AlertType.ERROR,
                        ex.getMessage()
                );

            } catch (Exception ex) {

                ex.printStackTrace();

                showAlert(
                        Alert.AlertType.ERROR,
                        "Unable to save marks: "
                                + ex.getMessage()
                );
            }
        });

        // ================= TABLE HEADER =================

        Label tableTitle = new Label(
                "Student Marks Register"
        );
        tableTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label tableDescription = new Label(
                "Double-click a Marks cell to edit. " +
                        "Press Enter to confirm."
        );
        tableDescription.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;"
        );
        tableDescription.setWrapText(true);

        VBox tableHeading = new VBox(
                5,
                tableTitle,
                tableDescription
        );

        Region tableSpacer = new Region();
        HBox.setHgrow(
                tableSpacer,
                Priority.ALWAYS
        );

        HBox tableHeader = new HBox(
                16,
                tableHeading,
                tableSpacer,
                saveButton
        );
        tableHeader.setAlignment(Pos.CENTER_LEFT);

        VBox tableCard = new VBox(
                18,
                tableHeader,
                table
        );

        tableCard.getStyleClass().add("content-card");
        tableCard.setMaxWidth(Double.MAX_VALUE);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Faculty Marks"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                selectionCard,
                stats,
                tableCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );

        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );

        scrollPane.setFitToWidth(true);

        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );

        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT =================

        BorderPane root = new BorderPane();
        root.setCenter(scrollPane);

        Scene scene = new Scene(
                root,
                1120,
                720
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Faculty Marks"
        );

        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= FIELD LABEL =================

    private Label fieldLabel(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #64748b;"
        );

        return label;
    }

    // ================= LIVE COUNTERS =================

    private void updateCounters(
            TableView<String[]> table,
            Label totalValue,
            Label enteredValue,
            Label pendingValue
    ) {

        int total = table.getItems().size();
        int entered = 0;

        for (String[] row : table.getItems()) {

            if (row.length > 3
                    && row[3] != null
                    && !row[3].trim().isEmpty()) {

                entered++;
            }
        }

        totalValue.setText(
                String.valueOf(total)
        );

        enteredValue.setText(
                String.valueOf(entered)
        );

        pendingValue.setText(
                String.valueOf(total - entered)
        );
    }

    // ================= STAT CARD =================

    private VBox createStatCard(
            String initials,
            String title,
            Label valueLabel,
            String iconBackground,
            String iconColor
    ) {

        Label icon = new Label(initials);

        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(42, 42);
        icon.setPrefSize(42, 42);

        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 11;"
        );

        Label titleLabel = new Label(title);

        titleLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;" +
                        "-fx-font-weight: bold;"
        );

        valueLabel.setStyle(
                "-fx-font-size: 27px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        VBox card = new VBox(
                12,
                icon,
                titleLabel,
                valueLabel
        );

        card.getStyleClass().add("dashboard-card");
        card.setPadding(new Insets(22));
        card.setMinHeight(155);
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= SAFE VALUE =================

    private String getValue(
            String[] row,
            int index
    ) {

        if (row == null
                || index >= row.length
                || row[index] == null) {

            return "";
        }

        return row[index];
    }

    // ================= ALERT =================

    private void showAlert(
            Alert.AlertType type,
            String message
    ) {

        Alert alert = new Alert(type);
        alert.setTitle("CampusTrack");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
