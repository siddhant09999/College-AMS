
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AdminAcademicDAO;
import com.college.campustrack.model.User;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class AdminAcademicView {

    private final AdminAcademicDAO dao = new AdminAcademicDAO();

    private final ComboBox<String> branchDropdown = new ComboBox<>();
    private final ComboBox<String> courseDropdown = new ComboBox<>();

    private final ListView<String> branchList = new ListView<>();
    private final ListView<String> courseList = new ListView<>();
    private final ListView<String> subjectList = new ListView<>();

    private List<String[]> departments = new ArrayList<>();
    private List<String[]> courses = new ArrayList<>();
    private List<String[]> subjects = new ArrayList<>();

    private int selectedBranchId = -1;
    private int selectedCourseId = -1;
    private int selectedSubjectId = -1;

    public void show(Stage stage) {

        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            showError("Please log in as an administrator.");
            return;
        }

        // Reset state if this view instance is reused.
        selectedBranchId = -1;
        selectedCourseId = -1;
        selectedSubjectId = -1;

        branchList.getSelectionModel().clearSelection();
        courseList.getSelectionModel().clearSelection();
        subjectList.getSelectionModel().clearSelection();

        Label eyebrow = new Label("ADMIN PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: #2563eb;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("Academic Management");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Manage branches, courses, and subjects in one place."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox headingBox = new VBox(
                5, eyebrow, heading, subtitle
        );

        Button back = new Button("← Back to Dashboard");
        back.setStyle(secondaryButtonStyle());
        back.setOnAction(e ->
                new AdminDashboardView().show(stage)
        );

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox header = new HBox(
                16, headingBox, spacer, back
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= BANNER =================

        Label bannerTag = new Label(
                "ADMINISTRATION • ACADEMICS"
        );
        bannerTag.setStyle(
                "-fx-text-fill: #bfdbfe;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label bannerTitle = new Label(
                "Build a stronger academic structure."
        );
        bannerTitle.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;"
        );
        bannerTitle.setWrapText(true);

        Label bannerText = new Label(
                "Organize departments, define courses, " +
                        "and maintain subject information."
        );
        bannerText.setStyle(
                "-fx-text-fill: #dbeafe;" +
                        "-fx-font-size: 13px;"
        );
        bannerText.setWrapText(true);

        VBox banner = new VBox(
                10, bannerTag, bannerTitle, bannerText
        );
        banner.setPadding(new Insets(26, 30, 26, 30));
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, #14233e, #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= TABS =================

        TabPane tabs = new TabPane();

        Tab branchesTab = new Tab(
                "Branches", createBranchTab()
        );

        Tab coursesTab = new Tab(
                "Courses", createCourseTab()
        );

        Tab subjectsTab = new Tab(
                "Subjects", createSubjectTab()
        );

        branchesTab.setClosable(false);
        coursesTab.setClosable(false);
        subjectsTab.setClosable(false);

        tabs.getTabs().addAll(
                branchesTab, coursesTab, subjectsTab
        );

        tabs.setTabClosingPolicy(
                TabPane.TabClosingPolicy.UNAVAILABLE
        );

        tabs.setMaxWidth(Double.MAX_VALUE);

        Label footer = new Label(
                "CampusTrack  •  Academic Administration"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;"
        );

        VBox content = new VBox(
                24, header, banner, tabs, footer
        );
        content.setPadding(new Insets(32, 36, 32, 36));
        content.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );

        refreshAll();

        Scene scene = new Scene(scroll, 1120, 750);
        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Academic Management"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= BRANCHES TAB =================

    private VBox createBranchTab() {

        TextField name = new TextField();
        name.setPromptText(
                "e.g. Artificial Intelligence & ML"
        );

        TextField code = new TextField();
        code.setPromptText("e.g. AIML");

        Label mode = modeLabel("ADD NEW BRANCH");

        GridPane form = createFormGrid();
        addField(form, 0, 0, "BRANCH NAME", name);
        addField(form, 1, 0, "BRANCH CODE", code);

        Button add = new Button("Add Branch");
        Button update = new Button("Save Changes");
        Button delete = new Button("Delete Branch");
        Button clear = new Button("Clear / New");

        styleActions(add, update, delete, clear);

        Runnable reset = () -> {
            selectedBranchId = -1;
            branchList.getSelectionModel().clearSelection();

            name.clear();
            code.clear();

            mode.setText("ADD NEW BRANCH");

            add.setDisable(false);
            update.setDisable(true);
            delete.setDisable(true);
        };

        branchList.getSelectionModel()
                .selectedIndexProperty()
                .addListener((obs, oldIndex, newIndex) -> {

                    int index = newIndex.intValue();

                    if (index < 0
                            || index >= departments.size()) {
                        return;
                    }

                    String[] d = departments.get(index);

                    selectedBranchId = Integer.parseInt(d[0]);

                    name.setText(d[1]);
                    code.setText(d[2]);

                    mode.setText(
                            "EDITING BRANCH #" + d[0]
                    );

                    add.setDisable(true);
                    update.setDisable(false);
                    delete.setDisable(false);
                });

        add.setOnAction(event -> {
            try {
                require(name.getText(), "Branch name");
                require(code.getText(), "Branch code");

                dao.addDepartment(
                        name.getText(),
                        code.getText()
                );

                reset.run();
                refreshAll();
                showMessage("Branch added successfully!");

            } catch (Exception e) {
                showError(e.getMessage());
            }
        });

        update.setOnAction(event -> {
            if (selectedBranchId <= 0) {
                return;
            }

            try {
                require(name.getText(), "Branch name");
                require(code.getText(), "Branch code");

                dao.updateDepartment(
                        selectedBranchId,
                        name.getText(),
                        code.getText()
                );

                reset.run();
                refreshAll();
                showMessage("Branch updated successfully!");

            } catch (Exception e) {
                showError(e.getMessage());
            }
        });

        delete.setOnAction(event -> {
            if (selectedBranchId <= 0) {
                return;
            }

            if (!confirmDelete(
                    "Delete branch \"" + name.getText() + "\"?"
            )) {
                return;
            }

            try {
                dao.deleteDepartment(selectedBranchId);

                reset.run();
                refreshAll();
                showMessage("Branch deleted successfully!");

            } catch (Exception e) {
                showError(
                        "Deletion blocked: " + e.getMessage()
                );
            }
        });

        clear.setOnAction(event -> reset.run());

        VBox formCard = createCard(
                mode,
                sectionTitle("Branch Information"),
                description(
                        "Create a new branch or select one to edit."
                ),
                form,
                actionRow(add, update, delete, clear)
        );

        branchList.setPrefHeight(280);
        branchList.setPlaceholder(
                new Label("No branches available.")
        );

        VBox listCard = createCard(
                sectionTitle("Existing Branches"),
                description(
                        "Select a branch to update or delete it."
                ),
                branchList
        );

        return createTabContent(formCard, listCard);
    }

    // ================= COURSES TAB =================

    private VBox createCourseTab() {

        TextField name = new TextField();
        name.setPromptText("e.g. B.Tech AI & ML");

        TextField code = new TextField();
        code.setPromptText("e.g. BTECH-AIML");

        TextField duration = new TextField("4");
        duration.setPromptText("Duration in years");

        branchDropdown.setPromptText("Select branch");

        Label mode = modeLabel("ADD NEW COURSE");

        GridPane form = createFormGrid();

        addField(form, 0, 0, "COURSE NAME", name);
        addField(form, 1, 0, "COURSE CODE", code);
        addField(form, 0, 1, "BRANCH", branchDropdown);
        addField(form, 1, 1, "DURATION (YEARS)", duration);

        Button add = new Button("Add Course");
        Button update = new Button("Save Changes");
        Button delete = new Button("Delete Course");
        Button clear = new Button("Clear / New");

        styleActions(add, update, delete, clear);

        Runnable reset = () -> {
            selectedCourseId = -1;
            courseList.getSelectionModel().clearSelection();

            name.clear();
            code.clear();
            duration.setText("4");
            branchDropdown.setValue(null);

            mode.setText("ADD NEW COURSE");

            add.setDisable(false);
            update.setDisable(true);
            delete.setDisable(true);
        };

        courseList.getSelectionModel()
                .selectedIndexProperty()
                .addListener((obs, oldIndex, newIndex) -> {

                    int index = newIndex.intValue();

                    if (index < 0
                            || index >= courses.size()) {
                        return;
                    }

                    String[] c = courses.get(index);

                    selectedCourseId = Integer.parseInt(c[0]);

                    name.setText(c[1]);
                    code.setText(c[2]);
                    duration.setText(c[5]);

                    selectById(
                            branchDropdown,
                            Integer.parseInt(c[4])
                    );

                    mode.setText(
                            "EDITING COURSE #" + c[0]
                    );

                    add.setDisable(true);
                    update.setDisable(false);
                    delete.setDisable(false);
                });

        add.setOnAction(event -> {
            try {
                require(name.getText(), "Course name");
                require(code.getText(), "Course code");

                if (branchDropdown.getValue() == null) {
                    throw new IllegalArgumentException(
                            "Please select a branch."
                    );
                }

                int years = Integer.parseInt(
                        duration.getText().trim()
                );

                if (years <= 0) {
                    throw new IllegalArgumentException(
                            "Duration must be greater than zero."
                    );
                }

                dao.addCourse(
                        name.getText(),
                        code.getText(),
                        getId(branchDropdown.getValue()),
                        years
                );

                reset.run();
                refreshAll();
                showMessage("Course added successfully!");

            } catch (Exception e) {
                showError(e.getMessage());
            }
        });

        update.setOnAction(event -> {
            if (selectedCourseId <= 0) {
                return;
            }

            try {
                require(name.getText(), "Course name");
                require(code.getText(), "Course code");

                if (branchDropdown.getValue() == null) {
                    throw new IllegalArgumentException(
                            "Please select a branch."
                    );
                }

                int years = Integer.parseInt(
                        duration.getText().trim()
                );

                if (years <= 0) {
                    throw new IllegalArgumentException(
                            "Duration must be greater than zero."
                    );
                }

                dao.updateCourse(
                        selectedCourseId,
                        name.getText(),
                        code.getText(),
                        getId(branchDropdown.getValue()),
                        years
                );

                reset.run();
                refreshAll();
                showMessage("Course updated successfully!");

            } catch (Exception e) {
                showError(e.getMessage());
            }
        });

        delete.setOnAction(event -> {
            if (selectedCourseId <= 0) {
                return;
            }

            if (!confirmDelete(
                    "Delete course \"" + name.getText() + "\"?"
            )) {
                return;
            }

            try {
                dao.deleteCourse(selectedCourseId);

                reset.run();
                refreshAll();
                showMessage("Course deleted successfully!");

            } catch (Exception e) {
                showError(
                        "Deletion blocked: " + e.getMessage()
                );
            }
        });

        clear.setOnAction(event -> reset.run());

        VBox formCard = createCard(
                mode,
                sectionTitle("Course Information"),
                description(
                        "Assign a course to a branch and set its duration."
                ),
                form,
                actionRow(add, update, delete, clear)
        );

        courseList.setPrefHeight(280);
        courseList.setPlaceholder(
                new Label("No courses available.")
        );

        VBox listCard = createCard(
                sectionTitle("Existing Courses"),
                description(
                        "Select a course to update or delete it."
                ),
                courseList
        );

        return createTabContent(formCard, listCard);
    }

    // ================= SUBJECTS TAB =================

    private VBox createSubjectTab() {

        TextField name = new TextField();
        name.setPromptText("e.g. Data Structures");

        TextField code = new TextField();
        code.setPromptText("e.g. AIML301");

        ComboBox<Integer> semester = new ComboBox<>(
                FXCollections.observableArrayList(
                        1, 2, 3, 4, 5, 6, 7, 8
                )
        );
        semester.setPromptText("Select semester");

        TextField credits = new TextField("4");
        credits.setPromptText("Subject credits");

        courseDropdown.setPromptText("Select course");

        Label mode = modeLabel("ADD NEW SUBJECT");

        GridPane form = createFormGrid();

        addField(form, 0, 0, "SUBJECT NAME", name);
        addField(form, 1, 0, "SUBJECT CODE", code);
        addField(form, 0, 1, "COURSE", courseDropdown);
        addField(form, 1, 1, "SEMESTER", semester);
        addField(form, 0, 2, "CREDITS", credits);

        Button add = new Button("Add Subject");
        Button update = new Button("Save Changes");
        Button delete = new Button("Delete Subject");
        Button clear = new Button("Clear / New");

        styleActions(add, update, delete, clear);

        Runnable reset = () -> {
            selectedSubjectId = -1;
            subjectList.getSelectionModel().clearSelection();

            name.clear();
            code.clear();
            courseDropdown.setValue(null);
            semester.setValue(null);
            credits.setText("4");

            mode.setText("ADD NEW SUBJECT");

            add.setDisable(false);
            update.setDisable(true);
            delete.setDisable(true);
        };

        subjectList.getSelectionModel()
                .selectedIndexProperty()
                .addListener((obs, oldIndex, newIndex) -> {

                    int index = newIndex.intValue();

                    if (index < 0
                            || index >= subjects.size()) {
                        return;
                    }

                    String[] s = subjects.get(index);

                    selectedSubjectId = Integer.parseInt(s[0]);

                    name.setText(s[1]);
                    code.setText(s[2]);

                    semester.setValue(
                            Integer.parseInt(s[4])
                    );

                    credits.setText(s[5]);

                    selectById(
                            courseDropdown,
                            Integer.parseInt(s[6])
                    );

                    mode.setText(
                            "EDITING SUBJECT #" + s[0]
                    );

                    add.setDisable(true);
                    update.setDisable(false);
                    delete.setDisable(false);
                });

        add.setOnAction(event -> {
            try {
                require(name.getText(), "Subject name");
                require(code.getText(), "Subject code");

                if (courseDropdown.getValue() == null
                        || semester.getValue() == null) {

                    throw new IllegalArgumentException(
                            "Please select a course and semester."
                    );
                }

                int creditValue = Integer.parseInt(
                        credits.getText().trim()
                );

                if (creditValue <= 0) {
                    throw new IllegalArgumentException(
                            "Credits must be greater than zero."
                    );
                }

                dao.addSubject(
                        name.getText(),
                        code.getText(),
                        getId(courseDropdown.getValue()),
                        semester.getValue(),
                        creditValue
                );

                reset.run();
                refreshAll();
                showMessage("Subject added successfully!");

            } catch (Exception e) {
                showError(e.getMessage());
            }
        });

        update.setOnAction(event -> {
            if (selectedSubjectId <= 0) {
                return;
            }

            try {
                require(name.getText(), "Subject name");
                require(code.getText(), "Subject code");

                if (courseDropdown.getValue() == null
                        || semester.getValue() == null) {

                    throw new IllegalArgumentException(
                            "Please select a course and semester."
                    );
                }

                int creditValue = Integer.parseInt(
                        credits.getText().trim()
                );

                if (creditValue <= 0) {
                    throw new IllegalArgumentException(
                            "Credits must be greater than zero."
                    );
                }

                dao.updateSubject(
                        selectedSubjectId,
                        name.getText(),
                        code.getText(),
                        getId(courseDropdown.getValue()),
                        semester.getValue(),
                        creditValue
                );

                reset.run();
                refreshAll();
                showMessage("Subject updated successfully!");

            } catch (Exception e) {
                showError(e.getMessage());
            }
        });

        delete.setOnAction(event -> {
            if (selectedSubjectId <= 0) {
                return;
            }

            if (!confirmDelete(
                    "Delete subject \"" + name.getText() + "\"?"
            )) {
                return;
            }

            try {
                dao.deleteSubject(selectedSubjectId);

                reset.run();
                refreshAll();
                showMessage("Subject deleted successfully!");

            } catch (Exception e) {
                showError(
                        "Deletion blocked: " + e.getMessage()
                );
            }
        });

        clear.setOnAction(event -> reset.run());

        VBox formCard = createCard(
                mode,
                sectionTitle("Subject Information"),
                description(
                        "Configure subjects, semesters, and credits."
                ),
                form,
                actionRow(add, update, delete, clear)
        );

        subjectList.setPrefHeight(320);
        subjectList.setPlaceholder(
                new Label("No subjects available.")
        );

        VBox listCard = createCard(
                sectionTitle("Existing Subjects"),
                description(
                        "Select a subject to update or delete it."
                ),
                subjectList
        );

        return createTabContent(formCard, listCard);
    }

    // ================= REFRESH ALL DATA =================

    private void refreshAll() {

        try {
            List<String[]> loadedDepartments =
                    dao.getDepartments();

            List<String[]> loadedCourses =
                    dao.getCourses();

            List<String[]> loadedSubjects =
                    dao.getSubjects();

            String previousBranch = branchDropdown.getValue();
            String previousCourse = courseDropdown.getValue();

            departments = loadedDepartments;
            courses = loadedCourses;
            subjects = loadedSubjects;

            branchDropdown.getItems().clear();
            courseDropdown.getItems().clear();

            branchList.getItems().clear();
            courseList.getItems().clear();
            subjectList.getItems().clear();

            for (String[] d : departments) {

                branchDropdown.getItems().add(
                        d[0] + " - " + d[1]
                );

                branchList.getItems().add(
                        d[1] + " (" + d[2] + ")"
                );
            }

            for (String[] c : courses) {

                courseDropdown.getItems().add(
                        c[0] + " - " + c[1]
                );

                courseList.getItems().add(
                        c[1] + " (" + c[2] + ") - " + c[3]
                );
            }

            for (String[] s : subjects) {

                subjectList.getItems().add(
                        s[1] + " (" + s[2] + ")" +
                                " | " + s[3] +
                                " | Semester " + s[4] +
                                " | " + s[5] + " credits"
                );
            }

            if (branchDropdown.getItems().contains(previousBranch)) {
                branchDropdown.setValue(previousBranch);
            }

            if (courseDropdown.getItems().contains(previousCourse)) {
                courseDropdown.setValue(previousCourse);
            }

        } catch (Exception e) {
            showError(
                    "Unable to load academic data: " +
                            e.getMessage()
            );
        }
    }

    // ================= UI HELPERS =================

    private VBox createTabContent(
            VBox formCard,
            VBox listCard
    ) {

        VBox content = new VBox(
                20, formCard, listCard
        );

        content.setPadding(
                new Insets(22, 8, 18, 8)
        );

        content.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        return content;
    }

    private VBox createCard(javafx.scene.Node... children) {

        VBox card = new VBox(18, children);
        card.getStyleClass().add("content-card");
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    private GridPane createFormGrid() {

        GridPane grid = new GridPane();

        grid.setHgap(18);
        grid.setVgap(16);

        ColumnConstraints left = new ColumnConstraints();
        ColumnConstraints right = new ColumnConstraints();

        left.setPercentWidth(50);
        right.setPercentWidth(50);

        grid.getColumnConstraints().addAll(
                left, right
        );

        return grid;
    }

    private void addField(
            GridPane grid,
            int column,
            int row,
            String labelText,
            Control control
    ) {

        Label label = new Label(labelText);

        label.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #64748b;"
        );

        control.setMaxWidth(Double.MAX_VALUE);

        VBox field = new VBox(
                8, label, control
        );

        grid.add(field, column, row);
    }

    private Label sectionTitle(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        return label;
    }

    private Label description(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;"
        );

        label.setWrapText(true);

        return label;
    }

    private Label modeLabel(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 9 14;" +
                        "-fx-background-radius: 16;"
        );

        return label;
    }

    private HBox actionRow(Button... buttons) {

        HBox row = new HBox(12, buttons);

        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(
                new Insets(8, 0, 0, 0)
        );

        return row;
    }

    private void styleActions(
            Button add,
            Button update,
            Button delete,
            Button clear
    ) {

        String primary =
                "-fx-background-color: #2563eb;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;";

        add.setStyle(primary);
        update.setStyle(primary);

        delete.setStyle(
                "-fx-background-color: #fee2e2;" +
                        "-fx-text-fill: #b91c1c;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;"
        );

        clear.setStyle(secondaryButtonStyle());

        update.setDisable(true);
        delete.setDisable(true);
    }

    private String secondaryButtonStyle() {

        return "-fx-background-color: #f1f5f9;" +
                "-fx-text-fill: #334155;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 11 17;" +
                "-fx-background-radius: 9;";
    }

    // ================= DATA HELPERS =================

    private void selectById(
            ComboBox<String> box,
            int id
    ) {

        for (String item : box.getItems()) {

            if (getId(item) == id) {
                box.setValue(item);
                return;
            }
        }
    }

    private int getId(String value) {

        return Integer.parseInt(
                value.split(" - ", 2)[0]
        );
    }

    private void require(
            String value,
            String field
    ) {

        if (value == null || value.isBlank()) {

            throw new IllegalArgumentException(
                    field + " is required."
            );
        }
    }

    // ================= ALERTS =================

    private boolean confirmDelete(String message) {

        Alert alert = new Alert(
                Alert.AlertType.CONFIRMATION,
                message + "\n\n" +
                        "This action cannot be undone.\n" +
                        "Deletion will be blocked if linked records exist.",
                ButtonType.YES,
                ButtonType.NO
        );

        alert.setTitle("Confirm Deletion");

        return alert.showAndWait()
                .orElse(ButtonType.NO) == ButtonType.YES;
    }

    private void showMessage(String message) {

        Alert alert = new Alert(
                Alert.AlertType.INFORMATION,
                message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.showAndWait();
    }

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR,
                message == null ? "An unexpected error occurred." : message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.showAndWait();
    }
}
