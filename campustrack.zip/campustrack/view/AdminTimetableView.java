
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AdminTimetableDAO;
import com.college.campustrack.model.User;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminTimetableView {

    private final AdminTimetableDAO dao =
            new AdminTimetableDAO();

    private final ListView<String> timetableList =
            new ListView<>();

    private List<String[]> timetableRows =
            new ArrayList<>();

    private List<String[]> visibleRows =
            new ArrayList<>();

    private int selectedTimetableId = -1;

    public void show(Stage stage) {

        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            showError("Please log in as an administrator.");
            return;
        }

        selectedTimetableId = -1;

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("ADMIN PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: #2563eb;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("Timetable Management");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Plan classes, assign faculty, and manage schedules."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox headingBox = new VBox(
                5, eyebrow, heading, subtitle
        );

        Button back = new Button("← Back to Dashboard");
        back.setStyle(secondaryButtonStyle());

        back.setOnAction(e ->
                new AdminDashboardView().show(stage)
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16, headingBox, headerSpacer, back
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= BANNER =================

        Label bannerTag = new Label(
                "ADMINISTRATION • CLASS SCHEDULING"
        );
        bannerTag.setStyle(
                "-fx-text-fill: #bfdbfe;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label bannerTitle = new Label(
                "Keep every class on schedule."
        );
        bannerTitle.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;"
        );
        bannerTitle.setWrapText(true);

        Label bannerText = new Label(
                "Coordinate courses, subjects, faculty, " +
                        "classrooms, and class timings."
        );
        bannerText.setStyle(
                "-fx-text-fill: #dbeafe;" +
                        "-fx-font-size: 13px;"
        );
        bannerText.setWrapText(true);

        VBox banner = new VBox(
                10, bannerTag, bannerTitle, bannerText
        );

        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );

        banner.setMaxWidth(Double.MAX_VALUE);

        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, #14233e, #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= FORM CONTROLS =================

        ComboBox<String> course = new ComboBox<>();
        ComboBox<String> subject = new ComboBox<>();
        ComboBox<String> faculty = new ComboBox<>();

        ComboBox<String> day = new ComboBox<>(
                FXCollections.observableArrayList(
                        "Monday",
                        "Tuesday",
                        "Wednesday",
                        "Thursday",
                        "Friday",
                        "Saturday"
                )
        );

        TextField start = new TextField("09:00");
        TextField end = new TextField("10:00");
        TextField classroom = new TextField();

        course.setPromptText("Select course");
        subject.setPromptText("Select subject");
        faculty.setPromptText("Select faculty");
        day.setPromptText("Select day");

        start.setPromptText("HH:mm");
        end.setPromptText("HH:mm");
        classroom.setPromptText("e.g. Room 301");

        subject.setDisable(true);

        course.setMaxWidth(Double.MAX_VALUE);
        subject.setMaxWidth(Double.MAX_VALUE);
        faculty.setMaxWidth(Double.MAX_VALUE);
        day.setMaxWidth(Double.MAX_VALUE);

        // ================= LOAD OPTIONS =================

        try {

            for (String[] c : dao.getCourses()) {

                course.getItems().add(
                        c[0] + " - " + c[1]
                );
            }

            for (String[] f : dao.getFaculty()) {

                faculty.getItems().add(
                        f[0] + " - " + f[1]
                );
            }

        } catch (Exception e) {

            showError(
                    "Unable to load options: " + e.getMessage()
            );
        }

        // ================= COURSE FILTER =================

        course.setOnAction(event -> {

            subject.getItems().clear();
            subject.setValue(null);
            subject.setDisable(true);

            if (course.getValue() == null) {
                return;
            }

            try {

                int courseId = getId(course.getValue());

                for (String[] s : dao.getSubjects(courseId)) {

                    subject.getItems().add(
                            s[0] + " - " + s[1]
                                    + " (Semester " + s[2] + ")"
                    );
                }

                subject.setDisable(
                        subject.getItems().isEmpty()
                );

            } catch (Exception e) {

                showError(
                        "Unable to load subjects: " +
                                e.getMessage()
                );
            }
        });

        // ================= FORM CARD =================

        Label mode = new Label("ADD NEW CLASS");
        mode.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 9 14;" +
                        "-fx-background-radius: 16;"
        );

        Label formTitle = sectionTitle(
                "Class Schedule Details"
        );

        Label formDescription = description(
                "Select a course and subject, assign faculty, " +
                        "and choose the class timing."
        );

        GridPane form = new GridPane();
        form.setHgap(18);
        form.setVgap(16);

        ColumnConstraints left = new ColumnConstraints();
        ColumnConstraints right = new ColumnConstraints();

        left.setPercentWidth(50);
        right.setPercentWidth(50);

        form.getColumnConstraints().addAll(
                left, right
        );

        addField(form, 0, 0, "COURSE", course);
        addField(form, 1, 0, "SUBJECT", subject);

        addField(form, 0, 1, "FACULTY", faculty);
        addField(form, 1, 1, "DAY OF WEEK", day);

        addField(form, 0, 2, "START TIME (HH:mm)", start);
        addField(form, 1, 2, "END TIME (HH:mm)", end);

        addField(form, 0, 3, "CLASSROOM", classroom);

        Label schedulingHint = new Label(
                "Tip: Use 24-hour time (e.g. 09:00 or 14:30). " +
                        "The system checks scheduling conflicts before saving."
        );

        schedulingHint.setWrapText(true);
        schedulingHint.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        // ================= ACTION BUTTONS =================

        Button add = new Button("Add Class");
        Button update = new Button("Save Changes");
        Button delete = new Button("Delete Class");
        Button clear = new Button("Clear / New");

        add.setStyle(primaryButtonStyle());
        update.setStyle(primaryButtonStyle());

        delete.setStyle(
                "-fx-background-color: #fee2e2;" +
                        "-fx-text-fill: #b91c1c;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;"
        );

        clear.setStyle(secondaryButtonStyle());

        update.setDisable(true);
        delete.setDisable(true);

        HBox actions = new HBox(
                12, add, update, delete, clear
        );
        actions.setAlignment(Pos.CENTER_LEFT);

        VBox formCard = new VBox(
                20,
                mode,
                formTitle,
                formDescription,
                form,
                schedulingHint,
                actions
        );

        formCard.getStyleClass().add("content-card");
        formCard.setMaxWidth(Double.MAX_VALUE);

        // ================= TIMETABLE RECORDS =================

        Label listTitle = sectionTitle(
                "Existing Timetable"
        );

        Label listDescription = description(
                "Search scheduled classes and select an entry " +
                        "to edit or delete."
        );

        TextField search = new TextField();
        search.setPromptText(
                "Search by day, course, subject, faculty or room"
        );

        search.setMaxWidth(Double.MAX_VALUE);

        timetableList.setPrefHeight(360);
        timetableList.setMinHeight(260);

        timetableList.setPlaceholder(
                new Label("No timetable entries found.")
        );

        timetableList.setCellFactory(list ->
                new ListCell<>() {

                    @Override
                    protected void updateItem(
                            String item,
                            boolean empty
                    ) {

                        super.updateItem(item, empty);

                        if (empty || item == null) {

                            setText(null);
                            setGraphic(null);

                        } else {

                            setText(item);
                            setWrapText(true);
                        }
                    }
                }
        );

        Button refresh = new Button(
                "↻ Refresh Timetable"
        );
        refresh.setStyle(secondaryButtonStyle());

        Label countLabel = new Label(
                "0 scheduled classes"
        );
        countLabel.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        Region listSpacer = new Region();
        HBox.setHgrow(listSpacer, Priority.ALWAYS);

        HBox listToolbar = new HBox(
                12, countLabel, listSpacer, refresh
        );
        listToolbar.setAlignment(Pos.CENTER_LEFT);

        VBox listCard = new VBox(
                18,
                listTitle,
                listDescription,
                search,
                timetableList,
                listToolbar
        );

        listCard.getStyleClass().add("content-card");
        listCard.setMaxWidth(Double.MAX_VALUE);

        // ================= RESET FORM =================

        Runnable reset = () -> {

            selectedTimetableId = -1;

            timetableList.getSelectionModel()
                    .clearSelection();

            course.setValue(null);

            subject.getItems().clear();
            subject.setValue(null);
            subject.setDisable(true);

            faculty.setValue(null);
            day.setValue(null);

            start.setText("09:00");
            end.setText("10:00");
            classroom.clear();

            mode.setText("ADD NEW CLASS");

            add.setDisable(false);
            update.setDisable(true);
            delete.setDisable(true);
        };

        // ================= SELECT TIMETABLE ENTRY =================

        timetableList.getSelectionModel()
                .selectedIndexProperty()
                .addListener((obs, oldValue, newValue) -> {

                    int index = newValue.intValue();

                    if (index < 0
                            || index >= visibleRows.size()) {

                        return;
                    }

                    String[] row = visibleRows.get(index);

                    try {

                        selectedTimetableId =
                                Integer.parseInt(row[0]);

                        // Selecting a course reloads its subjects.
                        selectById(
                                course,
                                Integer.parseInt(row[9])
                        );

                        selectById(
                                subject,
                                Integer.parseInt(row[10])
                        );

                        selectById(
                                faculty,
                                Integer.parseInt(row[11])
                        );

                        day.setValue(row[5]);

                        start.setText(
                                LocalTime.parse(row[6]).toString()
                        );

                        end.setText(
                                LocalTime.parse(row[7]).toString()
                        );

                        classroom.setText(
                                row[8] == null ? "" : row[8]
                        );

                        mode.setText(
                                "EDITING CLASS #" + row[0]
                        );

                        add.setDisable(true);
                        update.setDisable(false);
                        delete.setDisable(false);

                    } catch (Exception e) {

                        showError(
                                "Unable to load selected class: " +
                                        e.getMessage()
                        );
                    }
                });

        // ================= ADD CLASS =================

        add.setOnAction(event -> {

            try {

                validateSelection(
                        course, subject, faculty, day
                );

                LocalTime startTime = parseTime(
                        start.getText(),
                        "Start time"
                );

                LocalTime endTime = parseTime(
                        end.getText(),
                        "End time"
                );

                validateTimeRange(startTime, endTime);

                requireClassroom(classroom.getText());

                dao.addClass(
                        getId(course.getValue()),
                        getId(subject.getValue()),
                        getId(faculty.getValue()),
                        day.getValue(),
                        startTime,
                        endTime,
                        classroom.getText().trim()
                );

                reset.run();
                refreshTimetable(
                        search.getText(),
                        countLabel
                );

                showMessage(
                        "Class added successfully!"
                );

            } catch (Exception e) {

                showError(
                        "Unable to add class: " +
                                e.getMessage()
                );
            }
        });

        // ================= UPDATE CLASS =================

        update.setOnAction(event -> {

            try {

                if (selectedTimetableId <= 0) {

                    throw new IllegalArgumentException(
                            "Select a class to edit."
                    );
                }

                validateSelection(
                        course, subject, faculty, day
                );

                LocalTime startTime = parseTime(
                        start.getText(),
                        "Start time"
                );

                LocalTime endTime = parseTime(
                        end.getText(),
                        "End time"
                );

                validateTimeRange(startTime, endTime);

                requireClassroom(classroom.getText());

                dao.updateClass(
                        selectedTimetableId,
                        getId(course.getValue()),
                        getId(subject.getValue()),
                        getId(faculty.getValue()),
                        day.getValue(),
                        startTime,
                        endTime,
                        classroom.getText().trim()
                );

                reset.run();
                refreshTimetable(
                        search.getText(),
                        countLabel
                );

                showMessage(
                        "Class updated successfully!"
                );

            } catch (Exception e) {

                showError(
                        "Unable to update class: " +
                                e.getMessage()
                );
            }
        });

        // ================= DELETE CLASS =================

        delete.setOnAction(event -> {

            if (selectedTimetableId <= 0) {
                return;
            }

            Alert confirmation = new Alert(
                    Alert.AlertType.CONFIRMATION,
                    "Delete this timetable class?\n\n" +
                            "This will remove its scheduled entry.",
                    ButtonType.YES,
                    ButtonType.NO
            );

            confirmation.setTitle(
                    "Confirm Class Deletion"
            );

            if (confirmation.showAndWait()
                    .orElse(ButtonType.NO)
                    != ButtonType.YES) {

                return;
            }

            try {

                dao.deleteClass(selectedTimetableId);

                reset.run();
                refreshTimetable(
                        search.getText(),
                        countLabel
                );

                showMessage(
                        "Class deleted successfully!"
                );

            } catch (Exception e) {

                showError(
                        "Unable to delete class: " +
                                e.getMessage()
                );
            }
        });

        // ================= CLEAR / REFRESH =================

        clear.setOnAction(event -> reset.run());

        refresh.setOnAction(event -> {

            reset.run();

            refreshTimetable(
                    search.getText(),
                    countLabel
            );
        });

        // ================= LIVE SEARCH =================

        search.textProperty().addListener(
                (obs, oldValue, newValue) -> {

                    reset.run();

                    filterTimetable(
                            newValue,
                            countLabel
                    );
                }
        );

        // ================= INITIAL LOAD =================

        refreshTimetable("", countLabel);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Admin Timetable Management"
        );

        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;"
        );

        // ================= MAIN LAYOUT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                formCard,
                listCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );

        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scroll = new ScrollPane(
                mainContent
        );

        scroll.setFitToWidth(true);

        scroll.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );

        Scene scene = new Scene(
                scroll,
                1120,
                750
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Timetable Management"
        );

        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= REFRESH DATA =================

    private void refreshTimetable(
            String query,
            Label countLabel
    ) {

        try {

            timetableRows = dao.getTimetable();

            filterTimetable(
                    query,
                    countLabel
            );

        } catch (Exception e) {

            showError(
                    "Unable to load timetable: " +
                            e.getMessage()
            );
        }
    }

    // ================= SEARCH / FILTER =================

    private void filterTimetable(
            String query,
            Label countLabel
    ) {

        String searchText = query == null
                ? ""
                : query.trim().toLowerCase(Locale.ENGLISH);

        visibleRows = new ArrayList<>();

        timetableList.getSelectionModel()
                .clearSelection();

        timetableList.getItems().clear();

        for (String[] row : timetableRows) {

            String display = formatTimetableRow(row);

            if (display.toLowerCase(Locale.ENGLISH)
                    .contains(searchText)) {

                visibleRows.add(row);
                timetableList.getItems().add(display);
            }
        }

        countLabel.setText(
                visibleRows.size() +
                        (visibleRows.size() == 1
                                ? " scheduled class"
                                : " scheduled classes")
        );
    }

    // ================= ROW DISPLAY =================

    private String formatTimetableRow(String[] t) {

        return safe(t, 5) + "  |  " +
                safe(t, 6) + " - " + safe(t, 7) +
                "\n" +
                safe(t, 1) +
                "  |  Semester " + safe(t, 3) +
                "  |  " + safe(t, 2) +
                "\nFaculty: " + safe(t, 4) +
                "  |  Room: " + safe(t, 8);
    }

    private String safe(
            String[] row,
            int index
    ) {

        if (row == null
                || index >= row.length
                || row[index] == null) {

            return "N/A";
        }

        return row[index];
    }

    // ================= VALIDATION =================

    private void validateSelection(
            ComboBox<String> course,
            ComboBox<String> subject,
            ComboBox<String> faculty,
            ComboBox<String> day
    ) {

        if (course.getValue() == null
                || subject.getValue() == null
                || faculty.getValue() == null
                || day.getValue() == null) {

            throw new IllegalArgumentException(
                    "Please select course, subject, faculty and day."
            );
        }
    }

    private LocalTime parseTime(
            String value,
            String field
    ) {

        try {

            return LocalTime.parse(
                    value == null ? "" : value.trim()
            );

        } catch (DateTimeParseException e) {

            throw new IllegalArgumentException(
                    field + " must use HH:mm format " +
                            "(e.g. 09:00 or 14:30)."
            );
        }
    }

    private void validateTimeRange(
            LocalTime start,
            LocalTime end
    ) {

        if (!end.isAfter(start)) {

            throw new IllegalArgumentException(
                    "End time must be later than start time."
            );
        }
    }

    private void requireClassroom(String value) {

        if (value == null || value.isBlank()) {

            throw new IllegalArgumentException(
                    "Please enter a classroom."
            );
        }
    }

    // ================= FORM HELPERS =================

    private void addField(
            GridPane grid,
            int column,
            int row,
            String labelText,
            Control control
    ) {

        Label label = new Label(labelText);

        label.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #64748b;"
        );

        control.setMaxWidth(Double.MAX_VALUE);

        VBox field = new VBox(
                8, label, control
        );

        grid.add(field, column, row);
    }

    private Label sectionTitle(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        return label;
    }

    private Label description(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        label.setWrapText(true);

        return label;
    }

    private String primaryButtonStyle() {

        return "-fx-background-color: #2563eb;" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 11 17;" +
                "-fx-background-radius: 9;";
    }

    private String secondaryButtonStyle() {

        return "-fx-background-color: #f1f5f9;" +
                "-fx-text-fill: #334155;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 11 17;" +
                "-fx-background-radius: 9;";
    }

    private void selectById(
            ComboBox<String> box,
            int id
    ) {

        for (String item : box.getItems()) {

            if (getId(item) == id) {

                box.setValue(item);
                return;
            }
        }
    }

    private int getId(String value) {

        return Integer.parseInt(
                value.split(" - ", 2)[0]
        );
    }

    // ================= ALERTS =================

    private void showMessage(String message) {

        Alert alert = new Alert(
                Alert.AlertType.INFORMATION,
                message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR,
                message == null
                        ? "An unexpected error occurred."
                        : message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
