
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AdminFeeDAO;
import com.college.campustrack.model.User;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminFeeView {

    private final AdminFeeDAO dao = new AdminFeeDAO();

    private final ListView<String> feeList = new ListView<>();

    private List<String[]> feeRows = new ArrayList<>();
    private List<String[]> visibleFeeRows = new ArrayList<>();

    private int selectedFeeId = -1;

    private static final Locale INDIA =
            new Locale("en", "IN");

    public void show(Stage stage) {

        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            showError("Please log in as an administrator.");
            return;
        }

        selectedFeeId = -1;

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("ADMIN PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: #2563eb;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("Fee Management");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Assign fees, monitor balances, and record payments."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox headingBox = new VBox(
                5, eyebrow, heading, subtitle
        );

        Button back = new Button("← Back to Dashboard");
        back.setStyle(secondaryButtonStyle());

        back.setOnAction(e ->
                new AdminDashboardView().show(stage)
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16, headingBox, headerSpacer, back
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= BANNER =================

        Label bannerTag = new Label(
                "ADMINISTRATION • STUDENT FINANCES"
        );
        bannerTag.setStyle(
                "-fx-text-fill: #bfdbfe;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label bannerTitle = new Label(
                "Stay on top of student fees."
        );
        bannerTitle.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;"
        );
        bannerTitle.setWrapText(true);

        Label bannerText = new Label(
                "Manage fee assignments, track outstanding " +
                        "balances, and record payments."
        );
        bannerText.setStyle(
                "-fx-text-fill: #dbeafe;" +
                        "-fx-font-size: 13px;"
        );
        bannerText.setWrapText(true);

        VBox banner = new VBox(
                10, bannerTag, bannerTitle, bannerText
        );
        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, #14233e, #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= STUDENT SEARCH =================

        TextField search = new TextField();
        search.setPromptText(
                "Search by student name or roll number"
        );
        search.setMaxWidth(Double.MAX_VALUE);

        Button find = new Button("Search Students");
        find.setStyle(primaryButtonStyle());

        HBox searchRow = new HBox(12, search, find);
        searchRow.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(search, Priority.ALWAYS);

        ComboBox<String> student = new ComboBox<>();
        student.setPromptText("Select student from results");
        student.setMaxWidth(Double.MAX_VALUE);

        Label studentHint = description(
                "Search for a student, then select them to " +
                        "view or manage their fees."
        );

        VBox searchCard = createCard(
                sectionTitle("Find Student"),
                studentHint,
                searchRow,
                student
        );

        // ================= FEE FORM =================

        Label mode = new Label("ASSIGN NEW FEE");
        mode.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 9 14;" +
                        "-fx-background-radius: 16;"
        );

        TextField feeType = new TextField();
        feeType.setPromptText("e.g. Tuition Fee");

        TextField amount = new TextField();
        amount.setPromptText("e.g. 25000.00");

        DatePicker dueDate = new DatePicker(
                LocalDate.now().plusMonths(1)
        );

        GridPane form = createFormGrid();

        addField(form, 0, 0, "FEE TYPE", feeType);
        addField(form, 1, 0, "TOTAL AMOUNT (₹)", amount);
        addField(form, 0, 1, "DUE DATE", dueDate);

        Label formHint = description(
                "When editing an existing fee, previously " +
                        "recorded payments remain unchanged."
        );

        Button assign = new Button("Assign Fee");
        Button update = new Button("Save Changes");
        Button delete = new Button("Delete Unpaid Fee");
        Button clear = new Button("Clear / New Fee");

        assign.setStyle(primaryButtonStyle());
        update.setStyle(primaryButtonStyle());

        delete.setStyle(
                "-fx-background-color: #fee2e2;" +
                        "-fx-text-fill: #b91c1c;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;"
        );

        clear.setStyle(secondaryButtonStyle());

        update.setDisable(true);
        delete.setDisable(true);

        HBox actions = new HBox(
                12, assign, update, delete, clear
        );
        actions.setAlignment(Pos.CENTER_LEFT);

        VBox formCard = createCard(
                mode,
                sectionTitle("Fee Details"),
                description(
                        "Assign a new fee or select an existing " +
                                "record to update its details."
                ),
                form,
                formHint,
                actions
        );

        // ================= SUMMARY CARDS =================

        Label totalValue = new Label("₹0.00");
        Label paidValue = new Label("₹0.00");
        Label balanceValue = new Label("₹0.00");

        HBox summaryCards = new HBox(
                16,
                createStatCard("TOTAL FEES", totalValue),
                createStatCard("TOTAL PAID", paidValue),
                createStatCard("OUTSTANDING", balanceValue)
        );

        // ================= FEE RECORDS =================

        Label recordsTitle = sectionTitle(
                "Student Fee Records"
        );

        Label recordsHint = description(
                "Select a fee to edit its details, " +
                        "record a payment, or delete it if unpaid."
        );

        TextField feeSearch = new TextField();
        feeSearch.setPromptText(
                "Filter by fee type, status, or due date"
        );

        feeSearch.setMaxWidth(Double.MAX_VALUE);

        feeList.setPrefHeight(320);
        feeList.setMinHeight(240);

        feeList.setPlaceholder(
                new Label("No fee records found.")
        );

        feeList.setCellFactory(list ->
                new ListCell<>() {

                    @Override
                    protected void updateItem(
                            String item,
                            boolean empty
                    ) {

                        super.updateItem(item, empty);

                        if (empty || item == null) {
                            setText(null);
                            setGraphic(null);
                        } else {
                            setText(item);
                            setWrapText(true);
                        }
                    }
                }
        );

        Label countLabel = description("0 fee records");

        Button refresh = new Button("↻ Refresh Fees");
        refresh.setStyle(secondaryButtonStyle());

        Region recordsSpacer = new Region();
        HBox.setHgrow(recordsSpacer, Priority.ALWAYS);

        HBox recordsToolbar = new HBox(
                12, countLabel, recordsSpacer, refresh
        );
        recordsToolbar.setAlignment(Pos.CENTER_LEFT);

        VBox recordsCard = createCard(
                recordsTitle,
                recordsHint,
                feeSearch,
                feeList,
                recordsToolbar
        );

        // ================= PAYMENT SECTION =================

        Label selectedFee = new Label(
                "Select a fee record to view its payment details."
        );

        selectedFee.setWrapText(true);
        selectedFee.setStyle(
                "-fx-text-fill: #334155;" +
                        "-fx-font-size: 13px;"
        );

        TextField payment = new TextField();
        payment.setPromptText(
                "Enter payment amount, e.g. 5000.00"
        );

        Button record = new Button("Record Payment");
        record.setStyle(primaryButtonStyle());
        record.setDisable(true);

        HBox paymentRow = new HBox(
                12, payment, record
        );
        paymentRow.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(payment, Priority.ALWAYS);

        VBox paymentCard = createCard(
                sectionTitle("Record Payment"),
                description(
                        "Payments are added to the selected " +
                                "fee's existing paid amount."
                ),
                selectedFee,
                paymentRow
        );

        // ================= RESET FORM =================

        Runnable reset = () -> {

            selectedFeeId = -1;

            feeList.getSelectionModel()
                    .clearSelection();

            feeType.clear();
            amount.clear();
            dueDate.setValue(
                    LocalDate.now().plusMonths(1)
            );

            payment.clear();

            selectedFee.setText(
                    "Select a fee record to view its payment details."
            );

            mode.setText("ASSIGN NEW FEE");

            assign.setDisable(false);
            update.setDisable(true);
            delete.setDisable(true);
            record.setDisable(true);
        };

        // ================= STUDENT SEARCH =================

        find.setOnAction(event -> {

            try {

                reset.run();

                student.getItems().clear();
                student.setValue(null);

                feeRows = new ArrayList<>();
                filterFees(
                        feeSearch.getText(),
                        countLabel
                );

                updateSummary(
                        totalValue,
                        paidValue,
                        balanceValue
                );

                for (String[] s :
                        dao.searchStudents(search.getText())) {

                    student.getItems().add(
                            s[0] + " - " + s[1] + " - " + s[2]
                    );
                }

                if (student.getItems().isEmpty()) {

                    showMessage("No students found.");
                }

            } catch (Exception e) {

                showError(
                        "Unable to search students: " +
                                e.getMessage()
                );
            }
        });

        search.setOnAction(event -> find.fire());

        // ================= STUDENT SELECTION =================

        student.setOnAction(event -> {

            reset.run();

            refreshFees(
                    student,
                    feeSearch.getText(),
                    countLabel,
                    totalValue,
                    paidValue,
                    balanceValue
            );
        });

        // ================= SELECT FEE =================

        feeList.getSelectionModel()
                .selectedIndexProperty()
                .addListener((obs, oldValue, newValue) -> {

                    int index = newValue.intValue();

                    if (index < 0
                            || index >= visibleFeeRows.size()) {
                        return;
                    }

                    String[] fee = visibleFeeRows.get(index);

                    try {

                        selectedFeeId =
                                Integer.parseInt(fee[0]);

                        feeType.setText(fee[1]);
                        amount.setText(fee[2]);
                        dueDate.setValue(
                                LocalDate.parse(fee[4])
                        );

                        payment.clear();

                        BigDecimal total =
                                new BigDecimal(fee[2]);

                        BigDecimal paid =
                                new BigDecimal(fee[3]);

                        BigDecimal balance =
                                total.subtract(paid);

                        selectedFee.setText(
                                "Selected Fee #" + fee[0] +
                                        "\nPaid: " + money(paid) +
                                        "   |   Balance: " +
                                        money(balance) +
                                        "\nStatus: " + fee[5]
                        );

                        mode.setText(
                                "EDITING FEE #" + fee[0]
                        );

                        assign.setDisable(true);
                        update.setDisable(false);

                        delete.setDisable(
                                paid.signum() != 0
                        );

                        record.setDisable(
                                paid.compareTo(total) >= 0
                        );

                    } catch (Exception e) {

                        showError(
                                "Unable to load selected fee: " +
                                        e.getMessage()
                        );
                    }
                });

        // ================= ASSIGN FEE =================

        assign.setOnAction(event -> {

            try {

                int studentId =
                        requireStudent(student);

                BigDecimal total =
                        parsePositiveMoney(amount.getText());

                requireFeeType(feeType.getText());
                requireDueDate(dueDate.getValue());

                dao.assignFee(
                        studentId,
                        feeType.getText().trim(),
                        total,
                        dueDate.getValue()
                );

                reset.run();

                refreshFees(
                        student,
                        feeSearch.getText(),
                        countLabel,
                        totalValue,
                        paidValue,
                        balanceValue
                );

                showMessage(
                        "Fee assigned successfully!"
                );

            } catch (Exception e) {

                showError(
                        "Unable to assign fee: " +
                                e.getMessage()
                );
            }
        });

        // ================= UPDATE FEE =================

        update.setOnAction(event -> {

            try {

                int studentId =
                        requireStudent(student);

                if (selectedFeeId <= 0) {

                    throw new IllegalArgumentException(
                            "Please select a fee to edit."
                    );
                }

                BigDecimal total =
                        parsePositiveMoney(amount.getText());

                requireFeeType(feeType.getText());
                requireDueDate(dueDate.getValue());

                dao.updateFee(
                        selectedFeeId,
                        studentId,
                        feeType.getText().trim(),
                        total,
                        dueDate.getValue()
                );

                reset.run();

                refreshFees(
                        student,
                        feeSearch.getText(),
                        countLabel,
                        totalValue,
                        paidValue,
                        balanceValue
                );

                showMessage(
                        "Fee updated successfully!"
                );

            } catch (Exception e) {

                showError(
                        "Unable to update fee: " +
                                e.getMessage()
                );
            }
        });

        // ================= DELETE UNPAID FEE =================

        delete.setOnAction(event -> {

            try {

                int studentId =
                        requireStudent(student);

                if (selectedFeeId <= 0) {

                    throw new IllegalArgumentException(
                            "Please select a fee to delete."
                    );
                }

                Alert confirm = new Alert(
                        Alert.AlertType.CONFIRMATION,
                        "Delete this unpaid fee?\n\n" +
                                "Only records with no payments " +
                                "can be deleted.\n" +
                                "This action cannot be undone.",
                        ButtonType.YES,
                        ButtonType.NO
                );

                confirm.setTitle(
                        "Confirm Fee Deletion"
                );

                if (confirm.showAndWait()
                        .orElse(ButtonType.NO)
                        != ButtonType.YES) {
                    return;
                }

                dao.deleteUnpaidFee(
                        selectedFeeId,
                        studentId
                );

                reset.run();

                refreshFees(
                        student,
                        feeSearch.getText(),
                        countLabel,
                        totalValue,
                        paidValue,
                        balanceValue
                );

                showMessage(
                        "Unpaid fee deleted successfully!"
                );

            } catch (Exception e) {

                showError(
                        "Unable to delete fee: " +
                                e.getMessage()
                );
            }
        });

        // ================= RECORD PAYMENT =================

        record.setOnAction(event -> {

            try {

                if (selectedFeeId <= 0) {

                    throw new IllegalArgumentException(
                            "Please select a fee."
                    );
                }

                BigDecimal paymentAmount =
                        parsePositiveMoney(payment.getText());

                dao.recordPayment(
                        selectedFeeId,
                        paymentAmount
                );

                reset.run();

                refreshFees(
                        student,
                        feeSearch.getText(),
                        countLabel,
                        totalValue,
                        paidValue,
                        balanceValue
                );

                showMessage(
                        "Payment recorded successfully!"
                );

            } catch (Exception e) {

                showError(
                        "Unable to record payment: " +
                                e.getMessage()
                );
            }
        });

        // ================= CLEAR / REFRESH =================

        clear.setOnAction(event -> reset.run());

        refresh.setOnAction(event -> {

            reset.run();

            refreshFees(
                    student,
                    feeSearch.getText(),
                    countLabel,
                    totalValue,
                    paidValue,
                    balanceValue
            );
        });

        // ================= FILTER FEE RECORDS =================

        feeSearch.textProperty().addListener(
                (obs, oldValue, newValue) -> {

                    reset.run();

                    filterFees(
                            newValue,
                            countLabel
                    );
                }
        );

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Admin Fee Management"
        );

        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;"
        );

        // ================= MAIN LAYOUT =================

        VBox content = new VBox(
                24,
                header,
                banner,
                searchCard,
                formCard,
                summaryCards,
                recordsCard,
                paymentCard,
                footer
        );

        content.setPadding(
                new Insets(32, 36, 32, 36)
        );

        content.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);

        scroll.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );

        Scene scene = new Scene(
                scroll,
                1120,
                750
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Fee Management"
        );

        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= LOAD STUDENT FEES =================

    private void refreshFees(
            ComboBox<String> student,
            String query,
            Label countLabel,
            Label totalValue,
            Label paidValue,
            Label balanceValue
    ) {

        feeList.getSelectionModel().clearSelection();
        feeList.getItems().clear();

        feeRows = new ArrayList<>();
        visibleFeeRows = new ArrayList<>();

        selectedFeeId = -1;

        if (student.getValue() == null) {

            countLabel.setText("0 fee records");

            updateSummary(
                    totalValue,
                    paidValue,
                    balanceValue
            );

            return;
        }

        try {

            int studentId =
                    getId(student.getValue());

            feeRows = dao.getFees(studentId);

            filterFees(query, countLabel);

            updateSummary(
                    totalValue,
                    paidValue,
                    balanceValue
            );

        } catch (Exception e) {

            showError(
                    "Unable to load fees: " +
                            e.getMessage()
            );
        }
    }

    // ================= FILTER FEES =================

    private void filterFees(
            String query,
            Label countLabel
    ) {

        String text = query == null
                ? ""
                : query.trim().toLowerCase(Locale.ENGLISH);

        visibleFeeRows = new ArrayList<>();

        feeList.getSelectionModel()
                .clearSelection();

        feeList.getItems().clear();

        for (String[] fee : feeRows) {

            String display = formatFee(fee);

            if (display.toLowerCase(Locale.ENGLISH)
                    .contains(text)) {

                visibleFeeRows.add(fee);
                feeList.getItems().add(display);
            }
        }

        countLabel.setText(
                visibleFeeRows.size() +
                        (visibleFeeRows.size() == 1
                                ? " fee record"
                                : " fee records")
        );
    }

    // ================= FORMAT FEE =================

    private String formatFee(String[] fee) {

        BigDecimal total =
                new BigDecimal(fee[2]);

        BigDecimal paid =
                new BigDecimal(fee[3]);

        BigDecimal balance =
                total.subtract(paid);

        return fee[1] + "  •  " + fee[5] +
                "\nTotal: " + money(total) +
                "   |   Paid: " + money(paid) +
                "   |   Balance: " + money(balance) +
                "\nDue: " + fee[4] +
                "   |   Fee ID: " + fee[0];
    }

    // ================= UPDATE SUMMARY =================

    private void updateSummary(
            Label totalValue,
            Label paidValue,
            Label balanceValue
    ) {

        BigDecimal total = BigDecimal.ZERO;
        BigDecimal paid = BigDecimal.ZERO;

        for (String[] fee : feeRows) {

            total = total.add(
                    new BigDecimal(fee[2])
            );

            paid = paid.add(
                    new BigDecimal(fee[3])
            );
        }

        totalValue.setText(money(total));
        paidValue.setText(money(paid));

        balanceValue.setText(
                money(total.subtract(paid))
        );
    }

    // ================= SUMMARY CARD =================

    private VBox createStatCard(
            String title,
            Label value
    ) {

        Label caption = new Label(title);

        caption.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        value.setStyle(
                "-fx-text-fill: #14233e;" +
                        "-fx-font-size: 22px;" +
                        "-fx-font-weight: bold;"
        );

        VBox card = new VBox(
                10, caption, value
        );

        card.getStyleClass().add(
                "dashboard-card"
        );

        card.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(card, Priority.ALWAYS);

        return card;
    }

    // ================= UI HELPERS =================

    private VBox createCard(
            javafx.scene.Node... children
    ) {

        VBox card = new VBox(18, children);
        card.getStyleClass().add("content-card");
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    private GridPane createFormGrid() {

        GridPane grid = new GridPane();

        grid.setHgap(18);
        grid.setVgap(16);

        ColumnConstraints left =
                new ColumnConstraints();

        ColumnConstraints right =
                new ColumnConstraints();

        left.setPercentWidth(50);
        right.setPercentWidth(50);

        grid.getColumnConstraints().addAll(
                left, right
        );

        return grid;
    }

    private void addField(
            GridPane grid,
            int column,
            int row,
            String labelText,
            Control control
    ) {

        Label label = new Label(labelText);

        label.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        control.setMaxWidth(Double.MAX_VALUE);

        VBox field = new VBox(
                8, label, control
        );

        grid.add(field, column, row);
    }

    private Label sectionTitle(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-text-fill: #14233e;" +
                        "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;"
        );

        return label;
    }

    private Label description(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        label.setWrapText(true);

        return label;
    }

    private String primaryButtonStyle() {

        return "-fx-background-color: #2563eb;" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 11 17;" +
                "-fx-background-radius: 9;";
    }

    private String secondaryButtonStyle() {

        return "-fx-background-color: #f1f5f9;" +
                "-fx-text-fill: #334155;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 11 17;" +
                "-fx-background-radius: 9;";
    }

    // ================= DATA VALIDATION =================

    private int requireStudent(
            ComboBox<String> student
    ) {

        if (student.getValue() == null) {

            throw new IllegalArgumentException(
                    "Please select a student."
            );
        }

        return getId(student.getValue());
    }

    private int getId(String value) {

        return Integer.parseInt(
                value.split(" - ", 2)[0]
        );
    }

    private void requireFeeType(String value) {

        if (value == null || value.isBlank()) {

            throw new IllegalArgumentException(
                    "Please enter a fee type."
            );
        }
    }

    private void requireDueDate(LocalDate date) {

        if (date == null) {

            throw new IllegalArgumentException(
                    "Please select a due date."
            );
        }
    }

    private BigDecimal parsePositiveMoney(String value) {

        if (value == null || value.isBlank()) {

            throw new IllegalArgumentException(
                    "Please enter an amount."
            );
        }

        try {

            BigDecimal result =
                    new BigDecimal(value.trim());

            if (result.signum() <= 0) {

                throw new IllegalArgumentException(
                        "Amount must be greater than zero."
                );
            }

            return result;

        } catch (NumberFormatException e) {

            throw new IllegalArgumentException(
                    "Enter a valid amount, e.g. 25000.00."
            );
        }
    }

    private String money(BigDecimal value) {

        return NumberFormat
                .getCurrencyInstance(INDIA)
                .format(value);
    }

    // ================= ALERTS =================

    private void showMessage(String message) {

        Alert alert = new Alert(
                Alert.AlertType.INFORMATION,
                message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR,
                message == null
                        ? "An unexpected error occurred."
                        : message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
