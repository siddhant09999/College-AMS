
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.MarkDAO;
import com.college.campustrack.model.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MarksView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"STUDENT".equals(user.role())
                || user.studentId() == null) {

            showError("Please log in as a student.");
            return;
        }

        // ================= LOAD RESULTS =================

        List<String[]> studentMarks;

        try {
            studentMarks = new MarkDAO()
                    .getMarksForStudent(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load student marks.");
            return;
        }

        // ================= SUMMARY CALCULATIONS =================

        Set<String> subjects = new HashSet<>();
        Set<String> exams = new HashSet<>();

        for (String[] row : studentMarks) {

            if (row.length > 0 && row[0] != null) {
                subjects.add(row[0]);
            }

            if (row.length > 1 && row[1] != null) {
                exams.add(row[1]);
            }
        }

        int resultCount = studentMarks.size();
        int subjectCount = subjects.size();
        int examCount = exams.size();

        // ================= SHARED SIDEBAR =================

        VBox sidebar = Sidebar.create(stage);
        sidebar.setPrefWidth(260);
        sidebar.setMinWidth(230);

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("STUDENT PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("Marks & Results");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "View your subject-wise academic results."
        );
        subtitle.getStyleClass().add("page-subtitle");

        VBox headerText = new VBox(
                5,
                eyebrow,
                heading,
                subtitle
        );

        Label badge = new Label("●  ACADEMICS");
        badge.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10 14;" +
                        "-fx-background-radius: 20;"
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                headerText,
                headerSpacer,
                badge
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= RESULTS BANNER =================

        Label bannerTag = new Label(
                "YOUR ACADEMIC PERFORMANCE"
        );
        bannerTag.setStyle(
                "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #bfdbfe;"
        );

        Label bannerTitle = new Label(
                "Your results, all in one place."
        );
        bannerTitle.setStyle(
                "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Explore your recorded marks and grades " +
                        "across subjects and examinations."
        );
        bannerDescription.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #dbeafe;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= SUMMARY CARDS =================

        VBox resultsCard = createStatCard(
                "RS",
                "Results",
                String.valueOf(resultCount),
                "Recorded result entries",
                "#dbeafe",
                "#1d4ed8"
        );

        VBox subjectsCard = createStatCard(
                "SB",
                "Subjects",
                String.valueOf(subjectCount),
                "Subjects with results",
                "#dcfce7",
                "#15803d"
        );

        VBox examsCard = createStatCard(
                "EX",
                "Exam Types",
                String.valueOf(examCount),
                "Distinct exam names",
                "#f3e8ff",
                "#7e22ce"
        );

        HBox stats = new HBox(
                18,
                resultsCard,
                subjectsCard,
                examsCard
        );

        for (VBox card : new VBox[]{
                resultsCard,
                subjectsCard,
                examsCard
        }) {

            HBox.setHgrow(card, Priority.ALWAYS);
            card.setMaxWidth(Double.MAX_VALUE);

            card.prefWidthProperty().bind(
                    stats.widthProperty()
                            .subtract(36)
                            .divide(3)
            );
        }

        // ================= RESULTS SECTION =================

        Label sectionTitle = new Label(
                "Subject-wise Results"
        );
        sectionTitle.getStyleClass().add("section-title");

        Label sectionSubtitle = new Label(
                "Your recorded marks and grades for each exam."
        );
        sectionSubtitle.getStyleClass().add("page-subtitle");

        VBox sectionHeading = new VBox(
                4,
                sectionTitle,
                sectionSubtitle
        );

        // ================= RESULTS TABLE =================

        TableView<String[]> marksTable = new TableView<>();

        TableColumn<String[], String> subjectColumn =
                new TableColumn<>("Subject");

        subjectColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 0)
                )
        );

        TableColumn<String[], String> examColumn =
                new TableColumn<>("Exam");

        examColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 1)
                )
        );

        TableColumn<String[], String> marksColumn =
                new TableColumn<>("Marks");

        marksColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 2)
                )
        );

        TableColumn<String[], String> gradeColumn =
                new TableColumn<>("Grade");

        gradeColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 3)
                )
        );

        marksTable.getColumns().addAll(
                subjectColumn,
                examColumn,
                marksColumn,
                gradeColumn
        );

        marksTable.getItems().addAll(studentMarks);

        marksTable.setPlaceholder(
                new Label("No exam results available yet.")
        );

        marksTable.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        marksTable.setPrefHeight(
                Math.max(
                        280,
                        Math.min(520, 55 + resultCount * 42)
                )
        );

        marksTable.setMinHeight(280);
        marksTable.setMaxWidth(Double.MAX_VALUE);

        // ================= TABLE CARD =================

        Label tableTitle = new Label("Examination Records");
        tableTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label tableDescription = new Label(
                resultCount == 1
                        ? "1 result available"
                        : resultCount + " results available"
        );
        tableDescription.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );

        VBox tableHeader = new VBox(
                5,
                tableTitle,
                tableDescription
        );

        VBox tableCard = new VBox(
                18,
                tableHeader,
                marksTable
        );

        tableCard.getStyleClass().add("content-card");
        tableCard.setMaxWidth(Double.MAX_VALUE);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Student Results"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-padding: 10 0 0 0;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                stats,
                sectionHeading,
                tableCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );
        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );

        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT LAYOUT =================

        BorderPane root = new BorderPane();

        root.setLeft(sidebar);
        root.setCenter(scrollPane);

        Scene scene = new Scene(
                root,
                1120,
                720
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Marks & Results"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= SUMMARY CARD HELPER =================

    private VBox createStatCard(
            String initials,
            String title,
            String value,
            String description,
            String iconBackground,
            String iconColor
    ) {

        Label icon = new Label(initials);
        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(42, 42);
        icon.setPrefSize(42, 42);
        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 11;"
        );

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;" +
                        "-fx-font-weight: bold;"
        );

        Label valueLabel = new Label(value);
        valueLabel.setStyle(
                "-fx-font-size: 27px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label descriptionLabel = new Label(description);
        descriptionLabel.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-text-fill: #94a3b8;"
        );
        descriptionLabel.setWrapText(true);

        VBox card = new VBox(
                12,
                icon,
                titleLabel,
                valueLabel,
                descriptionLabel
        );

        card.getStyleClass().add("dashboard-card");
        card.setPadding(new Insets(22));
        card.setMinHeight(180);
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= SAFE TABLE VALUES =================

    private String getValue(String[] row, int index) {

        if (row == null
                || index >= row.length
                || row[index] == null) {

            return "N/A";
        }

        return row[index];
    }

    // ================= ERROR HANDLING =================

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText("Marks Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
