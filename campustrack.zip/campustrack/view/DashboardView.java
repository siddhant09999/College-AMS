
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AttendanceDAO;
import com.college.campustrack.dao.FeeDAO;
import com.college.campustrack.dao.TimetableDAO;
import com.college.campustrack.model.Student;
import com.college.campustrack.model.User;
import com.college.campustrack.service.StudentService;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

public class DashboardView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"STUDENT".equals(user.role())
                || user.studentId() == null) {

            showError("Please log in as a student.");
            return;
        }

        // ================= STUDENT INFORMATION =================

        Student student;

        try {
            student = new StudentService().get(user.studentId());

            if (student == null) {
                showError("Student record not found.");
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load student information.");
            return;
        }

        // ================= ATTENDANCE DATA =================

        List<String[]> attendanceSummary;

        try {
            attendanceSummary = new AttendanceDAO()
                    .getAttendanceSummary(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load attendance information.");
            return;
        }

        int totalAttended = 0;
        int totalClasses = 0;

        for (String[] row : attendanceSummary) {
            totalAttended += Integer.parseInt(row[1]);
            totalClasses += Integer.parseInt(row[2]);
        }

        String attendancePercentage = totalClasses == 0
                ? "N/A"
                : String.format(
                Locale.ENGLISH,
                "%.1f%%",
                totalAttended * 100.0 / totalClasses
        );

        int subjectCount = attendanceSummary.size();

        // ================= FEE DATA =================

        List<String[]> studentFees;

        try {
            studentFees = new FeeDAO()
                    .getFeesForStudent(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load fee information.");
            return;
        }

        String feeStatus;

        if (studentFees.isEmpty()) {
            feeStatus = "N/A";

        } else {

            boolean allPaid = true;
            boolean anyPaid = false;

            for (String[] fee : studentFees) {

                String status = fee[3];

                if (!"PAID".equalsIgnoreCase(status)) {
                    allPaid = false;
                }

                if ("PAID".equalsIgnoreCase(status)
                        || "PARTIAL".equalsIgnoreCase(status)) {
                    anyPaid = true;
                }
            }

            if (allPaid) {
                feeStatus = "Paid";

            } else if (anyPaid) {
                feeStatus = "Partial";

            } else {
                feeStatus = "Pending";
            }
        }

        // ================= TIMETABLE DATA =================

        List<String[]> weeklyTimetable;

        try {
            weeklyTimetable = new TimetableDAO()
                    .getTimetableForStudent(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load today's classes.");
            return;
        }

        String today = LocalDate.now()
                .getDayOfWeek()
                .getDisplayName(
                        TextStyle.FULL,
                        Locale.ENGLISH
                );

        StringBuilder todayClasses = new StringBuilder();

        int todayClassCount = 0;

        for (String[] classRow : weeklyTimetable) {

            if (today.equalsIgnoreCase(classRow[0])) {

                todayClassCount++;

                if (todayClasses.length() > 0) {
                    todayClasses.append("\n\n");
                }

                todayClasses
                        .append(classRow[1])
                        .append("    ")
                        .append(classRow[2])
                        .append("    ")
                        .append(classRow[3]);
            }
        }

        if (todayClassCount == 0) {
            todayClasses.append(
                    "No classes scheduled for today."
            );
        }

        // ================= EXISTING STUDENT SIDEBAR =================

        // Preserves all working student navigation.
        VBox sidebar = Sidebar.create(stage);

        sidebar.setPrefWidth(260);
        sidebar.setMinWidth(230);

        // ================= HEADER =================

        Label eyebrow = new Label("STUDENT WORKSPACE");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("My Dashboard");
        heading.getStyleClass().add("page-title");

        Label welcome = new Label(
                "Here's your academic overview, "
                        + student.name() + "."
        );
        welcome.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );
        welcome.setWrapText(true);

        VBox headerText = new VBox(
                5,
                eyebrow,
                heading,
                welcome
        );

        Label roleBadge = new Label("●  STUDENT");
        roleBadge.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10 14;" +
                        "-fx-background-radius: 20;"
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(
                headerSpacer,
                Priority.ALWAYS
        );

        HBox header = new HBox(
                16,
                headerText,
                headerSpacer,
                roleBadge
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= WELCOME BANNER =================

        Label bannerTag = new Label(
                "CAMPUS TRACK  •  STUDENT PORTAL"
        );
        bannerTag.setStyle(
                "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #bfdbfe;"
        );

        Label bannerTitle = new Label(
                "Welcome back, " + student.name() + "!"
        );
        bannerTitle.setStyle(
                "-fx-font-size: 22px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Stay on top of your attendance, " +
                        "academics, fees, and daily schedule."
        );
        bannerDescription.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #dbeafe;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= SUMMARY SECTION =================

        Label overviewTitle = new Label(
                "Academic Overview"
        );
        overviewTitle.getStyleClass().add("section-title");

        Label overviewSubtitle = new Label(
                "Your important information at a glance."
        );
        overviewSubtitle.getStyleClass().add(
                "page-subtitle"
        );

        VBox overviewHeading = new VBox(
                4,
                overviewTitle,
                overviewSubtitle
        );

        VBox attendanceCard = createStatCard(
                "AT",
                "Attendance",
                attendancePercentage,
                "Overall attendance",
                "#dbeafe",
                "#1d4ed8"
        );

        VBox subjectsCard = createStatCard(
                "SB",
                "Subjects",
                String.valueOf(subjectCount),
                "Subjects with attendance records",
                "#dcfce7",
                "#15803d"
        );

        VBox feesCard = createStatCard(
                "FE",
                "Fee Status",
                feeStatus,
                "Current payment status",
                "#fef3c7",
                "#b45309"
        );

        HBox stats = new HBox(
                18,
                attendanceCard,
                subjectsCard,
                feesCard
        );

        for (VBox card : new VBox[]{
                attendanceCard,
                subjectsCard,
                feesCard
        }) {
            HBox.setHgrow(card, Priority.ALWAYS);
            card.setMaxWidth(Double.MAX_VALUE);

            card.prefWidthProperty().bind(
                    stats.widthProperty()
                            .subtract(36)
                            .divide(3)
            );
        }

        // ================= TODAY'S CLASSES =================

        Label classesTitle = new Label(
                "Today's Classes"
        );
        classesTitle.getStyleClass().add("section-title");

        Label dayBadge = new Label(today.toUpperCase(Locale.ENGLISH));
        dayBadge.setStyle(
                "-fx-background-color: #eff6ff;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 8 12;" +
                        "-fx-background-radius: 20;"
        );

        Region classesHeaderSpacer = new Region();
        HBox.setHgrow(
                classesHeaderSpacer,
                Priority.ALWAYS
        );

        HBox classesHeader = new HBox(
                12,
                classesTitle,
                classesHeaderSpacer,
                dayBadge
        );
        classesHeader.setAlignment(Pos.CENTER_LEFT);

        Label classesCount = new Label(
                todayClassCount == 1
                        ? "1 class scheduled"
                        : todayClassCount + " classes scheduled"
        );
        classesCount.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );

        Label classes = new Label(
                todayClasses.toString()
        );
        classes.setWrapText(true);
        classes.setMaxWidth(Double.MAX_VALUE);
        classes.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-text-fill: #334155;" +
                        "-fx-line-spacing: 5;"
        );

        VBox classesPanel = new VBox(
                16,
                classesHeader,
                classesCount,
                classes
        );

        classesPanel.getStyleClass().add("content-card");
        classesPanel.setMaxWidth(Double.MAX_VALUE);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Student Portal"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-padding: 10 0 0 0;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                overviewHeading,
                stats,
                classesPanel,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );
        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT LAYOUT =================

        BorderPane root = new BorderPane();

        root.setLeft(sidebar);
        root.setCenter(scrollPane);

        Scene dashboardScene = new Scene(
                root,
                1120,
                720
        );

        StyleManager.applyStyles(dashboardScene);

        stage.setTitle(
                "CampusTrack - Student Dashboard"
        );
        stage.setScene(dashboardScene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= STAT CARD HELPER =================

    private VBox createStatCard(
            String initials,
            String title,
            String value,
            String description,
            String iconBackground,
            String iconColor
    ) {

        Label icon = new Label(initials);
        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(42, 42);
        icon.setPrefSize(42, 42);
        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 11;"
        );

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #64748b;" +
                        "-fx-font-weight: bold;"
        );

        Label valueLabel = new Label(value);
        valueLabel.setStyle(
                "-fx-font-size: 27px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label descriptionLabel = new Label(description);
        descriptionLabel.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-text-fill: #94a3b8;"
        );
        descriptionLabel.setWrapText(true);

        VBox textBox = new VBox(
                6,
                titleLabel,
                valueLabel,
                descriptionLabel
        );

        VBox card = new VBox(
                16,
                icon,
                textBox
        );

        card.getStyleClass().add("dashboard-card");

        card.setPadding(
                new Insets(22)
        );
        card.setMinHeight(180);
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= ERROR ALERT =================

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText("Dashboard Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
