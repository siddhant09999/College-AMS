
package com.college.campustrack.view;

import com.college.campustrack.Main;
import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.model.User;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminDashboardView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            return;
        }

        // ================= SIDEBAR =================

        Label logo = new Label("◈  CampusTrack");
        logo.getStyleClass().add("sidebar-logo");

        Label portalLabel = new Label("ADMIN PORTAL");
        portalLabel.setStyle(
                "-fx-text-fill: #93a8c5;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 0 12 8 12;"
        );

        Button dashboardNav = createNavButton(
                "⌂   Dashboard",
                () -> show(stage)
        );
        dashboardNav.getStyleClass().add("sidebar-button-active");

        Button studentsNav = createNavButton(
                "▣   Manage Students",
                () -> new AdminStudentView().show(stage)
        );

        Button facultyNav = createNavButton(
                "▣   Manage Faculty",
                () -> new AdminFacultyView().show(stage)
        );

        Button academicsNav = createNavButton(
                "▤   Courses & Subjects",
                () -> new AdminAcademicView().show(stage)
        );

        Button timetableNav = createNavButton(
                "▦   Manage Timetable",
                () -> new AdminTimetableView().show(stage)
        );

        Button feesNav = createNavButton(
                "▤   Manage Fees",
                () -> new AdminFeeView().show(stage)
        );

        Label accountLabel = new Label("SIGNED IN AS");
        accountLabel.setStyle(
                "-fx-text-fill: #93a8c5;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label usernameLabel = new Label(user.username());
        usernameLabel.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 14px;" +
                        "-fx-font-weight: bold;"
        );

        VBox accountBox = new VBox(5, accountLabel, usernameLabel);
        accountBox.setPadding(new Insets(12, 12, 10, 12));

        Button logoutButton = new Button("↪   Log Out");
        logoutButton.getStyleClass().add("logout-button");
        logoutButton.setMaxWidth(Double.MAX_VALUE);

        logoutButton.setOnAction(event -> {
            UserSession.logout();
            new Main().showLogin(stage);
        });

        Region sidebarSpacer = new Region();
        VBox.setVgrow(sidebarSpacer, Priority.ALWAYS);

        VBox sidebar = new VBox(
                10,
                logo,
                portalLabel,
                dashboardNav,
                studentsNav,
                facultyNav,
                academicsNav,
                timetableNav,
                feesNav,
                sidebarSpacer,
                accountBox,
                logoutButton
        );

        sidebar.getStyleClass().add("sidebar");
        sidebar.setPrefWidth(260);
        sidebar.setMinWidth(230);

        // ================= HEADER =================

        Label eyebrow = new Label("CAMPUS MANAGEMENT");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("Admin Dashboard");
        heading.getStyleClass().add("page-title");

        Label welcome = new Label(
                "Welcome back, " + user.username() + "!"
        );
        welcome.setStyle(
                "-fx-font-size: 15px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );

        VBox headerText = new VBox(
                5,
                eyebrow,
                heading,
                welcome
        );

        Label roleBadge = new Label("●  ADMINISTRATOR");
        roleBadge.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10 14;" +
                        "-fx-background-radius: 20;"
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                headerText,
                headerSpacer,
                roleBadge
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= WELCOME BANNER =================

        Label bannerTitle = new Label(
                "Your campus, organized."
        );
        bannerTitle.setStyle(
                "-fx-font-size: 22px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );

        Label bannerDescription = new Label(
                "Manage students, faculty, academics, " +
                        "timetables, and fees from one place."
        );
        bannerDescription.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #dbeafe;"
        );
        bannerDescription.setWrapText(true);

        Label bannerTag = new Label(
                "CAMPUS TRACK  •  ADMINISTRATION"
        );
        bannerTag.setStyle(
                "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #bfdbfe;"
        );

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(new Insets(26, 30, 26, 30));
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= MODULE CARDS =================

        Label modulesTitle = new Label("Management Modules");
        modulesTitle.getStyleClass().add("section-title");

        Label modulesSubtitle = new Label(
                "Choose a module to manage campus operations."
        );
        modulesSubtitle.getStyleClass().add("page-subtitle");

        VBox modulesHeading = new VBox(
                4,
                modulesTitle,
                modulesSubtitle
        );

        Button studentCard = createModuleCard(
                "ST",
                "Student Management",
                "Add, edit, search and manage student records.",
                "#dbeafe",
                "#1d4ed8",
                () -> new AdminStudentView().show(stage)
        );

        Button facultyCard = createModuleCard(
                "FC",
                "Faculty Management",
                "Manage faculty profiles and accounts.",
                "#dcfce7",
                "#15803d",
                () -> new AdminFacultyView().show(stage)
        );

        Button academicsCard = createModuleCard(
                "AC",
                "Courses & Subjects",
                "Organize departments, courses and subjects.",
                "#f3e8ff",
                "#7e22ce",
                () -> new AdminAcademicView().show(stage)
        );

        Button timetableCard = createModuleCard(
                "TT",
                "Timetable Management",
                "Schedule classes, faculty and classrooms.",
                "#fef3c7",
                "#b45309",
                () -> new AdminTimetableView().show(stage)
        );

        Button feesCard = createModuleCard(
                "FE",
                "Fees Management",
                "Assign fees and record student payments.",
                "#ffe4e6",
                "#be123c",
                () -> new AdminFeeView().show(stage)
        );

        GridPane cards = new GridPane();
        cards.setHgap(18);
        cards.setVgap(18);

        cards.add(studentCard, 0, 0);
        cards.add(facultyCard, 1, 0);

        cards.add(academicsCard, 0, 1);
        cards.add(timetableCard, 1, 1);

        cards.add(feesCard, 0, 2);

        studentCard.prefWidthProperty().bind(
                cards.widthProperty().subtract(18).divide(2)
        );
        facultyCard.prefWidthProperty().bind(
                cards.widthProperty().subtract(18).divide(2)
        );
        academicsCard.prefWidthProperty().bind(
                cards.widthProperty().subtract(18).divide(2)
        );
        timetableCard.prefWidthProperty().bind(
                cards.widthProperty().subtract(18).divide(2)
        );
        feesCard.prefWidthProperty().bind(
                cards.widthProperty().subtract(18).divide(2)
        );

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  College Management System"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-padding: 10 0 0 0;"
        );

        // ================= CONTENT =================

        VBox content = new VBox(
                24,
                header,
                banner,
                modulesHeading,
                cards,
                footer
        );

        content.setPadding(new Insets(32, 36, 32, 36));
        content.setStyle("-fx-background-color: #f1f5fb;");

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= MAIN LAYOUT =================

        BorderPane root = new BorderPane();
        root.setLeft(sidebar);
        root.setCenter(scrollPane);

        Scene scene = new Scene(root, 1120, 720);
        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Administration Dashboard"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= HELPER METHODS =================

    private Button createNavButton(
            String text,
            Runnable action
    ) {
        Button button = new Button(text);

        button.getStyleClass().add("sidebar-button");
        button.setMaxWidth(Double.MAX_VALUE);

        button.setOnAction(event -> action.run());

        return button;
    }

    private Button createModuleCard(
            String initials,
            String title,
            String description,
            String iconBackground,
            String iconColor,
            Runnable action
    ) {
        Label icon = new Label(initials);
        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(48, 48);
        icon.setPrefSize(48, 48);
        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 15px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 12;"
        );

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-text-fill: #14233e;" +
                        "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;"
        );
        titleLabel.setWrapText(true);

        Label descriptionLabel = new Label(description);
        descriptionLabel.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );
        descriptionLabel.setWrapText(true);

        VBox textBox = new VBox(
                8,
                titleLabel,
                descriptionLabel
        );

        textBox.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(textBox, Priority.ALWAYS);

        HBox cardContent = new HBox(
                18,
                icon,
                textBox
        );
        cardContent.setAlignment(Pos.CENTER_LEFT);

        Button card = new Button();
        card.setGraphic(cardContent);

        card.setContentDisplay(
                javafx.scene.control.ContentDisplay.GRAPHIC_ONLY
        );

        card.setAlignment(Pos.CENTER_LEFT);
        card.setMinHeight(125);
        card.setMaxWidth(Double.MAX_VALUE);

        card.setStyle(
                "-fx-background-color: white;" +
                        "-fx-background-radius: 16;" +
                        "-fx-border-color: #e2e8f0;" +
                        "-fx-border-radius: 16;" +
                        "-fx-border-width: 1;" +
                        "-fx-padding: 22;" +
                        "-fx-cursor: hand;" +
                        "-fx-effect: dropshadow(" +
                        "gaussian, rgba(15,23,42,0.06), 12, 0, 0, 3);"
        );

        card.setOnMouseEntered(event ->
                card.setStyle(
                        "-fx-background-color: #eff6ff;" +
                                "-fx-background-radius: 16;" +
                                "-fx-border-color: #93c5fd;" +
                                "-fx-border-radius: 16;" +
                                "-fx-border-width: 1;" +
                                "-fx-padding: 22;" +
                                "-fx-cursor: hand;"
                )
        );

        card.setOnMouseExited(event ->
                card.setStyle(
                        "-fx-background-color: white;" +
                                "-fx-background-radius: 16;" +
                                "-fx-border-color: #e2e8f0;" +
                                "-fx-border-radius: 16;" +
                                "-fx-border-width: 1;" +
                                "-fx-padding: 22;" +
                                "-fx-cursor: hand;" +
                                "-fx-effect: dropshadow(" +
                                "gaussian, rgba(15,23,42,0.06), 12, 0, 0, 3);"
                )
        );

        card.setOnAction(event -> action.run());

        return card;
    }
}
