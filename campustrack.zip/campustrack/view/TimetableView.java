
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.TimetableDAO;
import com.college.campustrack.model.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class TimetableView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"STUDENT".equals(user.role())
                || user.studentId() == null) {

            showError("Please log in as a student.");
            return;
        }

        // ================= LOAD REAL TIMETABLE =================

        List<String[]> studentTimetable;

        try {
            studentTimetable = new TimetableDAO()
                    .getTimetableForStudent(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load timetable.");
            return;
        }

        // ================= SUMMARY CALCULATIONS =================

        String today = LocalDate.now()
                .getDayOfWeek()
                .getDisplayName(
                        TextStyle.FULL,
                        Locale.ENGLISH
                );

        Set<String> subjects = new HashSet<>();
        int todayClassCount = 0;

        for (String[] row : studentTimetable) {

            String day = getValue(row, 0);
            String subject = getValue(row, 1);

            if (!"N/A".equals(subject)) {
                subjects.add(subject);
            }

            if (today.equalsIgnoreCase(day)) {
                todayClassCount++;
            }
        }

        int weeklyClassCount = studentTimetable.size();
        int subjectCount = subjects.size();

        // ================= SHARED SIDEBAR =================

        VBox sidebar = Sidebar.create(stage);
        sidebar.setPrefWidth(260);
        sidebar.setMinWidth(230);

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("STUDENT PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("My Timetable");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Your weekly class schedule, organized in one place."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox headerText = new VBox(
                5,
                eyebrow,
                heading,
                subtitle
        );

        Label badge = new Label("●  WEEKLY SCHEDULE");
        badge.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10 14;" +
                        "-fx-background-radius: 20;"
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16,
                headerText,
                headerSpacer,
                badge
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= WELCOME BANNER =================

        Label bannerTag = new Label(
                "YOUR WEEKLY CLASS SCHEDULE"
        );
        bannerTag.setStyle(
                "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #bfdbfe;"
        );

        Label bannerTitle = new Label(
                "Plan your week with confidence."
        );
        bannerTitle.setStyle(
                "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Check your subjects, class timings, " +
                        "and assigned rooms at a glance."
        );
        bannerDescription.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #dbeafe;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );

        banner.setPadding(
                new Insets(26, 30, 26, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= SUMMARY CARDS =================

        VBox weeklyCard = createStatCard(
                "WK",
                "Weekly Classes",
                String.valueOf(weeklyClassCount),
                "Scheduled class sessions",
                "#dbeafe",
                "#1d4ed8"
        );

        VBox subjectsCard = createStatCard(
                "SB",
                "Subjects",
                String.valueOf(subjectCount),
                "Subjects in your timetable",
                "#dcfce7",
                "#15803d"
        );

        VBox todayCard = createStatCard(
                "TD",
                "Today's Classes",
                String.valueOf(todayClassCount),
                today + "'s schedule",
                "#fef3c7",
                "#b45309"
        );

        HBox stats = new HBox(
                18,
                weeklyCard,
                subjectsCard,
                todayCard
        );

        for (VBox card : new VBox[]{
                weeklyCard,
                subjectsCard,
                todayCard
        }) {

            HBox.setHgrow(card, Priority.ALWAYS);
            card.setMaxWidth(Double.MAX_VALUE);

            card.prefWidthProperty().bind(
                    stats.widthProperty()
                            .subtract(36)
                            .divide(3)
            );
        }

        // ================= TIMETABLE SECTION =================

        Label sectionTitle = new Label(
                "Weekly Class Schedule"
        );
        sectionTitle.getStyleClass().add("section-title");

        Label sectionSubtitle = new Label(
                "All scheduled classes for your course."
        );
        sectionSubtitle.getStyleClass().add("page-subtitle");

        VBox sectionHeading = new VBox(
                4,
                sectionTitle,
                sectionSubtitle
        );

        // ================= TIMETABLE TABLE =================

        TableView<String[]> timetable = new TableView<>();

        TableColumn<String[], String> dayColumn =
                new TableColumn<>("Day");

        dayColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 0)
                )
        );

        TableColumn<String[], String> subjectColumn =
                new TableColumn<>("Subject");

        subjectColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 1)
                )
        );

        TableColumn<String[], String> timeColumn =
                new TableColumn<>("Time");

        timeColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 2)
                )
        );

        TableColumn<String[], String> roomColumn =
                new TableColumn<>("Room");

        roomColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        getValue(data.getValue(), 3)
                )
        );

        timetable.getColumns().addAll(
                dayColumn,
                subjectColumn,
                timeColumn,
                roomColumn
        );

        timetable.getItems().addAll(studentTimetable);

        timetable.setPlaceholder(
                new Label("No timetable available yet.")
        );

        timetable.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        // Highlight rows scheduled for today.
        timetable.setRowFactory(table -> new TableRow<>() {

            @Override
            protected void updateItem(
                    String[] row,
                    boolean empty
            ) {

                super.updateItem(row, empty);

                if (empty || row == null) {
                    setStyle("");
                    return;
                }

                String day = getValue(row, 0);

                if (today.equalsIgnoreCase(day)) {
                    setStyle(
                            "-fx-background-color: #eff6ff;" +
                                    "-fx-border-color: transparent " +
                                    "transparent #dbeafe transparent;"
                    );

                } else {
                    setStyle("");
                }
            }
        });

        timetable.setPrefHeight(
                Math.max(
                        280,
                        Math.min(
                                540,
                                55 + weeklyClassCount * 42
                        )
                )
        );

        timetable.setMinHeight(280);
        timetable.setMaxWidth(Double.MAX_VALUE);

        // ================= TABLE CARD =================

        Label tableTitle = new Label(
                "Class Timings & Rooms"
        );
        tableTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label tableDescription = new Label(
                weeklyClassCount == 1
                        ? "1 scheduled class"
                        : weeklyClassCount + " scheduled classes"
        );
        tableDescription.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: " + MUTED + ";"
        );

        VBox tableHeader = new VBox(
                5,
                tableTitle,
                tableDescription
        );

        VBox tableCard = new VBox(
                18,
                tableHeader,
                timetable
        );

        tableCard.getStyleClass().add("content-card");
        tableCard.setMaxWidth(Double.MAX_VALUE);

        // ================= TODAY'S SCHEDULE =================

        Label todayTitle = new Label(
                "Today's Schedule"
        );
        todayTitle.setStyle(
                "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label dayLabel = new Label(
                today.toUpperCase(Locale.ENGLISH)
        );
        dayLabel.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 7 12;" +
                        "-fx-background-radius: 16;"
        );

        Region todaySpacer = new Region();
        HBox.setHgrow(todaySpacer, Priority.ALWAYS);

        HBox todayHeader = new HBox(
                12,
                todayTitle,
                todaySpacer,
                dayLabel
        );
        todayHeader.setAlignment(Pos.CENTER_LEFT);

        VBox todayList = new VBox(12);

        for (String[] row : studentTimetable) {

            if (!today.equalsIgnoreCase(getValue(row, 0))) {
                continue;
            }

            Label subject = new Label(
                    getValue(row, 1)
            );
            subject.setStyle(
                    "-fx-font-size: 14px;" +
                            "-fx-font-weight: bold;" +
                            "-fx-text-fill: #14233e;"
            );

            Label details = new Label(
                    getValue(row, 2)
                            + "   •   Room "
                            + getValue(row, 3)
            );
            details.setStyle(
                    "-fx-font-size: 12px;" +
                            "-fx-text-fill: #64748b;"
            );
            details.setWrapText(true);

            VBox classEntry = new VBox(
                    5,
                    subject,
                    details
            );

            classEntry.setPadding(
                    new Insets(12, 14, 12, 14)
            );
            classEntry.setStyle(
                    "-fx-background-color: #f8fafc;" +
                            "-fx-background-radius: 10;" +
                            "-fx-border-color: #e2e8f0;" +
                            "-fx-border-radius: 10;"
            );

            todayList.getChildren().add(classEntry);
        }

        if (todayList.getChildren().isEmpty()) {

            Label emptyToday = new Label(
                    "No classes scheduled for today."
            );
            emptyToday.setStyle(
                    "-fx-font-size: 13px;" +
                            "-fx-text-fill: #64748b;"
            );

            todayList.getChildren().add(emptyToday);
        }

        VBox todayCardPanel = new VBox(
                18,
                todayHeader,
                todayList
        );

        todayCardPanel.getStyleClass().add("content-card");
        todayCardPanel.setMaxWidth(Double.MAX_VALUE);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Student Timetable"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-padding: 10 0 0 0;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                stats,
                sectionHeading,
                tableCard,
                todayCardPanel,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );
        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );

        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT LAYOUT =================

        BorderPane root = new BorderPane();

        root.setLeft(sidebar);
        root.setCenter(scrollPane);

        Scene scene = new Scene(
                root,
                1120,
                720
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - My Timetable"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= STAT CARD HELPER =================

    private VBox createStatCard(
            String initials,
            String title,
            String value,
            String description,
            String iconBackground,
            String iconColor
    ) {

        Label icon = new Label(initials);
        icon.setAlignment(Pos.CENTER);
        icon.setMinSize(42, 42);
        icon.setPrefSize(42, 42);
        icon.setStyle(
                "-fx-background-color: " + iconBackground + ";" +
                        "-fx-text-fill: " + iconColor + ";" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 11;"
        );

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #64748b;" +
                        "-fx-font-weight: bold;"
        );

        Label valueLabel = new Label(value);
        valueLabel.setStyle(
                "-fx-font-size: 27px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label descriptionLabel = new Label(description);
        descriptionLabel.setStyle(
                "-fx-font-size: 11px;" +
                        "-fx-text-fill: #94a3b8;"
        );
        descriptionLabel.setWrapText(true);

        VBox card = new VBox(
                12,
                icon,
                titleLabel,
                valueLabel,
                descriptionLabel
        );

        card.getStyleClass().add("dashboard-card");
        card.setPadding(new Insets(22));
        card.setMinHeight(180);
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    // ================= SAFE TABLE VALUES =================

    private String getValue(String[] row, int index) {

        if (row == null
                || index >= row.length
                || row[index] == null) {

            return "N/A";
        }

        return row[index];
    }

    // ================= ERROR HANDLING =================

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText("Timetable Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
