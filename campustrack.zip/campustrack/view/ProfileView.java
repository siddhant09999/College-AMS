
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.StudentDAO;
import com.college.campustrack.model.Student;
import com.college.campustrack.model.User;
import com.college.campustrack.service.StudentService;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ProfileView {

    private static final String NAVY = "#14233e";
    private static final String BLUE = "#2563eb";
    private static final String MUTED = "#64748b";

    public void show(Stage stage) {

        // ================= AUTHENTICATION =================

        User user = UserSession.getCurrentUser();

        if (user == null
                || !"STUDENT".equals(user.role())
                || user.studentId() == null) {

            showError("Please log in as a student.");
            return;
        }

        // ================= LOAD REAL STUDENT DATA =================

        Student student;
        String[] academicNames;

        try {
            student = new StudentService()
                    .get(user.studentId());

            if (student == null) {
                showError("Student record not found.");
                return;
            }

            academicNames = new StudentDAO()
                    .getDepartmentAndCourseNames(user.studentId());

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to load student profile.");
            return;
        }

        String departmentName =
                academicNames != null
                        && academicNames.length > 0
                        ? safe(academicNames[0])
                        : "Not available";

        String courseName =
                academicNames != null
                        && academicNames.length > 1
                        ? safe(academicNames[1])
                        : "Not available";

        // ================= SHARED SIDEBAR =================

        VBox sidebar = Sidebar.create(stage);
        sidebar.setPrefWidth(260);
        sidebar.setMinWidth(230);

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("STUDENT PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: " + BLUE + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label heading = new Label("My Profile");
        heading.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Your personal and academic information in one place."
        );
        subtitle.getStyleClass().add("page-subtitle");
        subtitle.setWrapText(true);

        VBox headerText = new VBox(
                5,
                eyebrow,
                heading,
                subtitle
        );

        Label badge = new Label("●  STUDENT PROFILE");
        badge.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10 14;" +
                        "-fx-background-radius: 20;"
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(
                headerSpacer,
                Priority.ALWAYS
        );

        HBox header = new HBox(
                16,
                headerText,
                headerSpacer,
                badge
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= PROFILE BANNER =================

        Label avatar = new Label(
                getInitials(student.name())
        );
        avatar.setAlignment(Pos.CENTER);
        avatar.setMinSize(74, 74);
        avatar.setPrefSize(74, 74);
        avatar.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 25px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 20;"
        );

        Label studentName = new Label(
                safe(student.name())
        );
        studentName.setStyle(
                "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );
        studentName.setWrapText(true);

        Label studentRoll = new Label(
                "Roll Number: " + safe(student.rollNo())
        );
        studentRoll.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #dbeafe;"
        );

        Label studentCourse = new Label(
                courseName + "  •  Semester " + student.semester()
        );
        studentCourse.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #bfdbfe;"
        );
        studentCourse.setWrapText(true);

        VBox identityText = new VBox(
                7,
                studentName,
                studentRoll,
                studentCourse
        );
        identityText.setAlignment(Pos.CENTER_LEFT);

        HBox banner = new HBox(
                22,
                avatar,
                identityText
        );
        banner.setAlignment(Pos.CENTER_LEFT);
        banner.setPadding(
                new Insets(28, 30, 28, 30)
        );
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, " + NAVY + ", #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= SECTION TITLE =================

        Label detailsTitle = new Label(
                "Student Information"
        );
        detailsTitle.getStyleClass().add("section-title");

        Label detailsSubtitle = new Label(
                "Your registered details and academic enrollment."
        );
        detailsSubtitle.getStyleClass().add("page-subtitle");

        VBox sectionHeading = new VBox(
                4,
                detailsTitle,
                detailsSubtitle
        );

        // ================= PERSONAL INFORMATION =================

        VBox personalCard = createSectionCard(
                "Personal Information",
                "Your registered contact details."
        );

        GridPane personalGrid = createInfoGrid();

        addInfo(
                personalGrid,
                0,
                "FULL NAME",
                safe(student.name())
        );

        addInfo(
                personalGrid,
                1,
                "ROLL NUMBER",
                safe(student.rollNo())
        );

        addInfo(
                personalGrid,
                2,
                "EMAIL ADDRESS",
                safe(student.email())
        );

        addInfo(
                personalGrid,
                3,
                "PHONE NUMBER",
                safe(student.phone())
        );

        personalCard.getChildren().add(personalGrid);

        // ================= ACADEMIC INFORMATION =================

        VBox academicCard = createSectionCard(
                "Academic Information",
                "Your course and enrollment details."
        );

        GridPane academicGrid = createInfoGrid();

        addInfo(
                academicGrid,
                0,
                "DEPARTMENT",
                departmentName
        );

        addInfo(
                academicGrid,
                1,
                "COURSE",
                courseName
        );

        addInfo(
                academicGrid,
                2,
                "SEMESTER",
                String.valueOf(student.semester())
        );

        addInfo(
                academicGrid,
                3,
                "DIVISION",
                safe(student.division())
        );

        addInfo(
                academicGrid,
                4,
                "ADMISSION YEAR",
                String.valueOf(student.admissionYear())
        );

        academicCard.getChildren().add(academicGrid);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Student Profile"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-padding: 10 0 0 0;"
        );

        // ================= MAIN CONTENT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                sectionHeading,
                personalCard,
                academicCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );
        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scrollPane = new ScrollPane(
                mainContent
        );
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );
        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        // ================= ROOT LAYOUT =================

        BorderPane root = new BorderPane();
        root.setLeft(sidebar);
        root.setCenter(scrollPane);

        Scene scene = new Scene(
                root,
                1120,
                720
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - My Profile"
        );
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= HELPER METHODS =================

    private VBox createSectionCard(
            String title,
            String subtitle
    ) {

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-text-fill: #14233e;" +
                        "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;"
        );

        Label subtitleLabel = new Label(subtitle);
        subtitleLabel.setStyle(
                "-fx-text-fill: " + MUTED + ";" +
                        "-fx-font-size: 12px;"
        );
        subtitleLabel.setWrapText(true);

        VBox card = new VBox(
                20,
                titleLabel,
                subtitleLabel
        );

        card.getStyleClass().add("content-card");
        card.setMaxWidth(Double.MAX_VALUE);

        return card;
    }

    private GridPane createInfoGrid() {

        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(22);

        javafx.scene.layout.ColumnConstraints first =
                new javafx.scene.layout.ColumnConstraints();

        first.setPercentWidth(50);

        javafx.scene.layout.ColumnConstraints second =
                new javafx.scene.layout.ColumnConstraints();

        second.setPercentWidth(50);

        grid.getColumnConstraints().addAll(
                first,
                second
        );

        return grid;
    }

    private void addInfo(
            GridPane grid,
            int index,
            String label,
            String value
    ) {

        Label fieldLabel = new Label(label);
        fieldLabel.setStyle(
                "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #94a3b8;"
        );

        Label fieldValue = new Label(value);
        fieldValue.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #334155;"
        );
        fieldValue.setWrapText(true);

        VBox field = new VBox(
                7,
                fieldLabel,
                fieldValue
        );

        field.setMaxWidth(Double.MAX_VALUE);

        grid.add(
                field,
                index % 2,
                index / 2
        );
    }

    private String safe(String value) {

        if (value == null || value.isBlank()) {
            return "Not available";
        }

        return value;
    }

    private String getInitials(String name) {

        if (name == null || name.isBlank()) {
            return "ST";
        }

        String[] parts = name.trim().split("\\s+");

        if (parts.length == 1) {
            return parts[0]
                    .substring(
                            0,
                            Math.min(2, parts[0].length())
                    )
                    .toUpperCase();
        }

        return (
                parts[0].substring(0, 1)
                        + parts[parts.length - 1].substring(0, 1)
        ).toUpperCase();
    }

    // ================= ERROR HANDLING =================

    private void showError(String message) {

        Alert alert = new Alert(
                Alert.AlertType.ERROR
        );

        alert.setTitle("CampusTrack");
        alert.setHeaderText("Profile Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
