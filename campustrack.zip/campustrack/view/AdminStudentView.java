
package com.college.campustrack.view;

import com.college.campustrack.StyleManager;
import com.college.campustrack.UserSession;
import com.college.campustrack.dao.AdminStudentDAO;
import com.college.campustrack.dao.StudentDAO;
import com.college.campustrack.model.Student;
import com.college.campustrack.model.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.time.Year;

public class AdminStudentView {

    private final AdminStudentDAO adminDAO =
            new AdminStudentDAO();

    private final StudentDAO studentDAO =
            new StudentDAO();

    public void show(Stage stage) {

        User user = UserSession.getCurrentUser();

        if (user == null || !"ADMIN".equals(user.role())) {
            showAlert(
                    Alert.AlertType.ERROR,
                    "Please log in as an administrator."
            );
            return;
        }

        // ================= PAGE HEADER =================

        Label eyebrow = new Label("ADMIN PORTAL");
        eyebrow.setStyle(
                "-fx-text-fill: #2563eb;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        Label title = new Label("Student Management");
        title.getStyleClass().add("page-title");

        Label subtitle = new Label(
                "Create, search, update, and manage student records."
        );
        subtitle.getStyleClass().add("page-subtitle");

        VBox titleBox = new VBox(
                5, eyebrow, title, subtitle
        );

        Button back = new Button("← Back to Dashboard");
        back.setStyle(
                "-fx-background-color: white;" +
                        "-fx-text-fill: #14233e;" +
                        "-fx-font-weight: bold;" +
                        "-fx-border-color: #e2e8f0;" +
                        "-fx-border-radius: 9;" +
                        "-fx-background-radius: 9;" +
                        "-fx-padding: 11 16;"
        );
        back.setOnAction(e ->
                new AdminDashboardView().show(stage)
        );

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        HBox header = new HBox(
                16, titleBox, headerSpacer, back
        );
        header.setAlignment(Pos.CENTER_LEFT);

        // ================= BANNER =================

        Label bannerTag = new Label(
                "ADMINISTRATION • STUDENTS"
        );
        bannerTag.setStyle(
                "-fx-text-fill: #bfdbfe;" +
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;"
        );

        Label bannerTitle = new Label(
                "Manage your student community."
        );
        bannerTitle.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 23px;" +
                        "-fx-font-weight: bold;"
        );
        bannerTitle.setWrapText(true);

        Label bannerDescription = new Label(
                "Maintain student profiles, academic assignments, " +
                        "and login accounts from one place."
        );
        bannerDescription.setStyle(
                "-fx-text-fill: #dbeafe;" +
                        "-fx-font-size: 13px;"
        );
        bannerDescription.setWrapText(true);

        VBox banner = new VBox(
                10,
                bannerTag,
                bannerTitle,
                bannerDescription
        );
        banner.setPadding(new Insets(26, 30, 26, 30));
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setStyle(
                "-fx-background-color: linear-gradient(" +
                        "to right, #14233e, #2563eb);" +
                        "-fx-background-radius: 18;"
        );

        // ================= FORM CONTROLS =================

        TextField roll = new TextField();
        TextField name = new TextField();
        TextField email = new TextField();
        TextField phone = new TextField();
        TextField division = new TextField("A");

        TextField year = new TextField(
                String.valueOf(Year.now().getValue())
        );

        TextField username = new TextField();
        PasswordField password = new PasswordField();

        roll.setPromptText("Enter roll number");
        name.setPromptText("Enter full name");
        email.setPromptText("Enter email address");
        phone.setPromptText("Enter phone number");
        division.setPromptText("e.g. A");
        year.setPromptText("Admission year");
        username.setPromptText("Create login username");
        password.setPromptText("Create login password");

        ComboBox<String> department = new ComboBox<>();
        ComboBox<String> course = new ComboBox<>();

        ComboBox<Integer> semester = new ComboBox<>(
                FXCollections.observableArrayList(
                        1, 2, 3, 4, 5, 6, 7, 8
                )
        );

        department.setPromptText("Select branch");
        course.setPromptText("Select course");
        semester.setPromptText("Select semester");

        // ================= LOAD BRANCHES =================

        try {

            for (String[] d : adminDAO.getDepartments()) {
                department.getItems().add(
                        d[0] + " - " + d[1]
                );
            }

        } catch (Exception e) {

            showAlert(
                    Alert.AlertType.ERROR,
                    "Unable to load branches: " + e.getMessage()
            );
        }

        department.setOnAction(event -> {

            course.getItems().clear();
            course.setValue(null);

            if (department.getValue() == null) {
                return;
            }

            try {

                for (String[] c : adminDAO.getCourses(
                        getId(department.getValue()))) {

                    course.getItems().add(
                            c[0] + " - " + c[1]
                    );
                }

            } catch (Exception e) {

                showAlert(
                        Alert.AlertType.ERROR,
                        e.getMessage()
                );
            }
        });

        // ================= FORM SECTIONS =================

        Label mode = new Label("CREATE NEW STUDENT");
        mode.setStyle(
                "-fx-background-color: #dbeafe;" +
                        "-fx-text-fill: #1d4ed8;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 9 14;" +
                        "-fx-background-radius: 16;"
        );

        Label formTitle = new Label("Student Details");
        formTitle.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label formDescription = new Label(
                "Enter personal, academic, and account information."
        );
        formDescription.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        GridPane personalGrid = new GridPane();
        personalGrid.setHgap(18);
        personalGrid.setVgap(16);

        addField(personalGrid, 0, 0, "ROLL NUMBER", roll);
        addField(personalGrid, 1, 0, "FULL NAME", name);
        addField(personalGrid, 0, 1, "EMAIL", email);
        addField(personalGrid, 1, 1, "PHONE", phone);

        GridPane academicGrid = new GridPane();
        academicGrid.setHgap(18);
        academicGrid.setVgap(16);

        addField(academicGrid, 0, 0, "BRANCH", department);
        addField(academicGrid, 1, 0, "COURSE", course);
        addField(academicGrid, 0, 1, "SEMESTER", semester);
        addField(academicGrid, 1, 1, "DIVISION", division);
        addField(academicGrid, 0, 2, "ADMISSION YEAR", year);

        GridPane accountGrid = new GridPane();
        accountGrid.setHgap(18);
        accountGrid.setVgap(16);

        addField(accountGrid, 0, 0, "LOGIN USERNAME", username);
        addField(accountGrid, 1, 0, "LOGIN PASSWORD", password);

        Label personalTitle = sectionLabel(
                "Personal Information"
        );

        Label academicTitle = sectionLabel(
                "Academic Information"
        );

        Label accountTitle = sectionLabel(
                "Login Account"
        );

        Label accountHint = new Label(
                "Login credentials are created with new students. " +
                        "They are not changed when editing a student."
        );
        accountHint.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 11px;"
        );
        accountHint.setWrapText(true);

        // ================= ACTION BUTTONS =================

        Button create = new Button(
                "Create Student & Login"
        );

        Button update = new Button("Save Changes");
        Button delete = new Button("Deactivate Student");
        Button reactivate = new Button("Reactivate Student");
        Button clear = new Button("Clear / New Student");

        create.setStyle(primaryButtonStyle());
        update.setStyle(primaryButtonStyle());

        delete.setStyle(
                "-fx-background-color: #fee2e2;" +
                        "-fx-text-fill: #b91c1c;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;"
        );

        reactivate.setStyle(primaryButtonStyle());

        clear.setStyle(
                "-fx-background-color: #f1f5f9;" +
                        "-fx-text-fill: #334155;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 11 17;" +
                        "-fx-background-radius: 9;"
        );

        update.setDisable(true);
        delete.setDisable(true);
        reactivate.setDisable(true);

        HBox actions = new HBox(
                12,
                create,
                update,
                delete,
                reactivate,
                clear
        );
        actions.setAlignment(Pos.CENTER_LEFT);
        actions.setPadding(new Insets(10, 0, 0, 0));

        VBox formCard = new VBox(
                22,
                mode,
                formTitle,
                formDescription,
                personalTitle,
                personalGrid,
                academicTitle,
                academicGrid,
                accountTitle,
                accountHint,
                accountGrid,
                actions
        );

        formCard.getStyleClass().add("content-card");
        formCard.setMaxWidth(Double.MAX_VALUE);

        // ================= STUDENT TABLE =================

        TextField search = new TextField();
        search.setPromptText(
                "Search by name, roll number or email"
        );
        search.setMaxWidth(Double.MAX_VALUE);

        TableView<Student> table = new TableView<>();

        TableColumn<Student, String> rollColumn =
                new TableColumn<>("Roll Number");

        rollColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().rollNo()
                )
        );

        TableColumn<Student, String> nameColumn =
                new TableColumn<>("Name");

        nameColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().name()
                )
        );

        TableColumn<Student, String> emailColumn =
                new TableColumn<>("Email");

        emailColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().email()
                )
        );

        TableColumn<Student, String> statusColumn =
                new TableColumn<>("Status");
        statusColumn.setCellValueFactory(data -> {
            try {
                return new SimpleStringProperty(
                        adminDAO.isStudentActive(data.getValue().id())
                                ? "Active" : "Inactive");
            } catch (Exception ex) {
                return new SimpleStringProperty("Unknown");
            }
        });

        table.getColumns().addAll(
                rollColumn,
                nameColumn,
                emailColumn,
                statusColumn
        );

        table.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        table.setPrefHeight(330);
        table.setMinHeight(260);

        table.setPlaceholder(
                new Label("No matching students found.")
        );

        Label recordsTitle = new Label(
                "Existing Students"
        );
        recordsTitle.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        Label recordsDescription = new Label(
                "Search students and select a row to edit or change its status."
        );
        recordsDescription.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 12px;"
        );

        VBox recordsCard = new VBox(
                18,
                recordsTitle,
                recordsDescription,
                search,
                table
        );

        recordsCard.getStyleClass().add("content-card");
        recordsCard.setMaxWidth(Double.MAX_VALUE);

        // ================= CREATE / EDIT STATE =================

        final Student[] selectedStudent = {null};

        Runnable clearForm = () -> {

            selectedStudent[0] = null;

            table.getSelectionModel().clearSelection();

            roll.clear();
            name.clear();
            email.clear();
            phone.clear();

            division.setText("A");

            year.setText(
                    String.valueOf(Year.now().getValue())
            );

            username.clear();
            password.clear();

            department.setValue(null);
            course.getItems().clear();
            course.setValue(null);
            semester.setValue(null);

            username.setDisable(false);
            password.setDisable(false);

            create.setDisable(false);
            update.setDisable(true);
            delete.setDisable(true);
            reactivate.setDisable(true);

            mode.setText("CREATE NEW STUDENT");
        };

        // ================= SELECT STUDENT =================

        table.getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldValue, student) -> {

                    if (student == null) {
                        return;
                    }

                    selectedStudent[0] = student;

                    roll.setText(student.rollNo());
                    name.setText(student.name());
                    email.setText(student.email());

                    phone.setText(
                            student.phone() == null
                                    ? ""
                                    : student.phone()
                    );

                    division.setText(
                            student.division() == null
                                    ? ""
                                    : student.division()
                    );

                    year.setText(
                            String.valueOf(
                                    student.admissionYear()
                            )
                    );

                    semester.setValue(student.semester());

                    selectById(
                            department,
                            student.departmentId()
                    );

                    selectById(
                            course,
                            student.courseId()
                    );

                    username.clear();
                    password.clear();

                    username.setDisable(true);
                    password.setDisable(true);

                    create.setDisable(true);
                    update.setDisable(false);
                    try {
                        boolean active = adminDAO.isStudentActive(student.id());
                        delete.setDisable(!active);
                        reactivate.setDisable(active);
                    } catch (Exception ex) {
                        delete.setDisable(true);
                        reactivate.setDisable(true);
                        showAlert(Alert.AlertType.ERROR,
                                "Unable to read student status: " + ex.getMessage());
                    }

                    mode.setText(
                            "EDITING: " + student.name()
                                    + " (ID " + student.id() + ")"
                    );
                });

        // ================= CREATE STUDENT =================

        create.setOnAction(event -> {

            try {

                Student student = buildStudent(
                        0,
                        roll,
                        name,
                        email,
                        phone,
                        department,
                        course,
                        semester,
                        division,
                        year
                );

                int id = adminDAO.createStudentWithAccount(
                        student,
                        username.getText(),
                        password.getText()
                );

                showAlert(
                        Alert.AlertType.INFORMATION,
                        "Student and login created! ID: " + id
                );

                clearForm.run();
                refreshStudents(
                        search.getText(),
                        table
                );

            } catch (Exception e) {

                showAlert(
                        Alert.AlertType.ERROR,
                        "Creation failed: " + e.getMessage()
                );
            }
        });

        // ================= UPDATE STUDENT =================

        update.setOnAction(event -> {

            try {

                if (selectedStudent[0] == null) {
                    return;
                }

                Student updated = buildStudent(
                        selectedStudent[0].id(),
                        roll,
                        name,
                        email,
                        phone,
                        department,
                        course,
                        semester,
                        division,
                        year
                );

                adminDAO.updateStudent(updated);

                showAlert(
                        Alert.AlertType.INFORMATION,
                        "Student updated successfully!"
                );

                clearForm.run();
                refreshStudents(
                        search.getText(),
                        table
                );

            } catch (Exception e) {

                showAlert(
                        Alert.AlertType.ERROR,
                        "Update failed: " + e.getMessage()
                );
            }
        });

        // ================= DEACTIVATE / REACTIVATE =================

        delete.setOnAction(event -> {
            Student selected = selectedStudent[0];
            if (selected == null) return;

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                    "Deactivate " + selected.name() + "?\n\n" +
                            "The student will be unable to log in. " +
                            "Attendance, marks, fees and academic history will be preserved.",
                    ButtonType.YES, ButtonType.NO);
            confirm.setTitle("Confirm Student Deactivation");
            if (confirm.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

            try {
                adminDAO.setStudentActive(selected.id(), false);
                showAlert(Alert.AlertType.INFORMATION,
                        "Student deactivated. All academic records are preserved.");
                clearForm.run();
                refreshStudents(search.getText(), table);
            } catch (Exception ex) {
                showAlert(Alert.AlertType.ERROR,
                        "Deactivation failed: " + ex.getMessage());
            }
        });

        reactivate.setOnAction(event -> {
            Student selected = selectedStudent[0];
            if (selected == null) return;

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                    "Reactivate " + selected.name() + " and restore login access?",
                    ButtonType.YES, ButtonType.NO);
            confirm.setTitle("Confirm Student Reactivation");
            if (confirm.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

            try {
                adminDAO.setStudentActive(selected.id(), true);
                showAlert(Alert.AlertType.INFORMATION,
                        "Student reactivated successfully.");
                clearForm.run();
                refreshStudents(search.getText(), table);
            } catch (Exception ex) {
                showAlert(Alert.AlertType.ERROR,
                        "Reactivation failed: " + ex.getMessage());
            }
        });

        clear.setOnAction(event -> clearForm.run());

        // ================= SEARCH =================

        search.textProperty().addListener(
                (observable, oldValue, newValue) ->
                        refreshStudents(
                                newValue,
                                table
                        )
        );

        refreshStudents("", table);

        // ================= FOOTER =================

        Label footer = new Label(
                "CampusTrack  •  Admin Student Management"
        );
        footer.setStyle(
                "-fx-text-fill: #94a3b8;" +
                        "-fx-font-size: 11px;"
        );

        // ================= MAIN LAYOUT =================

        VBox mainContent = new VBox(
                24,
                header,
                banner,
                formCard,
                recordsCard,
                footer
        );

        mainContent.setPadding(
                new Insets(32, 36, 32, 36)
        );

        mainContent.setStyle(
                "-fx-background-color: #f1f5fb;"
        );

        ScrollPane scroll = new ScrollPane(mainContent);
        scroll.setFitToWidth(true);

        scroll.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );

        Scene scene = new Scene(
                scroll,
                1120,
                750
        );

        StyleManager.applyStyles(scene);

        stage.setTitle(
                "CampusTrack - Student Management"
        );

        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ================= BUILD STUDENT =================

    private Student buildStudent(
            int id,
            TextField roll,
            TextField name,
            TextField email,
            TextField phone,
            ComboBox<String> department,
            ComboBox<String> course,
            ComboBox<Integer> semester,
            TextField division,
            TextField year
    ) {

        if (department.getValue() == null
                || course.getValue() == null
                || semester.getValue() == null) {

            throw new IllegalArgumentException(
                    "Please select branch, course and semester."
            );
        }

        return new Student(
                id,
                roll.getText().trim(),
                name.getText().trim(),
                email.getText().trim(),
                phone.getText().trim(),
                getId(department.getValue()),
                getId(course.getValue()),
                semester.getValue(),
                division.getText().trim(),
                Integer.parseInt(year.getText().trim())
        );
    }

    // ================= FORM FIELD =================

    private void addField(
            GridPane grid,
            int column,
            int row,
            String labelText,
            Control control
    ) {

        Label label = new Label(labelText);
        label.setStyle(
                "-fx-text-fill: #64748b;" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;"
        );

        control.setMaxWidth(Double.MAX_VALUE);

        VBox field = new VBox(
                7,
                label,
                control
        );

        grid.add(field, column, row);

        ColumnConstraints first = null;

        if (grid.getColumnConstraints().isEmpty()) {

            ColumnConstraints left =
                    new ColumnConstraints();

            ColumnConstraints right =
                    new ColumnConstraints();

            left.setPercentWidth(50);
            right.setPercentWidth(50);

            grid.getColumnConstraints().addAll(
                    left,
                    right
            );
        }
    }

    // ================= SECTION LABEL =================

    private Label sectionLabel(String text) {

        Label label = new Label(text);

        label.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #14233e;"
        );

        return label;
    }

    // ================= BUTTON STYLE =================

    private String primaryButtonStyle() {

        return "-fx-background-color: #2563eb;" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 11 17;" +
                "-fx-background-radius: 9;";
    }

    // ================= SELECT BY ID =================

    private void selectById(
            ComboBox<String> box,
            int id
    ) {

        for (String item : box.getItems()) {

            if (getId(item) == id) {
                box.setValue(item);
                return;
            }
        }
    }

    // ================= PARSE ID =================

    private int getId(String value) {

        return Integer.parseInt(
                value.split(" - ", 2)[0]
        );
    }

    // ================= REFRESH STUDENTS =================

    private void refreshStudents(
            String query,
            TableView<Student> table
    ) {

        try {

            table.setItems(
                    FXCollections.observableArrayList(
                            studentDAO.search(query)
                    )
            );

        } catch (Exception e) {

            showAlert(
                    Alert.AlertType.ERROR,
                    "Unable to load students: "
                            + e.getMessage()
            );
        }
    }

    // ================= ALERT =================

    private void showAlert(
            Alert.AlertType type,
            String message
    ) {

        Alert alert = new Alert(
                type,
                message,
                ButtonType.OK
        );

        alert.setTitle("CampusTrack");
        alert.showAndWait();
    }
}

