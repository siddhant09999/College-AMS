
package com.college.campustrack;

import com.college.campustrack.model.User;
import com.college.campustrack.service.AuthService;
import com.college.campustrack.view.AdminDashboardView;
import com.college.campustrack.view.DashboardView;
import com.college.campustrack.view.FacultyDashboardView;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) {
        showLogin(stage);
    }

    public void showLogin(Stage stage) {

        // ----- LOGIN SCREEN -----

        Label title = new Label("CampusTrack");
        title.getStyleClass().add("login-title");

        Label subtitle = new Label("College Management System");
        subtitle.getStyleClass().add("login-subtitle");

        Label usernameLabel = new Label("Username");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter your username");

        Label passwordLabel = new Label("Password");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");

        usernameField.getStyleClass().add("login-field");
        passwordField.getStyleClass().add("login-field");

        Button loginButton = new Button("Login");
        loginButton.getStyleClass().add("login-button");

        loginButton.setOnAction(event -> {

            String username = usernameField.getText().trim();
            String password = passwordField.getText();

            if (username.isEmpty() || password.isEmpty()) {
                showError("Please enter your username and password.");
                return;
            }

            try {
                AuthService authService = new AuthService();

                User user = authService.login(username, password);

                if (user == null) {
                    showError("Invalid username or password.");
                    return;
                }

                // ----- STUDENT LOGIN -----

                if ("STUDENT".equals(user.role())
                        && user.studentId() != null) {

                    UserSession.setCurrentUser(user);
                    new DashboardView().show(stage);

                    // ----- FACULTY LOGIN -----

                } else if ("FACULTY".equals(user.role())
                        && user.facultyId() != null) {

                    UserSession.setCurrentUser(user);
                    new FacultyDashboardView().show(stage);

                    // ----- ADMIN LOGIN -----

                } else if ("ADMIN".equals(user.role())) {

                    UserSession.setCurrentUser(user);
                    new AdminDashboardView().show(stage);

                } else {

                    showError(
                            "This account does not have access to a portal."
                    );
                }

            } catch (SecurityException e) {

                showError("Invalid username or password.");

            } catch (Exception e) {

                showError("Unable to connect to the system.");
                e.printStackTrace();
            }
        });

        // Press Enter to log in
        passwordField.setOnAction(event -> loginButton.fire());

        VBox root = new VBox(
                10,
                title,
                subtitle,
                usernameLabel,
                usernameField,
                passwordLabel,
                passwordField,
                loginButton
        );

        root.getStyleClass().add("login-root");
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(40));

        Scene scene = new Scene(root, 800, 500);
        StyleManager.applyStyles(scene);

        stage.setTitle("CampusTrack - Login");
        stage.setScene(scene);
        stage.show();
    }

    private void showError(String message) {

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("CampusTrack");
        alert.setHeaderText("Login Failed");
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch();
    }
}
