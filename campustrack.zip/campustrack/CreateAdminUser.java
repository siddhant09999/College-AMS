
package com.college.campustrack;

import com.college.campustrack.service.AuthService;

import java.io.Console;
import java.util.Arrays;
import java.util.Scanner;

public class CreateAdminUser {

    public static void main(String[] args) {

        try {
            String username = "admin1";

            String password;

            Console console = System.console();

            if (console != null) {
                char[] chars = console.readPassword(
                        "Enter a password for admin1: "
                );

                if (chars == null) {
                    return;
                }

                password = new String(chars);
                Arrays.fill(chars, '\0');

            } else {
                // IntelliJ's Run console may not support System.console().
                Scanner scanner = new Scanner(System.in);

                System.out.print("Enter a password for admin1: ");
                password = scanner.nextLine();
            }

            if (password.length() < 12) {
                System.out.println(
                        "Use a password with at least 12 characters."
                );
                return;
            }

            AuthService authService = new AuthService();

            int userId = authService.createUser(
                    username,
                    password,
                    "ADMIN",
                    null,
                    null
            );

            System.out.println(
                    "Admin account created successfully! ID: " + userId
            );

        } catch (Exception e) {
            System.err.println(
                    "Admin creation failed: " + e.getMessage()
            );
        }
    }
}
