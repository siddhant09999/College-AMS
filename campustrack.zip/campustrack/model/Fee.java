package com.college.campustrack.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public record Fee(int id, int studentId, String feeType, BigDecimal amount, BigDecimal paidAmount, LocalDate dueDate, String status) {}
