package com.college.campustrack.model;

public record Faculty(int id, String employeeNo, String name, String email, String phone, int departmentId) {}
