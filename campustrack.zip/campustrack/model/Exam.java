package com.college.campustrack.model;

import java.time.LocalDate;

public record Exam(int id, String name, int semester, LocalDate examDate, int maxMarks) {}
