package com.college.campustrack.model;

public record Course(int id, String name, String code, int departmentId, int durationYears){}