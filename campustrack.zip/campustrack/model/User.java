package com.college.campustrack.model;
public record User(int id, String username, String passwordHash, String role, Integer studentId, Integer facultyId) {}
