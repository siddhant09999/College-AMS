package com.college.campustrack.model;



public record Department(int id, String name, String code) {}

