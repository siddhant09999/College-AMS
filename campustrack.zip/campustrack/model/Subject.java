package com.college.campustrack.model;

public record Subject(int id, String name, String code, int courseId, int semester, int credits) {}

