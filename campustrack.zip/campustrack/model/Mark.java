package com.college.campustrack.model;


public record Mark(int id, int studentId, int subjectId, int examId, double marks) {}