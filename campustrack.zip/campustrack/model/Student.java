package com.college.campustrack.model;

public record Student(int id, String rollNo, String name, String email, String phone, int departmentId, int courseId, int semester, String division, int admissionYear) {}
