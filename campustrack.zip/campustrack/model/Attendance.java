package com.college.campustrack.model;

import java.time.LocalDate;

public record Attendance(int id, int studentId, int subjectId, LocalDate date, boolean present) {}
